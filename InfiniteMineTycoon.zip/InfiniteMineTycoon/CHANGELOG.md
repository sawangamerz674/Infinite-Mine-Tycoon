# Changelog

All notable changes to this project. Dates are omitted; entries are in release order.

## 1.0.0 - Release candidate

### Added
- Optional AI advisor: "Ask the Foreman" card, `AdvisorSystem`, and `server/` with Gemini access, input sanitising, rate limits and a mock mode (see `docs/AI_ADVISOR.md`)
- Treasure rooms with timed chests, milestone celebrations, ambient and region effects
- All eight upgrade categories (Mining Speed, Conveyor Speed, Worker Efficiency and Automation Efficiency joined the original four)
- `AssetLoader` (sprite and background cache with optional image overrides and a loading bar) and `AnimationManager` (animation speed setting, clips, tweens)
- Bundled pixel and body fonts, 16x16 pixel icons for machines, upgrades and research
- Installable PWA (manifest, service worker, maskable icon) and Google Play guide
- Cover art, thumbnail, screenshots and store listing documents
- Unit tests, browser smoke tests, ESLint, data validator and dev server

### Changed
- Auto-sell is built in: it runs from the first launch, sells only when storage is full and also applies to offline progress. Manager, research and the Automation Efficiency upgrade shorten its delay
- The scene scales by whole numbers for even pixels; the letterbox is filled with the region backdrop
- Portrait phones keep the scene at its native shape; tab bar uses icons
- `window.game` is exposed only on localhost or with `?debug`

## 0.7 - CrazyGames integration
- SDK v3 wrapper: init, loading and gameplay events, rewarded ads (offline x2, income boost), midgame ad after prestige, SDK data module for saves

## 0.6 - Saves and settings
- Versioned saves with checksum, backup and quarantine of corrupt data; export and import; reset
- Settings: audio, number notation, particles, screen shake, floating text, autosave, fullscreen
- Procedural sound effects and ambient music

## 0.5 - Prestige and offline progress
- Ancient Cores, a 7-upgrade tree, history, confirmation dialog
- Validated, capped offline earnings with a collect popup

## 0.4 - Progression
- 5 regions, 20 research technologies, 20 achievements, mineral discovery

## 0.3 - Automation
- Producer and support machines, workers with training levels

## 0.2 - Economy
- Minerals, storage, selling, machines, upgrades, buy x1 / x10 / max

## 0.1 - Foundation
- Canvas mine scene, HUD, manual mining, tabs, responsive layout

## Unreleased
- Added promo videos (landscape and portrait 1080p) and refreshed 16:9, 2:3 and 1:1 cover images in assets/promo.
- CrazyGames compliance pass: custom fullscreen button hidden when the SDK is active, gameplayStop on hidden tab, iOS audio resume on gesture, arrow-key scroll guard, `npm run package:crazygames` upload build.
- Responsive pass: layout follows orientation, UI scale per screen class (phones to 4K), iOS safe areas and web-app meta tags, compact landscape-phone menu, dialogs no longer open scrolled to the bottom, layout tests for 21 screen sizes.
- CrazyGames Data module for progress and player options (with one-time LocalStorage migration, fallback and size guard) and SDK `muteAudio` support (initial value and live changes, overrides in-game audio). New e2e test `tests/e2e/crazygames.test.mjs`.
- CrazyGames quality pass: title-only native-scale covers, silent 2:3 portrait and 16:9 preview videos that open on the cover, Income Boost moved off the tapping screen with a coin alternative (`boostCoinCostFactor`).
