import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus } from '../../js/core/EventBus.js';

test('on / emit / off', () => {
  const bus = new EventBus();
  const seen = [];
  const handler = (v) => seen.push(v);
  bus.on('x', handler);
  bus.emit('x', 1);
  bus.off('x', handler);
  bus.emit('x', 2);
  assert.deepEqual(seen, [1]);
});

test('on returns an unsubscribe function and once fires a single time', () => {
  const bus = new EventBus();
  let calls = 0;
  const off = bus.on('x', () => calls++);
  bus.once('x', () => calls++);
  bus.emit('x');
  bus.emit('x');
  assert.equal(calls, 3);
  off();
  bus.emit('x');
  assert.equal(calls, 3);
});

test('a throwing handler does not stop other handlers', () => {
  const bus = new EventBus();
  const original = console.error;
  console.error = () => {};
  let reached = false;
  bus.on('x', () => { throw new Error('boom'); });
  bus.on('x', () => { reached = true; });
  bus.emit('x');
  console.error = original;
  assert.equal(reached, true);
});
