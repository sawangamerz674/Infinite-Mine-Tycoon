import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isFiniteNumber, safeNumber, requireFields, requireUniqueIds } from '../../js/utils/ValidationUtils.js';
import { timeAgo } from '../../js/utils/TimeUtils.js';

test('safeNumber falls back for anything that is not a finite number', () => {
  assert.equal(safeNumber(5), 5);
  assert.equal(safeNumber(NaN, 3), 3);
  assert.equal(safeNumber('7'), 0);
  assert.equal(safeNumber(Infinity, 1), 1);
  assert.equal(isFiniteNumber(0), true);
  assert.equal(isFiniteNumber(null), false);
});

test('requireFields and requireUniqueIds throw on bad data', () => {
  assert.throws(() => requireFields({ a: 1 }, ['a', 'b'], 'thing'));
  assert.doesNotThrow(() => requireFields({ a: 1, b: 2 }, ['a', 'b'], 'thing'));
  assert.throws(() => requireUniqueIds([{ id: 'x' }, { id: 'x' }], 'list'), /duplicate/);
  assert.doesNotThrow(() => requireUniqueIds([{ id: 'x' }, { id: 'y' }], 'list'));
});

test('timeAgo', () => {
  const now = 1_000_000_000_000;
  assert.equal(timeAgo(0, now), 'never');
  assert.equal(timeAgo(now - 2000, now), 'just now');
  assert.equal(timeAgo(now - 30_000, now), '30s ago');
  assert.equal(timeAgo(now - 5 * 60_000, now), '5m ago');
  assert.equal(timeAgo(now - 3 * 3_600_000, now), '3h ago');
  assert.equal(timeAgo(now - 2 * 86_400_000, now), '2d ago');
});
