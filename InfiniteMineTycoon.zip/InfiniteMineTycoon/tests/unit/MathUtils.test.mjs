import { test } from 'node:test';
import assert from 'node:assert/strict';
import { clamp, geometricCost, maxAffordable, quotePurchase, weightedPick } from '../../js/utils/MathUtils.js';

test('clamp limits a value to a range', () => {
  assert.equal(clamp(5, 0, 3), 3);
  assert.equal(clamp(-1, 0, 3), 0);
  assert.equal(clamp(2, 0, 3), 2);
});

test('geometricCost sums baseCost x growth^level over the purchased levels', () => {
  assert.equal(geometricCost(10, 2, 0, 3), 10 + 20 + 40);
  assert.equal(geometricCost(10, 2, 2, 2), 40 + 80);
  assert.equal(geometricCost(5, 1, 7, 4), 20);
  assert.equal(geometricCost(10, 2, 0, 0), 0);
});

test('geometricCost reports Infinity instead of overflowing', () => {
  assert.equal(geometricCost(1e300, 10, 400, 5), Infinity);
});

test('maxAffordable never exceeds the budget or the cap', () => {
  const n = maxAffordable(10, 1.5, 3, 1000);
  assert.ok(geometricCost(10, 1.5, 3, n) <= 1000);
  assert.ok(geometricCost(10, 1.5, 3, n + 1) > 1000);
  assert.equal(maxAffordable(10, 1.5, 3, 1000, 2), 2);
  assert.equal(maxAffordable(10, 1.5, 0, 0), 0);
  assert.equal(maxAffordable(10, 1.5, 0, -5), 0);
});

test('quotePurchase handles fixed amounts and max mode', () => {
  assert.deepEqual(quotePurchase(10, 2, 0, 1, 100), { count: 1, cost: 10, affordable: true });
  assert.equal(quotePurchase(10, 2, 0, 10, 100).affordable, false);
  const broke = quotePurchase(10, 2, 0, 'max', 1);
  assert.equal(broke.count, 1, 'max with nothing affordable still quotes one level');
  assert.equal(broke.affordable, false);
  assert.equal(quotePurchase(10, 2, 5, 10, 1e9, 0).count, 0, 'a cap of zero means nothing to buy');
});

test('weightedPick follows the weights and ignores empty tables', () => {
  assert.equal(weightedPick({}), null);
  assert.equal(weightedPick({ a: 0, b: 0 }), null);
  assert.equal(weightedPick({ a: 1, b: 3 }, () => 0), 'a');
  assert.equal(weightedPick({ a: 1, b: 3 }, () => 0.5), 'b');
  assert.equal(weightedPick({ a: 1, b: 3 }, () => 0.9999), 'b');
});
