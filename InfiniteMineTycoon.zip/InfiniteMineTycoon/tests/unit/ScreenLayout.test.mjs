import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeUiScale } from '../../js/ui/ScreenLayout.js';

test('phones keep the base UI scale in both orientations', () => {
  for (const [w, h] of [[375, 667], [393, 852], [280, 653], [667, 375], [852, 393], [915, 412]]) {
    assert.equal(computeUiScale(w, h), 1, `${w}x${h}`);
  }
});

test('tablets in portrait scale with width', () => {
  assert.ok(computeUiScale(744, 1133) > 1.4);
  assert.ok(computeUiScale(1024, 1366) > 2);
  assert.ok(computeUiScale(1024, 1366) <= 2.2);
});

test('desktop landscape scales up to 2.5x and never below 1x', () => {
  assert.equal(computeUiScale(1280, 720), 1);
  assert.equal(computeUiScale(1920, 1080), 1.5);
  assert.equal(computeUiScale(2560, 1440), 2);
  assert.ok(computeUiScale(7680, 4320) <= 2.5);
  assert.equal(computeUiScale(800, 450), 1);
});
