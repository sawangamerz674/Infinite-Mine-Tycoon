import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AnimationManager, EASING } from '../../js/rendering/AnimationManager.js';
import { AssetLoader } from '../../js/rendering/AssetLoader.js';

test('AnimationManager scales the visual clock by the speed setting', () => {
  const anim = new AnimationManager();
  anim.setSpeed(0.5);
  assert.equal(anim.step(1), 0.5);
  anim.setSpeed(99);
  assert.equal(anim.speed, 2);
  anim.setSpeed(NaN);
  assert.equal(anim.speed, 1);
});

test('AnimationManager clips loop and one-shot clips stop on the last frame', () => {
  const anim = new AnimationManager();
  anim.defineClip('loop', { frames: ['a', 'b', 'c'], fps: 1 });
  anim.defineClip('once', { frames: ['a', 'b'], fps: 1, loop: false });
  anim.step(4.5);
  assert.equal(anim.frame('loop'), 'b');
  assert.equal(anim.frame('once'), 'b');
  assert.equal(anim.frame('missing'), undefined);
  assert.throws(() => anim.defineClip('bad', { frames: [] }));
});

test('AnimationManager tweens finish and call onDone once', () => {
  const anim = new AnimationManager();
  let done = 0;
  let last = 0;
  anim.tween({ duration: 1, onUpdate: (eased) => { last = eased; }, onDone: () => done++ });
  anim.step(0.5);
  assert.equal(done, 0);
  anim.step(1);
  anim.step(1);
  assert.equal(done, 1);
  assert.equal(last, 1);
  assert.equal(EASING.linear(0.25), 0.25);
});

test('AssetLoader builds assets lazily, caches them and rejects unknown keys', () => {
  const loader = new AssetLoader();
  let built = 0;
  loader.register('thing', () => ({ n: ++built }));
  assert.equal(built, 0);
  assert.equal(loader.get('thing').n, 1);
  assert.equal(loader.get('thing').n, 1);
  assert.equal(loader.getOrBuild('other', () => 'x'), 'x');
  assert.throws(() => loader.get('nope'), /Unknown asset/);
});
