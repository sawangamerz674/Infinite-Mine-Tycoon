import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatNumber, formatDuration, setNotation } from '../../js/utils/NumberFormatter.js';

test('small numbers are shown plainly', () => {
  assert.equal(formatNumber(0), '0');
  assert.equal(formatNumber(7), '7');
  assert.equal(formatNumber(1.234), '1.23');
  assert.equal(formatNumber(42.56), '42.6');
});

test('large numbers use suffixes with sensible precision', () => {
  assert.equal(formatNumber(1500), '1.5K');
  assert.equal(formatNumber(2_000_000), '2M');
  assert.equal(formatNumber(123_456_789), '123M');
  assert.equal(formatNumber(1e12), '1T');
});

test('rounding up to 1000 promotes to the next suffix', () => {
  assert.equal(formatNumber(999_999), '1M');
});

test('invalid input never produces NaN text', () => {
  assert.equal(formatNumber(NaN), '0');
  assert.equal(formatNumber(undefined), '0');
  assert.equal(formatNumber(Infinity), '∞');
  assert.equal(formatNumber(-1500), '-1.5K');
});

test('notation can be switched', () => {
  setNotation('scientific');
  assert.equal(formatNumber(1_500_000), '1.50e6');
  setNotation('short');
  assert.equal(formatNumber(1_500_000), '1.5M');
});

test('formatDuration', () => {
  assert.equal(formatDuration(45), '45s');
  assert.equal(formatDuration(125), '2m 05s');
  assert.equal(formatDuration(3725), '1h 02m 05s');
  assert.equal(formatDuration(-5), '0s');
  assert.equal(formatDuration(NaN), '0s');
});
