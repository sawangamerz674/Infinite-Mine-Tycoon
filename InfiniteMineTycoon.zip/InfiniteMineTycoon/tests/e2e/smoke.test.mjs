/**
 * Browser smoke tests: boots the real game in Chromium against the dev server and
 * checks the core loop (mine, buy, auto-sell, save/load, tabs). Needs Playwright
 * (`npm i -D playwright`) and a Chromium install; run with `npm run test:e2e`.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const PORT = 8123;
const URL = `http://localhost:${PORT}/index.html`;
let server;
let browser;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

before(async () => {
  server = spawn(process.execPath, ['tools/serve.mjs'], { env: { ...process.env, PORT: String(PORT) }, stdio: 'ignore' });
  await wait(500);
  browser = await chromium.launch();
});

after(async () => {
  await browser?.close();
  server?.kill();
});

/** Opens a fresh page, starts the game and collects page errors (the CrazyGames SDK may be unreachable offline). */
async function startGame() {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(URL);
  await page.click('#btn-play');
  await page.evaluate(() => game.settings.set('musicEnabled', false));
  return { page, errors };
}

test('boots to the title screen and starts a game without errors', async () => {
  const { page, errors } = await startGame();
  assert.equal(await page.evaluate(() => game.started), true);
  assert.equal(errors.length, 0, errors.join('; '));
  await page.close();
});

test('mining puts minerals in storage and selling converts them to coins', async () => {
  const { page } = await startGame();
  await page.evaluate(() => { for (let i = 0; i < 5; i++) game.manualMine(100, 90); });
  assert.ok(await page.evaluate(() => game.minerals.used()) > 0);
  await page.evaluate(() => game.economy.sellAll());
  assert.ok(await page.evaluate(() => game.state.coins) > 0);
  await page.close();
});

test('buying a machine spends coins and raises its level', async () => {
  const { page } = await startGame();
  await page.evaluate(() => { game.state.coins = 1e6; });
  const before = await page.evaluate(() => game.state.machines.basic_miner ?? 0);
  await page.click('[data-tab=machines]');
  await page.click('.item-card .btn-primary');
  assert.ok(await page.evaluate(() => game.state.machines.basic_miner) > before);
  await page.close();
});

test('auto-sell empties storage only when it is full', async () => {
  const { page } = await startGame();
  await page.evaluate(() => { game.state.minerals.coal = 5; game.state.coins = 0; });
  await wait(3600);
  assert.equal(await page.evaluate(() => game.state.coins), 0, 'a part-filled warehouse is left alone');
  await page.evaluate(() => { game.state.minerals.coal = game.minerals.capacity(); });
  await wait(3600);
  assert.ok(await page.evaluate(() => game.state.coins) > 0, 'a full warehouse is sold automatically');
  await page.close();
});

test('progress survives a reload', async () => {
  const { page } = await startGame();
  await page.evaluate(() => { game.state.coins = 12345; game.save.save(); });
  await page.reload();
  await page.click('#btn-play');
  assert.equal(await page.evaluate(() => Math.floor(game.state.coins)), 12345);
  await page.close();
});

test('every tab opens its panel', async () => {
  const { page } = await startGame();
  for (const tab of ['mine', 'machines', 'workers', 'research', 'statistics', 'prestige', 'settings']) {
    await page.click(`[data-tab=${tab}]`);
    assert.ok(await page.locator('.panel.active').count() > 0, `${tab} panel is visible`);
  }
  await page.close();
});
