/**
 * Advisor end-to-end: with the mock server the Foreman card appears and answers; on a plain
 * static server (no API) the card stays hidden. Needs Playwright.
 */
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';

const { chromium } = createRequire(import.meta.url)('playwright');
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const children = [];

function start(script, args, port) {
  const child = spawn(process.execPath, [script, ...args], { env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
  children.push(child);
  return wait(600);
}

after(() => children.forEach((c) => c.kill()));

async function open(browser, port) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(`http://localhost:${port}/index.html`);
  await page.click('#btn-play');
  await page.evaluate(() => game.settings.set('musicEnabled', false));
  return page;
}

test('mock advisor: card appears, answers once, then enforces the cooldown', async () => {
  await start('server/index.mjs', ['--mock'], 8124);
  const browser = await chromium.launch();
  const page = await open(browser, 8124);
  await page.waitForSelector('.advisor-card:not([hidden])');
  await page.click('.advisor-card .btn');
  await page.waitForFunction(() => !document.querySelector('.advisor-tip').textContent.includes('thinking'));
  const tip = await page.textContent('.advisor-tip');
  assert.ok(tip.length > 10 && !tip.includes('thinking'), tip);
  assert.match(await page.textContent('.advisor-card .btn'), /Ask again in \d+s/);
  assert.equal(await page.isDisabled('.advisor-card .btn'), true);
  await browser.close();
});

test('the server rejects bad requests without crashing', async () => {
  const bad = await fetch('http://localhost:8124/api/advisor', { method: 'POST', body: 'not json' });
  assert.equal(bad.status, 400);
  const wrongShape = await fetch('http://localhost:8124/api/advisor', { method: 'POST', body: '[]' });
  assert.equal(wrongShape.status, 400);
  const huge = await fetch('http://localhost:8124/api/advisor', { method: 'POST', body: 'x'.repeat(20000) }).catch(() => ({ status: 413 }));
  assert.ok([413, 400].includes(huge.status));
  const health = await (await fetch('http://localhost:8124/api/health')).json();
  assert.deepEqual(health, { ok: true, enabled: true });
});

test('without the API the Foreman card stays hidden', async () => {
  await start('tools/serve.mjs', [], 8125);
  const browser = await chromium.launch();
  const page = await open(browser, 8125);
  await wait(1500);
  assert.equal(await page.locator('.advisor-card').isHidden(), true);
  await browser.close();
});
