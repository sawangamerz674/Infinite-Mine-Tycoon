/* global __cgData, __cgListeners -- defined by the stub inside the browser page */
/**
 * CrazyGames integration end-to-end against a stub of the documented SDK v3 API:
 * progress and settings go through SDK.data, an older LocalStorage save is migrated once,
 * and SDK.game.settings.muteAudio (initial value and live changes) overrides the in-game audio.
 * The live SDK is not reachable from tests, so also try the game in the CrazyGames QA tool.
 * Needs Playwright and a static server on PORT (default 8080, `npm start`).
 */
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const { chromium } = createRequire(import.meta.url)('playwright');
const base = `http://localhost:${process.env.PORT || 8080}/index.html`;

const stub = (muteAudio) => `
window.__cgData = {}; window.__cgListeners = [];
window.CrazyGames = { SDK: { environment: 'crazygames', init: async () => {},
  game: { settings: { muteAudio: ${muteAudio}, disableChat: false },
    loadingStart() {}, loadingStop() {}, gameplayStart() {}, gameplayStop() {},
    addSettingsChangeListener(l) { __cgListeners.push(l); },
    removeSettingsChangeListener(l) { __cgListeners.splice(__cgListeners.indexOf(l), 1); } },
  ad: { hasAdblock: async () => false, requestAd(t, cb) { cb.adError({ code: 'unfilled' }); } },
  data: { getItem: (k) => (k in __cgData ? __cgData[k] : null), setItem: (k, v) => { __cgData[k] = String(v); },
          removeItem: (k) => { delete __cgData[k]; }, clear() { __cgData = {}; } } } };`;

let browser;
after(() => browser?.close());

async function open({ muteAudio = false, seed } = {}) {
  browser ??= await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await ctx.newPage();
  await page.route('**/crazygames-sdk-v3.js', (r) => r.fulfill({ body: stub(muteAudio), contentType: 'application/javascript' }));
  if (seed) await page.addInitScript((s) => { if (!localStorage.getItem('__seeded')) { for (const [k, v] of Object.entries(s)) localStorage.setItem(k, v); localStorage.setItem('__seeded', '1'); } }, seed);
  await page.goto(base);
  await page.waitForSelector('#btn-play:not([disabled])');
  await page.click('#btn-play');
  await page.waitForTimeout(400);
  return { ctx, page };
}

test('progress and settings are stored through the SDK data module', async () => {
  const { ctx, page } = await open();
  await page.evaluate(() => { game.state.addCoins(1234); game.settings.set('particles', 'low'); game.save.save('manual'); });
  const keys = await page.evaluate(() => Object.keys(__cgData));
  assert.ok(keys.includes('infinite_mine_tycoon_save'), `save key in data module: ${keys}`);
  assert.ok(keys.some((k) => k.includes('settings')), `settings key in data module: ${keys}`);
  const local = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith('infinite_mine')));
  assert.deepEqual(local, [], 'nothing written to LocalStorage while the SDK is active');
  await page.reload();
  await page.waitForSelector('#btn-play:not([disabled])');
  await ctx.close();
});

test('an older LocalStorage save is migrated into the data module and then removed', async () => {
  // Build a real save with the SDK off, then reuse its LocalStorage contents.
  browser ??= await chromium.launch();
  const plain = await (await browser.newContext()).newPage();
  await plain.route('**/crazygames-sdk-v3.js', (r) => r.abort());
  await plain.goto(base);
  await plain.waitForSelector('#btn-play:not([disabled])');
  await plain.click('#btn-play');
  await plain.evaluate(() => { game.state.addCoins(777); game.save.save('manual'); });
  const seed = await plain.evaluate(() => Object.fromEntries(Object.entries(localStorage)));
  await plain.context().close();
  assert.ok(seed.infinite_mine_tycoon_save, 'seed save exists');

  const { ctx, page } = await open({ seed });
  const result = await page.evaluate(() => ({
    coins: game.state.coins >= 777,
    inSdk: 'infinite_mine_tycoon_save' in __cgData,
    legacyLeft: localStorage.getItem('infinite_mine_tycoon_save'),
  }));
  assert.equal(result.coins, true, 'progress restored from the old save');
  assert.equal(result.inSdk, true, 'copied into the data module');
  assert.equal(result.legacyLeft, null, 'old copy removed after verification');
  await ctx.close();
});

test('SDK muteAudio overrides the in-game audio options, at start and live', async () => {
  const { ctx, page } = await open({ muteAudio: true });
  const state = () => page.evaluate(() => game.audio.ctx?.state);
  await page.evaluate(() => game.settings.set('musicEnabled', true));
  await page.click('#btn-play').catch(() => {});
  await page.mouse.click(640, 300);
  await page.waitForTimeout(300);
  assert.notEqual(await state(), 'running', 'muted by the portal at start');
  await page.click('.tab[data-tab=settings]');
  assert.equal(await page.isVisible('#panel-area >> text=Sound is muted by CrazyGames'), true, 'player is told why');

  await page.evaluate(() => __cgListeners.forEach((l) => l({ muteAudio: false, disableChat: false })));
  await page.mouse.click(640, 300);
  await page.waitForTimeout(300);
  assert.equal(await state(), 'running', 'portal unmuted');
  assert.equal(await page.isVisible('#panel-area >> text=Sound is muted by CrazyGames'), false);

  await page.evaluate(() => __cgListeners.forEach((l) => l({ muteAudio: true })));
  await page.waitForTimeout(200);
  assert.notEqual(await state(), 'running', 'muted again live');
  await page.evaluate(() => game.settings.set('musicEnabled', true));
  assert.notEqual(await state(), 'running', 'in-game toggle cannot override the portal mute');
  await ctx.close();
});
