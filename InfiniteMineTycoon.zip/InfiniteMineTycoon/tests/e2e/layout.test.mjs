/**
 * Layout end-to-end: for phones, tablets and desktops in portrait and landscape, the menu,
 * game screen and a dialog must fit the viewport with no page scroll and no clipped HUD/tabs.
 * Needs Playwright and a static server on PORT (default 8080, `npm start`).
 */
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const { chromium } = createRequire(import.meta.url)('playwright');
const base = `http://localhost:${process.env.PORT || 8080}/index.html`;

const SCREENS = [
  [375, 667], [393, 852], [430, 932], [360, 640], [280, 653], [744, 1133], [820, 1180], [1024, 1366],
  [667, 375], [852, 393], [915, 412], [640, 360], [653, 280], [1133, 744], [1366, 1024],
  [800, 450], [1280, 720], [1366, 768], [1920, 1080], [2560, 1440], [3440, 1440],
];

const inside = (r, w, h) => r.left >= -1 && r.top >= -1 && r.right <= w + 1 && r.bottom <= h + 1;
let browser;
after(() => browser?.close());

for (const [w, h] of SCREENS) {
  test(`fits ${w}x${h}`, async () => {
    browser ??= await chromium.launch();
    const touch = Math.min(w, h) <= 1024 && w < 1280;
    const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: touch, hasTouch: touch });
    const page = await ctx.newPage();
    await page.goto(base);
    await page.waitForSelector('#btn-play:not([disabled])');
    const rect = (sel) => page.evaluate((s) => { const r = document.querySelector(s).getBoundingClientRect(); return { left: r.left, top: r.top, right: r.right, bottom: r.bottom }; }, sel);
    for (const sel of ['#btn-play', '#btn-how']) assert.ok(inside(await rect(sel), w, h), `${sel} on menu`);
    await page.click('#btn-how');
    assert.ok(inside(await rect('.modal'), w, h), 'how-to-play dialog');
    await page.keyboard.press('Escape');
    await page.click('#btn-play');
    await page.waitForTimeout(400);
    for (const tab of ['mine', 'machines', 'research', 'settings']) {
      await page.click(`.tab[data-tab=${tab}]`);
      for (const sel of ['#hud', '#tabs', '#mine-view', '#panel-area']) assert.ok(inside(await rect(sel), w, h), `${sel} in ${tab}`);
      const scroll = await page.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.scrollHeight]);
      assert.ok(scroll[0] <= w + 1 && scroll[1] <= h + 1, `page scroll ${scroll}`);
      const clipped = await page.evaluate(() => [...document.querySelectorAll('#tabs .tab, #hud .hud-value')].filter((e) => e.scrollWidth > e.clientWidth + 1).length);
      assert.equal(clipped, 0, 'clipped HUD/tab text');
    }
    await ctx.close();
  });
}
