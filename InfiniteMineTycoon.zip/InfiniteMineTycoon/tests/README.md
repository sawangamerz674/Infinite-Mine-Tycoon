# Tests

| Command | What it runs |
|---------|--------------|
| `npm test` | Unit tests (`tests/unit`, Node's built-in runner, no dependencies) for the utilities, event bus, animation manager and asset loader |
| `npm run validate` | Content validation for `data/*.json` and `config/*.json` (ids, numbers, cross references) |
| `npm run lint` | ESLint |
| `npm run test:e2e` | Browser smoke tests in Chromium (needs `playwright`), including the advisor against the mock server |
| `npm run check` | lint + validate + unit tests |

The end-to-end tests start `tools/serve.mjs` on port 8123 and drive the real game through `window.game`, which is exposed on localhost only.
