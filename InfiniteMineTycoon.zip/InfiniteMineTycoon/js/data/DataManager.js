/**
 * DataManager — loads and validates the JSON data files and config so the
 * rest of the game can rely on well-formed definitions.
 */
import { requireFields, requireUniqueIds, isFiniteNumber } from '../utils/ValidationUtils.js';

async function fetchJson(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Could not load ${path} (${response.status})`);
  return response.json();
}

const byId = (list) => Object.fromEntries(list.map((x) => [x.id, x]));

export class DataManager {
  constructor({ minerals, machines, upgrades, workers, regions, research, achievements, prestige, balance }) {
    this.minerals = minerals;
    this.machines = machines;
    this.upgrades = upgrades;
    this.workers = workers;
    this.regions = regions;
    this.research = research; // { categories, techs }
    this.achievements = achievements;
    this.prestige = prestige; // { settings, upgrades }
    this.balance = balance;
    this.mineralMap = byId(minerals);
    this.machineMap = byId(machines);
    this.upgradeMap = byId(upgrades);
    this.workerMap = byId(workers);
    this.regionMap = byId(regions);
    this.techMap = byId(research.techs);
    this.prestigeMap = byId(prestige.upgrades);
    this.validate();
  }

  static async load() {
    const [minerals, machines, upgrades, workers, regions, research, achievements, prestige, balance] = await Promise.all([
      fetchJson('data/minerals.json'),
      fetchJson('data/machines.json'),
      fetchJson('data/upgrades.json'),
      fetchJson('data/workers.json'),
      fetchJson('data/regions.json'),
      fetchJson('data/research.json'),
      fetchJson('data/achievements.json'),
      fetchJson('data/prestige.json'),
      fetchJson('config/balance.config.json'),
    ]);
    return new DataManager({
      minerals: minerals.minerals,
      machines: machines.machines,
      upgrades: upgrades.upgrades,
      workers: workers.workers,
      regions: regions.regions,
      research,
      achievements: achievements.achievements,
      prestige,
      balance,
    });
  }

  validate() {
    requireUniqueIds(this.minerals, 'minerals');
    requireUniqueIds(this.machines, 'machines');
    requireUniqueIds(this.upgrades, 'upgrades');
    requireUniqueIds(this.workers, 'workers');
    requireUniqueIds(this.regions, 'regions');
    requireUniqueIds(this.research.categories, 'research categories');
    requireUniqueIds(this.research.techs, 'research techs');
    requireUniqueIds(this.achievements, 'achievements');
    requireUniqueIds(this.prestige.upgrades, 'prestige upgrades');

    for (const m of this.minerals) {
      requireFields(m, ['id', 'name', 'region', 'rarity', 'value', 'weight', 'miningSpeed', 'unlock', 'sprite'], `mineral ${m.id}`);
      if (![m.value, m.weight, m.miningSpeed].every((n) => isFiniteNumber(n) && n > 0)) {
        throw new Error(`mineral ${m.id}: value, weight and miningSpeed must be positive numbers`);
      }
      if (!this.regionMap[m.region]) throw new Error(`mineral ${m.id}: unknown region ${m.region}`);
      for (const table of ['discoveryReward', 'researchPerUnit']) {
        if (!(m.rarity in (this.balance[table] || {}))) throw new Error(`balance.${table} lacks rarity "${m.rarity}"`);
      }
    }
    for (const m of this.machines) {
      requireFields(m, ['id', 'name', 'baseCost', 'growth', 'unlock'], `machine ${m.id}`);
      if (!(m.baseCost > 0) || !(m.growth >= 1)) throw new Error(`machine ${m.id}: invalid cost or growth`);
      if (m.kind === 'support') {
        requireFields(m, ['effect'], `machine ${m.id}`);
        requireFields(m.effect, ['type', 'perLevel', 'display', 'label'], `machine ${m.id} effect`);
        if (!(m.effect.perLevel > 0)) throw new Error(`machine ${m.id}: effect.perLevel must be positive`);
      } else {
        requireFields(m, ['baseRate'], `machine ${m.id}`);
        if (!(m.baseRate > 0)) throw new Error(`machine ${m.id}: invalid rate`);
      }
    }
    for (const u of this.upgrades) {
      requireFields(u, ['id', 'name', 'baseCost', 'growth', 'effect'], `upgrade ${u.id}`);
      requireFields(u.effect, ['type', 'mode', 'perLevel', 'display'], `upgrade ${u.id} effect`);
      if (!(u.baseCost > 0) || !(u.growth >= 1)) throw new Error(`upgrade ${u.id}: invalid cost or growth`);
    }
    for (const w of this.workers) {
      requireFields(w, ['id', 'name', 'baseCost', 'growth', 'upgradeBaseCost', 'upgradeGrowth', 'effect', 'unlock', 'sprite'], `worker ${w.id}`);
      requireFields(w.effect, ['type', 'display'], `worker ${w.id} effect`);
      if (!(w.baseCost > 0) || !(w.growth >= 1) || !(w.upgradeBaseCost > 0) || !(w.upgradeGrowth >= 1)) {
        throw new Error(`worker ${w.id}: invalid cost or growth`);
      }
      if (w.effect.type !== 'autoSell' && !(w.perWorker > 0)) throw new Error(`worker ${w.id}: perWorker must be positive`);
    }
    this.regions.forEach((r, i) => {
      requireFields(r, ['id', 'name', 'unlockCost', 'reward', 'theme'], `region ${r.id}`);
      requireFields(r.theme, ['dirt', 'speck', 'cavern', 'floor', 'frame', 'rock', 'light', 'deco'], `region ${r.id} theme`);
      if (r.id !== i + 1) throw new Error(`regions must be numbered 1..n in order (got ${r.id} at position ${i + 1})`);
    });
    const modes = {};
    for (const t of this.research.techs) {
      requireFields(t, ['id', 'category', 'name', 'description', 'cost', 'requires', 'effect'], `tech ${t.id}`);
      requireFields(t.effect, ['type', 'mode', 'value'], `tech ${t.id} effect`);
      if (!this.research.categories.some((c) => c.id === t.category)) throw new Error(`tech ${t.id}: unknown category`);
      if (!(t.cost > 0)) throw new Error(`tech ${t.id}: invalid cost`);
      for (const req of t.requires) {
        if (!this.techMap[req]) throw new Error(`tech ${t.id}: unknown requirement "${req}"`);
      }
      if (modes[t.effect.type] && modes[t.effect.type] !== t.effect.mode) {
        throw new Error(`effect ${t.effect.type} mixes multiply and add modes`);
      }
      modes[t.effect.type] = t.effect.mode;
    }
    for (const a of this.achievements) {
      requireFields(a, ['id', 'name', 'description', 'stat', 'target', 'reward'], `achievement ${a.id}`);
      if (!(a.target > 0)) throw new Error(`achievement ${a.id}: invalid target`);
    }
    const ps = this.prestige.settings;
    requireFields(ps, ['minRunCoins', 'coreDivisor', 'coreExponent', 'coreScale', 'coreProductionBonus', 'historyLimit'], 'prestige settings');
    if (![ps.minRunCoins, ps.coreDivisor, ps.coreExponent, ps.coreScale].every((n) => isFiniteNumber(n) && n > 0)) {
      throw new Error('prestige settings must be positive numbers');
    }
    for (const u of this.prestige.upgrades) {
      requireFields(u, ['id', 'name', 'description', 'baseCost', 'growth', 'maxLevel', 'effect'], `prestige upgrade ${u.id}`);
      requireFields(u.effect, ['type', 'mode', 'perLevel', 'label'], `prestige upgrade ${u.id} effect`);
      if (!(u.baseCost > 0) || !(u.growth >= 1) || !(u.maxLevel >= 1) || !(u.effect.perLevel > 0)) {
        throw new Error(`prestige upgrade ${u.id}: invalid cost, growth, level cap or effect`);
      }
      if (!['multiply', 'add'].includes(u.effect.mode)) throw new Error(`prestige upgrade ${u.id}: bad mode`);
    }
    if (this.achievements.length < 15) throw new Error('at least 15 achievements are required');
    requireFields(this.balance, ['storage', 'machines', 'mining', 'discoveryReward', 'researchPerUnit', 'achievements'], 'balance');
  }
}
