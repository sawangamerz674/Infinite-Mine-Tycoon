/**
 * Entry point — loads configuration and data, creates the game and the UI.
 */
import { Game } from './core/Game.js';
import { UIManager } from './ui/UIManager.js';
import { DataManager } from './data/DataManager.js';
import { CrazyGamesIntegration } from './integrations/CrazyGamesIntegration.js';
import { configureNumberFormat } from './utils/NumberFormatter.js';
import { assets } from './rendering/AssetLoader.js';
import { registerSprites, createMineralIcon } from './rendering/SpriteRenderer.js';
import { initScreenLayout } from './ui/ScreenLayout.js';

async function loadConfig() {
  const response = await fetch('config/game.config.json');
  if (!response.ok) throw new Error(`Could not load game config (${response.status})`);
  return response.json();
}

async function boot() {
  initScreenLayout();
  try {
    // SDK first (it preloads cloud data), then the loading phase, as the CrazyGames docs advise.
    const platform = new CrazyGamesIntegration();
    await platform.init();
    platform.loadingStart();
    const [config, data] = await Promise.all([loadConfig(), DataManager.load()]);
    configureNumberFormat(config.numberFormat?.suffixes);
    const game = new Game(config, data, platform);
    game.init(document.getElementById('mine-canvas'));
    // Console access for development only (localhost or ?debug), not in the released game.
    const dev = ['localhost', '127.0.0.1'].includes(location.hostname) || new URLSearchParams(location.search).has('debug');
    if (dev) window.game = game;
    platform.attach(game);
    game.save.load();
    registerSprites(data);
    try { await Promise.all([document.fonts.load('700 12px "Pixelify Sans"'), document.fonts.load('600 16px Nunito')]); } catch { /* fallback fonts are fine */ }
    const bar = document.getElementById('load-bar');
    await assets.preload((p) => { if (bar) bar.style.width = `${Math.round(p * 100)}%`; });
    await assets.loadImages(config.assets?.overrides);
    const gems = document.getElementById('menu-gems');
    data.minerals.forEach((m, i) => {
      const icon = createMineralIcon(m, 'menu-gem');
      icon.style.animationDelay = `${i * 0.18}s`;
      gems.append(icon);
    });
    document.getElementById('load-wrap')?.setAttribute('hidden', '');
    new UIManager(game);
    game.advisor.probe(); // optional Foreman tips; stays hidden when the server is absent
    platform.loadingStop();
  } catch (err) {
    console.error(err);
    const menu = document.getElementById('main-menu');
    const msg = document.createElement('p');
    msg.className = 'tagline';
    msg.textContent = 'Failed to start. Serve this folder from a local web server (see README).';
    menu.append(msg);
    document.getElementById('btn-play').disabled = true;
  }
}

/** Installable / offline support for web and Play Store (TWA) builds; skipped inside portal iframes. */
function registerServiceWorker() {
  const secure = location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname);
  if (!('serviceWorker' in navigator) || !secure || window.self !== window.top) return;
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}

registerServiceWorker();
boot();
