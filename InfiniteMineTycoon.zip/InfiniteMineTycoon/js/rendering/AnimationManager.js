/**
 * AnimationManager — one place for animation timing.
 *  - A global, player-configurable speed (settings.animationSpeed) that scales
 *    every purely visual clock, so slowing animations never changes the economy.
 *  - Frame-based sprite animations: define a clip (frame names + fps) and read
 *    the current frame from the shared clock.
 *  - Tweens with easing for one-shot effects (banners, pops, fades).
 * Gameplay timers (production, auto-sell, treasure) never use this class.
 */
export const EASING = {
  linear: (t) => t,
  easeOut: (t) => 1 - (1 - t) * (1 - t),
  easeIn: (t) => t * t,
  easeInOut: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
  backOut: (t) => 1 + 2.70158 * Math.pow(t - 1, 3) + 1.70158 * Math.pow(t - 1, 2),
  bounce: (t) => Math.abs(Math.sin(t * Math.PI * 2.5)) * (1 - t),
};

export class AnimationManager {
  constructor() {
    this.speed = 1;
    this.time = 0; // scaled visual clock in seconds
    this.clips = new Map();
    this.tweens = [];
  }

  /** Sets the global speed multiplier (clamped to 0.25..2). */
  setSpeed(value) {
    this.speed = Number.isFinite(value) ? Math.min(2, Math.max(0.25, value)) : 1;
  }

  /** Converts a real frame delta to a visual delta and advances tweens. */
  step(dt) {
    const scaled = Math.max(0, dt) * this.speed;
    this.time += scaled;
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      tw.elapsed += scaled;
      const t = Math.min(1, tw.elapsed / tw.duration);
      tw.onUpdate?.(EASING[tw.easing](t), t);
      if (t >= 1) {
        this.tweens.splice(i, 1);
        tw.onDone?.();
      }
    }
    return scaled;
  }

  /** Registers a looping or one-shot clip: { frames: [...], fps, loop }. */
  defineClip(name, { frames, fps = 8, loop = true }) {
    if (!Array.isArray(frames) || frames.length === 0) throw new Error(`clip ${name}: needs frames`);
    this.clips.set(name, { frames, fps, loop });
  }

  /** Current frame of a clip; `offset` desynchronises copies of one clip. */
  frame(name, offset = 0) {
    const clip = this.clips.get(name);
    if (!clip) return undefined;
    const index = Math.floor((this.time + offset) * clip.fps);
    const last = clip.frames.length - 1;
    return clip.frames[clip.loop ? index % clip.frames.length : Math.min(index, last)];
  }

  /** Smooth 0..1..0 pulse used for glows and blinking arrows. */
  pulse(period = 1.2, offset = 0) {
    return (Math.sin(((this.time + offset) / period) * Math.PI * 2) + 1) / 2;
  }

  /** Runs a tween; onUpdate(eased, linear) is called every step. */
  tween({ duration = 0.5, easing = 'easeOut', onUpdate, onDone }) {
    const tw = { duration: Math.max(0.01, duration), easing: EASING[easing] ? easing : 'linear', elapsed: 0, onUpdate, onDone };
    this.tweens.push(tw);
    return tw;
  }

  clearTweens() {
    this.tweens.length = 0;
  }
}
