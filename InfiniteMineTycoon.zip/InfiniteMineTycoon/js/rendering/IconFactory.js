/**
 * IconFactory — original 16x16 pixel-art icons for machines, upgrades and
 * research categories, drawn in code and cached by AssetLoader. Shown in the UI
 * as crisp, integer-scaled <img> elements (image-rendering: pixelated).
 */
import { assets } from './AssetLoader.js';

const O = '#1b120c'; // outline
const STEEL = ['#c3c9d4', '#8a909c', '#5d6370'];
const GOLD = ['#fff2a8', '#ffd23f', '#d9981a'];
const TIER = {
  basic_miner: ['#f0c15a', '#d99a2b', '#9a6414'],
  advanced_miner: ['#ff9a5c', '#e0662a', '#a03e14'],
  conveyor_belt: ['#7fd0ff', '#3f9ad6', '#256a9c'],
  mining_elevator: ['#9be09b', '#4fb25a', '#2c7a38'],
  drill_machine: ['#ff7a6e', '#c0392b', '#7d2018'],
  ore_processor: ['#c79bff', '#8e44ad', '#5a2a74'],
  heavy_drill: ['#ff7a6e', '#c0392b', '#7d2018'],
  industrial_excavator: ['#ffe27a', '#f2b51d', '#b57d0c'],
  crystal_extractor: ['#8cf0e0', '#16a085', '#0c6a58'],
  advanced_robot: ['#c79bff', '#8e44ad', '#5a2a74'],
};

function ctxOf(draw) {
  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 16;
  const ctx = canvas.getContext('2d');
  const r = (x, y, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };
  draw(r);
  return canvas;
}

/** Filled box with outline, highlight and shadow. */
function box(r, x, y, w, h, [hi, mid, lo]) {
  r(x - 1, y - 1, w + 2, h + 2, O);
  r(x, y, w, h, mid);
  r(x, y, w, 1, hi);
  r(x, y + h - 1, w, 1, lo);
}

const pick = (r) => { // pickaxe
  r(3, 3, 9, 2, O); r(4, 4, 7, 1, STEEL[0]); r(2, 5, 2, 2, O); r(11, 5, 2, 2, O);
  r(7, 4, 2, 10, O); r(7, 5, 1, 8, '#b07a45'); r(8, 5, 1, 8, '#7a4f2a');
  r(3, 4, 1, 1, STEEL[1]); r(12, 4, 1, 1, STEEL[1]);
};
const gear = (r, c = GOLD) => {
  r(6, 1, 4, 14, O); r(1, 6, 14, 4, O); r(3, 3, 10, 10, O);
  r(7, 2, 2, 12, c[1]); r(2, 7, 12, 2, c[1]); r(4, 4, 8, 8, c[1]);
  r(5, 5, 6, 6, c[0]); r(6, 6, 4, 4, O); r(7, 7, 2, 2, c[2]);
};
const helmet = (r) => {
  r(3, 4, 10, 8, O); r(4, 3, 8, 2, O);
  r(4, 4, 8, 4, GOLD[1]); r(4, 4, 8, 1, GOLD[0]); r(7, 2, 2, 3, GOLD[0]);
  r(4, 8, 8, 3, '#f0c294'); r(5, 9, 2, 1, O); r(9, 9, 2, 1, O); r(3, 8, 10, 1, GOLD[2]);
};
const gem = (r, c = ['#bfe8ff', '#5fb4ec', '#2f7fb5']) => {
  r(4, 3, 8, 1, O); r(2, 4, 12, 1, O); r(1, 5, 14, 3, O); r(2, 8, 12, 1, O); r(4, 9, 8, 1, O); r(6, 10, 4, 1, O); r(7, 11, 2, 1, O);
  r(5, 4, 6, 1, c[0]); r(3, 5, 10, 3, c[1]); r(3, 5, 4, 1, c[0]); r(4, 8, 8, 1, c[2]); r(6, 9, 4, 1, c[2]); r(7, 10, 2, 1, c[2]);
};

const ICONS = {
  // ---- machines ----
  basic_miner: (r) => { const t = TIER.basic_miner; box(r, 3, 6, 8, 7, t); r(5, 8, 2, 2, O); r(9, 3, 3, 1, O); r(10, 3, 1, 5, '#b07a45'); r(8, 2, 3, 2, STEEL[0]); r(4, 13, 6, 2, O); },
  advanced_miner: (r) => { const t = TIER.advanced_miner; box(r, 3, 5, 9, 8, t); r(5, 7, 2, 2, O); r(8, 7, 2, 2, GOLD[0]); r(7, 1, 2, 3, O); r(7, 2, 2, 2, STEEL[1]); r(4, 13, 8, 2, O); },
  conveyor_belt: (r) => { const t = TIER.conveyor_belt; box(r, 1, 9, 14, 4, ['#4a4f5c', '#33363f', '#1f2128']); r(2, 10, 12, 1, t[0]); for (const x of [2, 7, 12]) r(x, 12, 2, 2, STEEL[0]); box(r, 3, 4, 4, 4, ['#a8a8b8', '#6e7380', '#4a4f5c']); box(r, 9, 5, 3, 3, ['#ffb06a', '#d98a2b', '#9a5a14']); },
  mining_elevator: (r) => { const t = TIER.mining_elevator; r(2, 1, 2, 14, O); r(12, 1, 2, 14, O); r(2, 1, 1, 14, STEEL[1]); r(12, 1, 1, 14, STEEL[1]); box(r, 4, 6, 8, 7, t); r(5, 8, 6, 3, O); r(6, 9, 1, 1, t[0]); r(9, 9, 1, 1, t[0]); r(7, 1, 2, 5, O); },
  drill_machine: (r) => { const t = TIER.drill_machine; box(r, 2, 2, 12, 6, t); r(4, 4, 2, 2, O); r(7, 9, 2, 1, O); r(5, 8, 6, 2, O); r(6, 8, 4, 1, STEEL[0]); r(6, 10, 4, 2, STEEL[1]); r(7, 12, 2, 2, STEEL[2]); r(7, 14, 2, 1, O); },
  ore_processor: (r) => { const t = TIER.ore_processor; box(r, 2, 6, 11, 8, t); r(10, 1, 3, 5, O); r(11, 2, 1, 4, STEEL[1]); r(4, 8, 4, 4, O); r(5, 9, 2, 2, GOLD[1]); r(9, 9, 3, 1, t[0]); r(9, 11, 3, 1, t[0]); },
  heavy_drill: (r) => { const t = TIER.heavy_drill; box(r, 1, 3, 14, 6, t); r(3, 5, 3, 2, O); r(10, 5, 3, 2, O); r(5, 9, 6, 2, O); r(4, 9, 8, 1, STEEL[0]); r(5, 10, 6, 2, STEEL[1]); r(6, 12, 4, 2, STEEL[2]); r(7, 14, 2, 1, O); },
  industrial_excavator: (r) => { const t = TIER.industrial_excavator; box(r, 1, 9, 12, 5, ['#4a4f5c', '#33363f', '#1f2128']); box(r, 3, 5, 6, 5, t); r(4, 6, 3, 2, '#9fe0ff'); r(9, 3, 5, 2, O); r(10, 3, 3, 1, t[1]); r(12, 4, 3, 5, O); r(13, 5, 1, 3, STEEL[0]); },
  crystal_extractor: (r) => { const t = TIER.crystal_extractor; r(1, 12, 14, 3, O); r(2, 12, 12, 2, t[2]); r(2, 2, 2, 10, O); r(12, 2, 2, 10, O); r(2, 2, 12, 2, O); r(3, 2, 10, 1, t[0]); r(6, 5, 4, 1, O); r(5, 6, 6, 5, O); r(6, 6, 4, 4, t[0]); r(7, 5, 2, 1, '#fff'); r(8, 7, 1, 3, t[1]); },
  advanced_robot: (r) => { const t = TIER.advanced_robot; r(7, 1, 2, 2, O); r(7, 1, 2, 1, GOLD[1]); box(r, 3, 3, 10, 6, t); r(5, 5, 2, 2, '#7fffd4'); r(9, 5, 2, 2, '#7fffd4'); box(r, 4, 10, 8, 4, ['#a8a8b8', '#6e7380', '#4a4f5c']); r(1, 10, 2, 4, O); r(13, 10, 2, 4, O); r(1, 10, 1, 3, STEEL[1]); r(14, 10, 1, 3, STEEL[1]); },
  // ---- upgrades ----
  pickaxe_power: pick,
  mining_speed: (r) => { r(8, 1, 4, 1, O); r(6, 2, 6, 1, O); r(4, 3, 7, 1, O); r(4, 4, 6, 3, O); r(7, 7, 6, 1, O); r(6, 8, 6, 2, O); r(4, 10, 6, 1, O); r(3, 11, 5, 2, O); r(5, 13, 3, 1, O); r(9, 2, 3, 1, GOLD[0]); r(7, 3, 3, 2, GOLD[1]); r(5, 4, 4, 2, GOLD[1]); r(8, 7, 4, 1, GOLD[1]); r(7, 8, 4, 1, GOLD[1]); r(5, 9, 4, 1, GOLD[2]); r(4, 11, 3, 1, GOLD[2]); },
  machine_production: (r) => gear(r, STEEL),
  conveyor_speed: (r) => { box(r, 1, 10, 14, 3, ['#4a4f5c', '#33363f', '#1f2128']); for (const x of [2, 7, 12]) r(x, 13, 2, 1, STEEL[0]); for (const x of [2, 7]) { r(x, 4, 5, 1, O); r(x + 3, 3, 1, 3, O); r(x + 4, 4, 1, 1, O); r(x, 5, 4, 1, '#7fd0ff'); r(x + 1, 4, 3, 1, '#7fd0ff'); } for (const x of [2, 7]) { r(x, 6, 5, 3, O); r(x + 1, 7, 3, 1, '#3f9ad6'); } },
  worker_efficiency: helmet,
  selling_value: (r) => { r(4, 2, 8, 12, O); r(2, 4, 12, 8, O); r(3, 3, 10, 10, O); r(4, 3, 8, 10, GOLD[1]); r(3, 4, 10, 8, GOLD[1]); r(4, 3, 8, 1, GOLD[0]); r(3, 4, 1, 8, GOLD[0]); r(7, 5, 2, 6, O); r(6, 6, 4, 1, O); r(6, 9, 4, 1, O); r(5, 4, 1, 1, GOLD[0]); },
  storage_capacity: (r) => { box(r, 2, 4, 12, 10, ['#c28a52', '#9a6a36', '#6a4522']); r(2, 7, 12, 1, '#6a4522'); r(2, 11, 12, 1, '#6a4522'); r(7, 4, 2, 10, '#6a4522'); r(7, 8, 2, 2, GOLD[1]); r(3, 2, 10, 2, O); r(4, 2, 8, 1, '#c28a52'); },
  automation_efficiency: (r) => { r(5, 1, 6, 1, O); r(3, 2, 10, 2, O); r(2, 4, 12, 8, O); r(3, 12, 10, 2, O); r(5, 14, 6, 1, O); r(4, 3, 8, 11, '#f3e6d3'); r(3, 5, 10, 6, '#f3e6d3'); r(7, 4, 2, 5, O); r(8, 8, 3, 2, O); r(7, 5, 1, 3, '#c24a4a'); r(3, 5, 1, 6, '#c9b99f'); },
  // ---- research categories ----
  'cat:mining': pick,
  'cat:machines': (r) => gear(r),
  'cat:transport': (r) => { box(r, 1, 6, 12, 6, ['#a8a8b8', '#6e7380', '#4a4f5c']); r(2, 4, 10, 2, O); r(3, 4, 8, 1, '#ffb06a'); r(2, 11, 4, 4, O); r(10, 11, 4, 4, O); r(3, 12, 2, 2, STEEL[0]); r(11, 12, 2, 2, STEEL[0]); },
  'cat:discovery': (r) => gem(r),
  'cat:workers': helmet,
};

/** Returns an <img> for an icon id, or null when the id has no icon. */
export function iconImage(id, className = 'card-icon') {
  const draw = ICONS[id];
  if (!draw) return null;
  const canvas = assets.getOrBuild(`icon:${id}`, () => ctxOf(draw));
  const img = document.createElement('img');
  img.className = className;
  img.alt = '';
  img.draggable = false;
  img.src = canvas.toDataURL();
  return img;
}

export function hasIcon(id) {
  return id in ICONS;
}

export const ICON_IDS = Object.keys(ICONS);
