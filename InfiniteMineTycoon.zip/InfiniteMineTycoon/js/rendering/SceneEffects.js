/**
 * SceneEffects — the extra visual layer of the mine scene: the hidden
 * treasure room, glowing rare minerals, machine-upgrade pulses, ambient
 * embers and dust, region-unlock showers and milestone banners.
 * MineRenderer owns one instance and calls update / drawScene / drawOverlay.
 */
import { formatNumber } from '../utils/NumberFormatter.js';

const VIEW_W = 192;
const ROOM = { x: 70, y: 30, w: 30, h: 17 }; // treasure room carved into the rock above the cavern
const CHEST = { x: 79, y: 37 };
const HIT_PAD = 7;
const GLOW_ALPHA = { rare: 0.28, epic: 0.38, legendary: 0.5 };

/** Where each machine sits in the scene (for upgrade pulses). */
const MACHINE_POS = {
  basic_miner: [140, 92], advanced_miner: [100, 62], conveyor_belt: [96, 106],
  mining_elevator: [21, 70], drill_machine: [44, 66], ore_processor: [148, 40],
  heavy_drill: [134, 66], industrial_excavator: [174, 66], crystal_extractor: [174, 86],
  advanced_robot: [174, 106],
};
const TORCHES = [[47, 66], [149, 66]];

export class SceneEffects {
  constructor(game, particles, bus, { rockX, floorY, flecks }) {
    this.game = game;
    this.particles = particles;
    this.rockX = rockX;
    this.floorY = floorY;
    this.flecks = flecks;
    this.time = 0;
    this.pulses = [];
    this.banner = null; // { text, sub, color, t }
    this.chestFade = 0; // 0..1 visibility of the treasure room
    this.chestOpen = 0; // chest lid animation after opening
    this.emberTimer = 0;
    this.dustTimer = 0;
    this.sparkTimer = 0;
    bus.on('machinePurchased', (e) => this.onMachine(e));
    bus.on('regionUnlocked', (e) => this.onRegionUnlocked(e));
    bus.on('milestoneReached', (e) => this.onMilestone(e));
    bus.on('treasureOpened', (e) => this.onTreasure(e));
    bus.on('stateReplaced', () => { this.pulses.length = 0; this.banner = null; });
  }

  // ---- events -----------------------------------------------------------------------

  onMachine({ id, count, level }) {
    const pos = MACHINE_POS[id];
    if (!pos) return;
    const every = this.game.data.balance.machines.milestoneEvery;
    const milestone = Math.floor(level / every) > Math.floor((level - count) / every);
    const color = milestone ? '#ffd23f' : '#9fe8ff';
    this.pulses.push({ x: pos[0], y: pos[1], t: 0, color, big: milestone });
    this.particles.emit({
      x: pos[0], y: pos[1], count: milestone ? 30 : 10, speed: milestone ? 70 : 40,
      angle: -Math.PI / 2, spread: Math.PI * 1.3, life: 0.9, size: 1, gravity: 30,
      colors: [color, '#ffffff', '#ffb02e'],
    });
    this.particles.floatText(milestone ? 'x2 OUTPUT!' : `LV ${level}`, pos[0], pos[1] - 12, color);
    if (milestone) this.showBanner('MACHINE MILESTONE', 'Output doubled', '#ffd23f');
  }

  onRegionUnlocked({ region }) {
    const t = region.theme;
    const colors = [t.dirt[3], t.speck[1], t.crystalColor?.[0] || t.decoColor || '#ffffff', '#ffffff'];
    for (let i = 0; i < 6; i++) {
      this.particles.emit({
        x: 20 + i * 30, y: 20, count: 14, speed: 30, angle: Math.PI / 2, spread: 0.6,
        life: 1.4, size: 2, gravity: 90, colors,
      });
    }
    this.showBanner('REGION UNLOCKED', region.name, '#7ad87a');
  }

  onMilestone({ label }) {
    this.showBanner('MILESTONE!', `${label} EARNED`, '#ffd23f');
    for (let i = 0; i < 5; i++) {
      this.particles.emit({
        x: 25 + i * 35, y: 40, count: 16, speed: 60, angle: -Math.PI / 2, spread: Math.PI * 1.4,
        life: 1.2, size: 2, gravity: 60, colors: ['#ffd23f', '#fff0a0', '#ff9d2e', '#ffffff'],
      });
    }
  }

  onTreasure({ type, amount, mineral }) {
    this.chestOpen = 1;
    const cx = CHEST.x + 6;
    this.particles.emit({
      x: cx, y: CHEST.y, count: 36, speed: 70, angle: -Math.PI / 2, spread: Math.PI * 1.4,
      life: 1.2, size: 2, gravity: 80,
      colors: type === 'cache' ? [mineral.sprite.main, mineral.sprite.light, '#ffffff'] : ['#ffd23f', '#fff0a0', '#ffb300'],
    });
    const text = type === 'coins' ? `+${formatNumber(amount)} COINS`
      : type === 'research' ? `+${formatNumber(amount)} RP`
        : `+${formatNumber(amount)} ${mineral.name.toUpperCase()}`;
    this.particles.floatText(text, cx, CHEST.y - 12, '#ffffff');
  }

  showBanner(text, sub, color) {
    this.banner = { text, sub, color, t: 0 };
  }

  // ---- update -------------------------------------------------------------------------

  update(dt, theme) {
    this.time += dt;
    const active = !!this.game.treasure.active;
    this.chestFade = Math.min(1, Math.max(0, this.chestFade + (active ? dt * 2.5 : -dt * 3)));
    this.chestOpen = Math.max(0, this.chestOpen - dt * 1.5);
    if (this.banner && (this.banner.t += dt) > 2.6) this.banner = null;
    for (const p of this.pulses) p.t += dt;
    this.pulses = this.pulses.filter((p) => p.t < 0.8);

    this.emberTimer += dt;
    if (this.emberTimer > 0.3) {
      this.emberTimer = 0;
      const [x, y] = TORCHES[Math.floor(Math.random() * TORCHES.length)];
      this.particles.emit({
        x: x + 1, y: y - 10, count: 1, speed: 6, angle: -Math.PI / 2, spread: 0.8, life: 1.4,
        size: 1, gravity: -8, colors: ['#ff9d2e', '#ffd23f', '#ff7a1a'],
      });
    }
    this.dustTimer += dt;
    if (this.dustTimer > 0.9) {
      this.dustTimer = 0;
      this.particles.emit({
        x: 40 + Math.random() * 110, y: 62 + Math.random() * 40, count: 1, speed: 3,
        angle: Math.random() * Math.PI * 2, spread: 0.5, life: 3.2, size: 1, gravity: 0,
        colors: [`rgb(${theme.light})`],
      });
    }
    if (this.chestFade > 0.5) {
      this.sparkTimer += dt;
      if (this.sparkTimer > 0.25) {
        this.sparkTimer = 0;
        this.particles.emit({
          x: CHEST.x + 3 + Math.random() * 10, y: CHEST.y - 1, count: 1, speed: 8,
          angle: -Math.PI / 2, spread: 1, life: 0.9, size: 1, gravity: -6, colors: ['#fff0a0', '#ffd23f'],
        });
      }
    }
  }

  // ---- input --------------------------------------------------------------------------

  hitTreasure(x, y) {
    return x >= ROOM.x - HIT_PAD && x <= ROOM.x + ROOM.w + HIT_PAD
      && y >= ROOM.y - HIT_PAD && y <= ROOM.y + ROOM.h + HIT_PAD;
  }

  // ---- drawing ------------------------------------------------------------------------

  /** Treasure room, rare-mineral glow and machine pulses (under the lighting pass). */
  drawScene(ctx) {
    this.drawTreasure(ctx);
    this.drawGlow(ctx);
    this.drawPulses(ctx);
  }

  rect(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  }

  drawTreasure(ctx) {
    const treasure = this.game.treasure.active;
    if (this.chestFade <= 0.01) return;
    const a = this.chestFade;
    // Blink during the last 5 seconds so the player knows it is closing.
    const blink = treasure && treasure.life < 5 && Math.floor(this.time * 6) % 2 === 0 ? 0.45 : 1;
    ctx.save();
    ctx.globalAlpha = a * blink;
    const { x, y, w, h } = ROOM;
    this.rect(ctx, x, y, w, h, '#0f0a07');
    this.rect(ctx, x, y, w, 2, '#5a3a1e');
    this.rect(ctx, x, y, 2, h, '#7a4f2a');
    this.rect(ctx, x + w - 2, y, 2, h, '#7a4f2a');
    this.rect(ctx, x, y + h - 1, w, 1, '#5a3a1e');
    // Warm glow pooling on the floor of the room.
    const g = ctx.createRadialGradient(CHEST.x + 6, CHEST.y + 4, 1, CHEST.x + 6, CHEST.y + 4, 20);
    g.addColorStop(0, 'rgba(255,210,63,0.55)');
    g.addColorStop(1, 'rgba(255,210,63,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);

    // Chest (lid rises when opened).
    const lift = Math.round(this.chestOpen * 3);
    this.rect(ctx, CHEST.x, CHEST.y + 4, 12, 7, '#8a5a2b');
    this.rect(ctx, CHEST.x, CHEST.y + 4, 12, 1, '#b07a3c');
    this.rect(ctx, CHEST.x + 5, CHEST.y + 4, 2, 7, '#ffd23f');
    this.rect(ctx, CHEST.x - 1, CHEST.y + 8, 14, 1, '#c9a227');
    this.rect(ctx, CHEST.x + 1, CHEST.y + 1 - lift, 10, 3, '#9a6a33');
    this.rect(ctx, CHEST.x + 2, CHEST.y - lift, 8, 1, '#9a6a33');
    this.rect(ctx, CHEST.x + 5, CHEST.y + 1 - lift, 2, 3, '#ffd23f');
    this.rect(ctx, CHEST.x + 5, CHEST.y + 6, 2, 2, '#fff0a0');
    // Bouncing arrow pointing at the chest.
    if (treasure) {
      const bob = Math.round(Math.sin(this.time * 6) * 1.5);
      this.rect(ctx, CHEST.x + 5, ROOM.y - 6 + bob, 2, 3, '#ffd23f');
      this.rect(ctx, CHEST.x + 4, ROOM.y - 3 + bob, 4, 1, '#ffd23f');
      // Time-left bar.
      const f = treasure.life / treasure.total;
      this.rect(ctx, ROOM.x + 2, ROOM.y + h + 1, w - 4, 2, '#000000');
      this.rect(ctx, ROOM.x + 2, ROOM.y + h + 1, Math.round((w - 4) * f), 2, '#ffd23f');
    }
    ctx.restore();
  }

  /** Pulsing glow on the rock's flecks for rare, epic and legendary minerals. */
  drawGlow(ctx) {
    const minerals = this.game.regions.mineralsOf(this.game.state.currentRegion);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    this.flecks.forEach(([dx, dy], i) => {
      const m = minerals[i % minerals.length];
      const alpha = GLOW_ALPHA[m.rarity];
      if (!alpha || i % 3 === 0) return;
      const pulse = 0.65 + 0.35 * Math.sin(this.time * 2.4 + i * 1.7);
      const cx = this.rockX + dx + 1;
      const cy = this.floorY + dy + 1;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 8);
      g.addColorStop(0, hexA(m.sprite.light, alpha * pulse));
      g.addColorStop(1, hexA(m.sprite.light, 0));
      ctx.fillStyle = g;
      ctx.fillRect(cx - 8, cy - 8, 16, 16);
    });
    ctx.restore();
  }

  drawPulses(ctx) {
    for (const p of this.pulses) {
      const k = p.t / 0.8;
      const r = 4 + k * (p.big ? 22 : 12);
      ctx.save();
      ctx.globalAlpha = 1 - k;
      ctx.strokeStyle = p.color;
      ctx.lineWidth = p.big ? 2 : 1;
      ctx.strokeRect(Math.round(p.x - r), Math.round(p.y - r), Math.round(r * 2), Math.round(r * 2));
      ctx.restore();
    }
  }

  /** Large banner for milestones, region unlocks and machine milestones (above lighting). */
  drawOverlay(ctx) {
    const b = this.banner;
    if (!b) return;
    const k = b.t / 2.6;
    const alpha = k < 0.1 ? k / 0.1 : k > 0.8 ? (1 - k) / 0.2 : 1;
    const y = 18 + (k < 0.1 ? (1 - k / 0.1) * -8 : 0);
    ctx.save();
    ctx.globalAlpha = Math.max(0, alpha);
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(0, y - 9, VIEW_W, 24);
    ctx.fillStyle = b.color;
    ctx.fillRect(0, y - 9, VIEW_W, 1);
    ctx.fillRect(0, y + 14, VIEW_W, 1);
    ctx.textAlign = 'center';
    ctx.font = '700 11px "Pixelify Sans", monospace';
    ctx.fillStyle = '#14100c';
    ctx.fillText(b.text, VIEW_W / 2 + 1, y + 3);
    ctx.fillStyle = b.color;
    ctx.fillText(b.text, VIEW_W / 2, y + 2);
    ctx.font = '700 8px "Pixelify Sans", monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(b.sub, VIEW_W / 2, y + 12);
    ctx.restore();
  }
}

/** '#rrggbb' + alpha -> 'rgba(...)'. */
function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
