/**
 * CanvasRenderer — owns the <canvas>, handles DPI-aware sizing and maps
 * the fixed virtual resolution onto the screen with integer scaling so
 * pixel art stays crisp.
 */
export class CanvasRenderer {
  constructor(canvas, viewWidth, viewHeight) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.viewWidth = viewWidth;
    this.viewHeight = viewHeight;
    this.scale = 1;
    this.backdrop = null; // optional canvas stretched behind the scene (fills letterbox bars)
    this.offsetX = 0;
    this.offsetY = 0;
    this.resize();
    if (typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(() => this.resize()).observe(canvas.parentElement || canvas);
    }
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.floor(this.canvas.clientWidth * dpr));
    const h = Math.max(1, Math.floor(this.canvas.clientHeight * dpr));
    if (this.canvas.width !== w) this.canvas.width = w;
    if (this.canvas.height !== h) this.canvas.height = h;
    // Integer scaling keeps every virtual pixel the same size (no shimmer or uneven pixels);
    // leftover space is filled by the blurred region backdrop. Tiny screens fall back to fitting.
    const fit = Math.min(w / this.viewWidth, h / this.viewHeight);
    this.scale = fit >= 1 ? Math.floor(fit) : fit;
    this.offsetX = Math.floor((w - this.viewWidth * this.scale) / 2);
    this.offsetY = Math.floor((h - this.viewHeight * this.scale) / 2);
  }

  /** Starts a frame; drawing afterwards happens in virtual pixel units. */
  begin() {
    const { ctx, canvas } = this;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#0d0907';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (this.backdrop && (this.offsetX > 0 || this.offsetY > 0)) {
      ctx.imageSmoothingEnabled = true;
      ctx.globalAlpha = 0.5;
      ctx.drawImage(this.backdrop, 0, 0, canvas.width, canvas.height);
      ctx.globalAlpha = 1;
      ctx.imageSmoothingEnabled = false;
    }
    ctx.save();
    ctx.setTransform(this.scale, 0, 0, this.scale, this.offsetX, this.offsetY);
    ctx.beginPath();
    ctx.rect(0, 0, this.viewWidth, this.viewHeight);
    ctx.clip();
    return ctx;
  }

  end() {
    this.ctx.restore();
  }

  /** Converts client (page) coordinates to virtual view coordinates. */
  toVirtual(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    const px = (clientX - rect.left) * (this.canvas.width / rect.width);
    const py = (clientY - rect.top) * (this.canvas.height / rect.height);
    return { x: (px - this.offsetX) / this.scale, y: (py - this.offsetY) / this.scale };
  }
}
