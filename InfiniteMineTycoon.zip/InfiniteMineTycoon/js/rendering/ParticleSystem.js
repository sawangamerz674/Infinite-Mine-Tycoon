/**
 * ParticleSystem — small pixel particles (rock chips, coin sparks) and
 * floating text such as "+12".
 */
export class ParticleSystem {
  constructor(max = 400) {
    this.max = max;
    this.items = [];
    this.quality = 1; // particle count multiplier (display setting)
    this.showText = true; // floating numbers (display setting)
  }

  emit({
    x, y, count = 1, speed = 40, angle = -Math.PI / 2, spread = Math.PI * 2,
    life = 0.6, size = 2, gravity = 140, colors = ['#ffd23f'],
  }) {
    const n = this.quality <= 0 ? 0 : Math.ceil(count * this.quality);
    for (let i = 0; i < n; i++) {
      if (this.items.length >= this.max) this.items.shift();
      const a = angle + (Math.random() - 0.5) * spread;
      const s = speed * (0.4 + Math.random() * 0.8);
      this.items.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, gravity,
        life, maxLife: life, size,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
  }

  floatText(text, x, y, color = '#ffd23f') {
    if (!this.showText) return;
    if (this.items.length >= this.max) this.items.shift();
    this.items.push({ x, y, vx: 0, vy: -22, gravity: 0, life: 0.9, maxLife: 0.9, text, color });
  }

  update(dt) {
    for (const p of this.items) {
      p.life -= dt;
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    this.items = this.items.filter((p) => p.life > 0);
  }

  draw(ctx) {
    ctx.save();
    for (const p of this.items) {
      ctx.globalAlpha = Math.min(1, (p.life / p.maxLife) * 1.5);
      if (p.text) {
        ctx.font = '700 8px "Pixelify Sans", monospace';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#1a0f08';
        ctx.fillText(p.text, Math.round(p.x) + 1, Math.round(p.y) + 1);
        ctx.fillStyle = p.color;
        ctx.fillText(p.text, Math.round(p.x), Math.round(p.y));
      } else {
        ctx.fillStyle = p.color;
        ctx.fillRect(Math.round(p.x), Math.round(p.y), p.size, p.size);
      }
    }
    ctx.restore();
  }
}
