/**
 * MachineVisuals — pixel-art for the machines:
 * Drill Machine (left wall), Heavy Drill (right wall), Conveyor Belt (floor),
 * Mining Elevator (shaft left of the cavern) and Ore Processor (surface
 * plant with smoking chimney), plus the three side-tunnel machines of the
 * deeper regions: Industrial Excavator, Crystal Extractor and Advanced
 * Mining Robot. Each one is drawn only once owned, speeds up
 * with its level and changes colour with every milestone tier.
 * Producing machines pause while storage is full.
 */
const TIER_COLORS = ['#e0a526', '#e06a26', '#c0392b', '#8e44ad', '#16a085'];
const BELT_FROM = 30;
const BELT_TO = 150;
const BELT_Y = 111;

export class MachineVisuals {
  constructor(game, particles) {
    this.game = game;
    this.particles = particles;
    this.drillSpin = 0;
    this.heavySpin = 0;
    this.beltOffset = 0;
    this.cagePhase = 0;
    this.smokeTimer = 0;
    this.sparkTimer = 0;
    this.time = 0;
    this.digPhase = 0;
    this.pylonPhase = 0;
    this.robotPhase = 0;
  }

  level(id) {
    return this.game.state.machines[id] || 0;
  }

  color(id) {
    return TIER_COLORS[Math.min(TIER_COLORS.length - 1, this.game.machines.tier(id))];
  }

  /** Animation speed grows with level but stays readable. */
  speed(id, base) {
    return base + Math.min(8, Math.log2(1 + this.level(id)) * 1.6);
  }

  update(dt) {
    this.time += dt;
    const running = !this.game.production.storageFull;

    if (this.level('drill_machine') > 0 && running) {
      this.drillSpin += dt * this.speed('drill_machine', 8);
      this.sparkTimer += dt;
      if (this.sparkTimer > 0.18) {
        this.sparkTimer = 0;
        this.chips(76, 63, 0);
      }
    }
    if (this.level('heavy_drill') > 0 && running) {
      this.heavySpin += dt * this.speed('heavy_drill', 6);
      if (Math.random() < dt * 5) this.chips(112, 63, Math.PI);
    }
    if (this.level('conveyor_belt') > 0) {
      this.beltOffset = (this.beltOffset + dt * this.speed('conveyor_belt', 10)) % 1000;
    }
    if (this.level('mining_elevator') > 0) {
      this.cagePhase += dt * this.speed('mining_elevator', 0.5) * 0.35;
    }
    if (this.level('industrial_excavator') > 0 && running) {
      this.digPhase += dt * this.speed('industrial_excavator', 2);
      if (Math.sin(this.digPhase) > 0.97 && Math.random() < 0.5) this.chips(186, 70, Math.PI);
    }
    if (this.level('crystal_extractor') > 0 && running) this.pylonPhase += dt * this.speed('crystal_extractor', 2);
    if (this.level('advanced_robot') > 0 && running) this.robotPhase += dt * this.speed('advanced_robot', 3);
    if (this.level('ore_processor') > 0 && running) {
      this.smokeTimer += dt;
      if (this.smokeTimer > 0.35) {
        this.smokeTimer = 0;
        this.particles.emit({
          x: 148, y: 3, count: 1, speed: 7, angle: -Math.PI / 2, spread: 0.7,
          life: 1.3, size: 2, gravity: -5, colors: ['#aab0ba', '#8a909a', '#c9ccd4'],
        });
      }
    }
  }

  chips(x, y, angle) {
    this.particles.emit({
      x, y, count: 2, speed: 28, angle, spread: 1.6, life: 0.4, size: 1,
      colors: ['#ffd23f', '#fff0a0', '#c9ccd4'],
    });
  }

  rect(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), w, h);
  }

  /** Elevator, conveyor and processor: drawn behind the torches and rock. */
  drawBack(ctx) {
    this.drawElevator(ctx);
    this.drawConveyor(ctx);
    this.drawProcessor(ctx);
    this.drawSideTunnels(ctx);
  }

  /** Drills: drawn in front of the cavern wall. */
  drawFront(ctx) {
    this.drawDrill(ctx, 'drill_machine', { x: 40, y: 56, dir: 1, spin: this.drillSpin, size: 1 });
    this.drawDrill(ctx, 'heavy_drill', { x: 134, y: 54, dir: -1, spin: this.heavySpin, size: 1.3 });
  }

  drawDrill(ctx, id, { x, y, dir, spin, size }) {
    if (this.level(id) <= 0) return;
    const color = this.color(id);
    const r = (rx, ry, w, h, c) => {
      // rx is measured from the machine's back; dir flips it for the right wall.
      const px = dir === 1 ? x + rx : x + 18 - rx - w;
      this.rect(ctx, px, ry, w, h, c);
    };
    const h = Math.round(14 * size);
    r(0, y, 18, h, color);
    r(0, y, 18, 2, '#ffffff44');
    r(2, y + 4, 4, 4, '#14100c');
    r(10, y + 4, 4, 4, this.game.production.storageFull ? '#6b2a2a' : '#7dff9a');
    r(0, y + h - 2, 18, 2, '#00000055');
    const mid = y + Math.round(h / 2) - 2;
    r(18, mid, 8, 4, '#8a909a');
    // Spinning bit: alternating stripes slide along the cone.
    for (let i = 0; i < 5; i++) {
      const bw = 3;
      const bh = Math.max(2, Math.round((8 - i * 1.5) * size));
      const stripe = (i + Math.floor(spin)) % 2 === 0;
      r(26 + i * bw, mid + 2 - Math.round(bh / 2), bw, bh, stripe ? '#c9ccd4' : '#7a808a');
    }
  }

  drawConveyor(ctx) {
    if (this.level('conveyor_belt') <= 0) return;
    const w = BELT_TO - BELT_FROM;
    this.rect(ctx, BELT_FROM - 2, BELT_Y - 3, 10, 8, '#2a1c14'); // tunnel mouth
    this.rect(ctx, BELT_FROM, BELT_Y, w, 4, '#2b2b30');
    this.rect(ctx, BELT_FROM, BELT_Y, w, 1, '#555560');
    for (let i = 0; i < 24; i++) {
      const x = BELT_FROM + ((i * 6 - this.beltOffset % 6 + 600) % w);
      this.rect(ctx, x, BELT_Y + 2, 2, 1, '#6a6a76');
    }
    this.rect(ctx, BELT_FROM - 1, BELT_Y - 1, 4, 6, '#444450');
    this.rect(ctx, BELT_TO - 2, BELT_Y - 1, 4, 6, '#444450');
    // Ore chunks riding the belt toward the elevator.
    const minerals = this.game.minerals.available();
    const chunkColor = (k) => minerals[k % Math.max(1, minerals.length)]?.sprite.main ?? '#8a8b96';
    for (let k = 0; k < 5; k++) {
      const x = BELT_TO - ((this.beltOffset * 1.2 + k * 24) % w);
      this.rect(ctx, x, BELT_Y - 3, 3, 3, chunkColor(k));
      this.rect(ctx, x, BELT_Y - 3, 1, 1, '#ffffff66');
    }
  }

  drawElevator(ctx) {
    if (this.level('mining_elevator') <= 0) return;
    const color = this.color('mining_elevator');
    this.rect(ctx, 12, 22, 20, 3, '#5a3a1e');
    this.rect(ctx, 14, 28, 16, 88, '#14100c');
    this.rect(ctx, 16, 28, 1, 88, '#555560');
    this.rect(ctx, 27, 28, 1, 88, '#555560');
    const t = (Math.sin(this.cagePhase) + 1) / 2;
    const cageY = 30 + Math.round(t * 72);
    this.rect(ctx, 21, 28, 1, cageY - 28, '#8a909a');
    this.rect(ctx, 17, cageY, 10, 12, color);
    this.rect(ctx, 17, cageY, 10, 2, '#ffffff44');
    this.rect(ctx, 19, cageY + 3, 6, 6, '#241711');
    this.rect(ctx, 20, cageY + 4, 1, 4, '#7dff9a');
    this.rect(ctx, 23, cageY + 4, 1, 4, '#7dff9a');
    this.rect(ctx, 17, cageY + 10, 10, 2, '#00000055');
  }

  drawProcessor(ctx) {
    if (this.level('ore_processor') <= 0) return;
    const color = this.color('ore_processor');
    const lit = !this.game.production.storageFull;
    this.rect(ctx, 144, 2, 6, 8, '#555560');
    this.rect(ctx, 144, 2, 6, 2, '#6a6a76');
    this.rect(ctx, 122, 8, 32, 3, '#8a3a2a');
    this.rect(ctx, 124, 11, 28, 13, '#6b5a4a');
    this.rect(ctx, 124, 11, 28, 2, '#8a7560');
    this.rect(ctx, 128, 14, 8, 6, lit ? '#ffd23f' : '#3a2a1c');
    this.rect(ctx, 130, 14, 1, 6, '#14100c');
    this.rect(ctx, 140, 14, 8, 8, color);
    // Spinning gear on the machine face.
    const frame = Math.floor(this.time * 6) % 2;
    this.rect(ctx, 143, 17, 2, 2, '#14100c');
    this.rect(ctx, frame ? 142 : 143, frame ? 18 : 16, frame ? 4 : 2, frame ? 1 : 5, '#14100c');
    this.rect(ctx, 151, 12, 2, 2, lit ? '#7dff9a' : '#6b2a2a');
  }
}

// ---- side tunnels (region-gated machines) -----------------------------------------

MachineVisuals.prototype.tunnel = function tunnel(ctx, y) {
  this.rect(ctx, 160, y, 30, 17, '#120c08');
  this.rect(ctx, 160, y, 30, 1, '#5a3a1e');
  this.rect(ctx, 160, y + 16, 30, 1, '#5a3a1e');
  this.rect(ctx, 189, y, 1, 17, '#3a2a1c');
};

MachineVisuals.prototype.drawSideTunnels = function drawSideTunnels(ctx) {
  this.drawExcavator(ctx, 58);
  this.drawExtractor(ctx, 78);
  this.drawRobot(ctx, 98);
};

MachineVisuals.prototype.drawExcavator = function drawExcavator(ctx, y) {
  if (this.level('industrial_excavator') <= 0) return;
  this.tunnel(ctx, y);
  const color = this.color('industrial_excavator');
  const moving = !this.game.production.storageFull;
  this.rect(ctx, 162, y + 12, 20, 4, '#2b2b30');
  for (let i = 0; i < 5; i++) {
    const x = 163 + ((i * 4 + (moving ? Math.floor(this.digPhase * 4) : 0)) % 18);
    this.rect(ctx, x, y + 13, 2, 1, '#6a6a76');
  }
  this.rect(ctx, 164, y + 6, 14, 7, color);
  this.rect(ctx, 164, y + 6, 14, 2, '#ffffff44');
  this.rect(ctx, 166, y + 2, 7, 5, color);
  this.rect(ctx, 168, y + 3, 4, 3, '#9fe8ff');
  // Arm: boom and bucket swing toward the tunnel face.
  const a = -0.35 + Math.sin(this.digPhase) * 0.45;
  const px = 177;
  const py = y + 7;
  for (let i = 0; i <= 9; i++) {
    this.rect(ctx, px + Math.cos(a) * i, py + Math.sin(a) * i, 2, 2, '#c9ccd4');
  }
  const bx = px + Math.cos(a) * 9;
  const by = py + Math.sin(a) * 9;
  this.rect(ctx, bx, by, 4, 4, '#8a909a');
  this.rect(ctx, bx + 3, by + 1, 1, 3, '#ffd23f');
};

MachineVisuals.prototype.drawExtractor = function drawExtractor(ctx, y) {
  if (this.level('crystal_extractor') <= 0) return;
  this.tunnel(ctx, y);
  const color = this.color('crystal_extractor');
  const moving = !this.game.production.storageFull;
  const pulse = moving ? (Math.sin(this.pylonPhase) + 1) / 2 : 0.1;
  this.rect(ctx, 165, y + 4, 3, 11, '#8a909a');
  this.rect(ctx, 182, y + 4, 3, 11, '#8a909a');
  this.rect(ctx, 164, y + 2, 5, 3, color);
  this.rect(ctx, 181, y + 2, 5, 3, color);
  ctx.save();
  ctx.globalAlpha = 0.25 + pulse * 0.6;
  this.rect(ctx, 168, y + 3, 14, 1, '#9fe8ff');
  this.rect(ctx, 168, y + 8, 14, 1, '#9dffc0');
  ctx.restore();
  const grow = 5 + Math.round(pulse * 3);
  for (const [dx, h, c1, c2] of [[171, grow + 2, '#9fe8ff', '#ffffff'], [175, grow + 5, '#2fcf6e', '#9dffc0'], [179, grow, '#9fe8ff', '#ffffff']]) {
    this.rect(ctx, dx, y + 15 - h, 3, h, c1);
    this.rect(ctx, dx, y + 15 - h, 1, Math.min(3, h), c2);
  }
  this.rect(ctx, 166, y + 15, 18, 1, '#555560');
};

MachineVisuals.prototype.drawRobot = function drawRobot(ctx, y) {
  if (this.level('advanced_robot') <= 0) return;
  this.tunnel(ctx, y);
  const color = this.color('advanced_robot');
  const moving = !this.game.production.storageFull;
  const swing = moving ? Math.sin(this.robotPhase) : 0;
  const blink = moving && Math.floor(this.time * 3) % 6 !== 0;
  this.rect(ctx, 170, y + 11, 3, 5, '#555560');
  this.rect(ctx, 177, y + 11, 3, 5, '#555560');
  this.rect(ctx, 168, y + 4, 14, 8, color);
  this.rect(ctx, 168, y + 4, 14, 2, '#ffffff44');
  this.rect(ctx, 171, y + 6, 3, 3, '#14100c');
  this.rect(ctx, 176, y + 6, 3, 3, '#14100c');
  this.rect(ctx, 171, y + 7, 3, 1, blink ? '#7dff9a' : '#14100c');
  this.rect(ctx, 176, y + 7, 3, 1, blink ? '#7dff9a' : '#14100c');
  this.rect(ctx, 174, y + 1, 2, 3, '#8a909a');
  this.rect(ctx, 173, y, 4, 2, blink ? '#e0314b' : '#6b2a2a');
  // Arms with drills swinging at the wall.
  const armY = y + 6 + Math.round(swing * 2);
  this.rect(ctx, 163, armY, 5, 2, '#8a909a');
  this.rect(ctx, 160, armY - 1, 3, 4, '#c9ccd4');
  this.rect(ctx, 182, armY, 5, 2, '#8a909a');
  this.rect(ctx, 186, armY - 1, 3, 4, '#c9ccd4');
};
