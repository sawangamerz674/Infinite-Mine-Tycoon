/**
 * AssetLoader — central cache for every drawable asset.
 *  - Procedural assets: factories registered per key build a canvas once
 *    (mineral sprites, worker portraits, region backgrounds, glows).
 *  - Optional external images: a manifest { key: 'path.png' } can override a
 *    procedural asset; missing files fall back silently to the procedural one,
 *    so the game never depends on binary art files.
 *  - preload() builds everything up front and reports progress, so the first
 *    frames never stall on lazy generation.
 */
export class AssetLoader {
  constructor() {
    this.factories = new Map();
    this.cache = new Map();
    this.overrides = new Map();
  }

  /** Registers (or replaces) the factory that builds an asset canvas. */
  register(key, factory) {
    this.factories.set(key, factory);
    this.cache.delete(key);
  }

  has(key) {
    return this.cache.has(key) || this.factories.has(key);
  }

  /** Returns the asset, building it on first use. External overrides win. */
  get(key) {
    if (this.overrides.has(key)) return this.overrides.get(key);
    if (!this.cache.has(key)) {
      const factory = this.factories.get(key);
      if (!factory) throw new Error(`Unknown asset: ${key}`);
      this.cache.set(key, factory());
    }
    return this.cache.get(key);
  }

  /** Get-or-register helper for assets that are created on demand. */
  getOrBuild(key, factory) {
    if (!this.has(key)) this.register(key, factory);
    return this.get(key);
  }

  /** Loads optional image overrides; resolves with the number that loaded. */
  async loadImages(manifest = {}, onProgress = () => {}) {
    const entries = Object.entries(manifest);
    let done = 0;
    let loaded = 0;
    await Promise.all(entries.map(([key, src]) => new Promise((resolve) => {
      const img = new Image();
      img.onload = () => { this.overrides.set(key, img); loaded += 1; resolve(); };
      img.onerror = () => resolve(); // keep the procedural asset
      img.src = src;
    }).then(() => onProgress(++done / entries.length))));
    return loaded;
  }

  /** Builds every registered asset; onProgress receives 0..1. */
  async preload(onProgress = () => {}) {
    const keys = [...this.factories.keys()];
    let done = 0;
    for (const key of keys) {
      this.get(key);
      done += 1;
      onProgress(done / keys.length);
      // Yield so the loading bar can paint between batches.
      if (done % 8 === 0) await new Promise((r) => requestAnimationFrame(() => r()));
    }
    onProgress(1);
  }

  get size() {
    return this.factories.size;
  }
}

/** Shared instance used by the renderer and the UI. */
export const assets = new AssetLoader();
