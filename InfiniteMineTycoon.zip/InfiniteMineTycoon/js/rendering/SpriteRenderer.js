/**
 * SpriteRenderer — generates the 8x8 pixel-art mineral sprites from small
 * character maps and the colours in minerals.json, and caches them.
 * Character key: L light, M main, D dark, F fleck (ore minerals use
 * o/l/d for the surrounding rock).
 */
const SHAPES = {
  ore: [
    '..oooo..',
    '.oloFFo.',
    'oloFFooo',
    'ooFFooFo',
    'ooooFFoo',
    'oFooloFo',
    'ddooooDd',
    '.dddddd.',
  ],
  gem: [
    '..LMMD..',
    '.LLMMMD.',
    'LLMMMMDD',
    'MMMMMMMD',
    '.DMMMMD.',
    '..DMMD..',
    '...DD...',
    '........',
  ],
  emerald: [
    '.LLLLLD.',
    'LMMMMMMD',
    'LMLLLLMD',
    'LMLMMLMD',
    'LMLMMLMD',
    'LMLLLLMD',
    'LMMMMMMD',
    '.DDDDDD.',
  ],
  crystal: [
    '...LL...',
    '..LMMD..',
    '..LMMD..',
    '.LLMMDD.',
    '.LMMMMD.',
    '.LMMMMD.',
    '..DMMD..',
    '..DDDD..',
  ],
};

const ROCK = { o: '#73747e', l: '#9a9ba5', d: '#4b4c55' };
import { assets } from './AssetLoader.js';

const dataUrl = (asset) => (asset.toDataURL ? asset.toDataURL() : asset.src);

function build(sprite) {
  const rows = SHAPES[sprite.shape] || SHAPES.ore;
  const palette = {
    ...ROCK, L: sprite.light, M: sprite.main, D: sprite.dark, F: sprite.main,
  };
  const canvas = document.createElement('canvas');
  canvas.width = 8;
  canvas.height = 8;
  const ctx = canvas.getContext('2d');
  rows.forEach((row, y) => {
    [...row].forEach((ch, x) => {
      if (ch === '.') return;
      ctx.fillStyle = palette[ch];
      ctx.fillRect(x, y, 1, 1);
    });
  });
  return canvas;
}

/** Cached 8x8 canvas for a mineral definition. */
export function getMineralSprite(mineral) {
  return assets.getOrBuild(`mineral:${mineral.id}`, () => build(mineral.sprite));
}

const WORKER_ROWS = [
  '..hhhh..',
  '.hhhhhh.',
  '..ssss..',
  '..sksk..',
  '..ssss..',
  '.bbbbbb.',
  'bbbaabbb',
  'bb.aa.bb',
];

function buildWorker(sprite) {
  const palette = { h: sprite.hat, s: '#f0c294', k: '#2a1c14', b: sprite.shirt, a: sprite.accent };
  const canvas = document.createElement('canvas');
  canvas.width = 8;
  canvas.height = 8;
  const ctx = canvas.getContext('2d');
  WORKER_ROWS.forEach((row, y) => [...row].forEach((ch, x) => {
    if (ch === '.') return;
    ctx.fillStyle = palette[ch];
    ctx.fillRect(x, y, 1, 1);
  }));
  return canvas;
}

/** Cached 8x8 canvas for a worker definition (hat, shirt, accent colours). */
export function getWorkerSprite(worker) {
  return assets.getOrBuild(`worker:${worker.id}`, () => buildWorker(worker.sprite));
}

/** Registers every mineral and worker sprite so AssetLoader.preload() can build them. */
export function registerSprites(data) {
  for (const m of data.minerals) assets.register(`mineral:${m.id}`, () => build(m.sprite));
  for (const w of data.workers) assets.register(`worker:${w.id}`, () => buildWorker(w.sprite));
}

/** An <img> portrait for a worker definition (hat, shirt, accent colours). */
export function createWorkerPortrait(worker, className = 'worker-portrait') {
  const canvas = getWorkerSprite(worker);
  const img = document.createElement('img');
  img.className = className;
  img.alt = worker.name;
  img.src = dataUrl(canvas);
  return img;
}

/** An <img> element showing the mineral sprite, crisp at any size. */
export function createMineralIcon(mineral, className = 'mineral-icon') {
  const img = document.createElement('img');
  img.className = className;
  img.alt = mineral.name;
  img.src = dataUrl(getMineralSprite(mineral));
  return img;
}
