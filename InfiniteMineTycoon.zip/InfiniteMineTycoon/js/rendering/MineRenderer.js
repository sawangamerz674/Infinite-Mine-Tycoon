/**
 * MineRenderer — draws the mine scene in a 192x128 virtual pixel space.
 * Each region has its own theme (data/regions.json): background tiles,
 * decorations, ore flecks, rock colours, lighting and twinkles. Backgrounds
 * are pre-rendered once per region to offscreen canvases. Also draws the
 * player's miner, the hired miner and drill rig, region-transition banners
 * and mineral-discovery effects; machine artwork lives in MachineVisuals.
 */
import { ParticleSystem } from './ParticleSystem.js';
import { MachineVisuals } from './MachineVisuals.js';
import { SceneEffects } from './SceneEffects.js';
import { AnimationManager } from './AnimationManager.js';
import { assets } from './AssetLoader.js';
import { formatNumber } from '../utils/NumberFormatter.js';

export const VIEW_W = 192;
export const VIEW_H = 128;

const FLOOR_Y = 108;
const ROCK_X = 100;
const ROCK_W = 20; // half-width at the base
const ROCK_H = 28;
const MINER_X = 60;
const HIRED_X = 140;
const TORCHES = [{ x: 46, y: 76 }, { x: 148, y: 76 }];
const FLECK_POS = [[-10, -6], [6, -12], [-4, -18], [10, -4], [-14, -3], [0, -9]];
const CRACKS = [
  [0, -26], [1, -23], [-1, -20], [-3, -17], [2, -19], [4, -16],
  [-4, -14], [5, -12], [-2, -11], [7, -9], [-7, -9], [0, -7],
];
const SHIRTS = ['#c0392b', '#8e44ad', '#16a085', '#d35400', '#2c3e50'];
const HELMETS = ['#ffd23f', '#ff9d2e', '#ff7a7a', '#d4b0ff', '#8ff0ff'];
const RIG_COLORS = ['#e0a526', '#e06a26', '#c0392b', '#8e44ad', '#16a085'];

const hash = (x, y) => {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return (h ^ (h >>> 16)) >>> 0;
};
const lerp = (a, b, t) => a + (b - a) * t;
/** True when a point lies inside the cavern, elevator shaft or side tunnels. */
const inBuiltArea = (x, y) => (x >= 30 && x <= 192 && y >= 48)
  || (x >= 10 && x <= 32 && y >= 20);

export class MineRenderer {
  constructor(game, bus) {
    this.game = game;
    this.time = 0;
    this.swingT = 1; // player swing animation 0..1, 1 = at rest
    this.flash = 0;
    this.shake = 0;
    this.hiredSwing = 1;
    this.hiredTimer = 0;
    this.rigPhase = 0;
    this.rigStruck = false;
    this.fullWarnAt = -10;
    this.transitionT = 1; // region banner/fade 0..1, 1 = finished
    this.transitionName = '';
    this.anim = new AnimationManager();
    this.particles = new ParticleSystem();
    this.visuals = new MachineVisuals(game, this.particles);
    this.fx = new SceneEffects(game, this.particles, bus, { rockX: ROCK_X, floorY: FLOOR_Y, flecks: FLECK_POS });
    this.shakeOn = true;
    this.applySettings();
    bus.on('settingsChanged', () => this.applySettings());
    bus.on('mined', (e) => this.onMined(e));
    bus.on('sold', (e) => this.onSold(e));
    bus.on('storageFull', () => this.onStorageFull());
    bus.on('mineralDiscovered', (e) => this.onDiscovery(e));
    bus.on('regionChanged', (e) => this.onRegionChanged(e));
    bus.on('prestiged', (e) => this.onPrestige(e));
  }

  /** Applies the display settings (particle amount, floating text, screen shake). */
  applySettings() {
    const st = this.game.settings;
    this.particles.quality = { low: 0.4, normal: 1, high: 1.6 }[st.get('particles')] ?? 1;
    this.particles.showText = st.get('floatingText');
    this.shakeOn = st.get('screenShake');
    this.anim.setSpeed(st.get('animationSpeed'));
  }

  get region() {
    return this.game.regions.current;
  }

  get theme() {
    return this.region.theme;
  }

  getBackground() {
    const id = this.region.id;
    return assets.getOrBuild(`background:${id}`, () => this.buildBackground(this.region));
  }

  // ---- background -----------------------------------------------------------

  buildBackground(region) {
    const t = region.theme;
    const canvas = document.createElement('canvas');
    canvas.width = VIEW_W;
    canvas.height = VIEW_H;
    const c = canvas.getContext('2d');
    const rect = (x, y, w, h, color) => { c.fillStyle = color; c.fillRect(x, y, w, h); };
    const minerals = this.game.regions.mineralsOf(region.id);
    const flecks = minerals.map((m) => m.sprite.main);

    if (t.sky) {
      rect(0, 0, VIEW_W, 8, t.sky[0]);
      rect(0, 8, VIEW_W, 8, t.sky[1]);
      rect(0, 16, VIEW_W, 10, t.sky[2]);
      rect(166, 4, 10, 10, '#ffe27a');
      rect(168, 2, 6, 14, '#ffe27a');
      rect(100, 6, 18, 4, '#ffffff');
      rect(104, 3, 10, 4, '#ffffff');
      // Wooden head-frame above the shaft.
      rect(26, 6, 3, 20, '#7a4f2a');
      rect(46, 6, 3, 20, '#7a4f2a');
      rect(24, 4, 26, 3, '#5a3a1e');
      rect(33, 8, 9, 9, '#3a2a1c');
      rect(35, 10, 5, 5, '#8a8b96');
      rect(0, 24, VIEW_W, 1, '#7ad87a');
      rect(0, 25, VIEW_W, 3, '#4aa34a');
    } else {
      // Underground ceiling with stalactites and a stone ledge.
      rect(0, 0, VIEW_W, 28, t.cavern[0]);
      rect(0, 0, VIEW_W, 12, t.cavern[1]);
      if (t.deco.includes('stalactites')) {
        for (let x = 2; x < VIEW_W; x += 7) {
          const h = hash(x, region.id);
          const len = 5 + (h % 12);
          for (let i = 0; i < len; i++) {
            const w = Math.max(1, Math.round(((len - i) / len) * 5));
            rect(x - Math.floor(w / 2), i, w, 1, t.dirt[(i + h) % 4]);
          }
        }
      }
      rect(0, 24, VIEW_W, 4, t.floor[0]);
      rect(0, 24, VIEW_W, 1, t.speck[1]);
    }

    // Dirt tiles with speckles, ore flecks and veins/runes.
    for (let ty = 28; ty < VIEW_H; ty += 8) {
      for (let tx = 0; tx < VIEW_W; tx += 8) {
        const h = hash(tx, ty);
        rect(tx, ty, 8, 8, t.dirt[h % t.dirt.length]);
        for (let i = 0; i < 3; i++) {
          const sh = hash(tx + i * 13, ty + i * 7);
          rect(tx + (sh % 7), ty + ((sh >>> 4) % 7), 2, 1, i % 2 ? t.speck[0] : t.speck[1]);
        }
        if (flecks[0] && h % 17 === 0) rect(tx + 2, ty + 3, 2, 2, flecks[0]);
        if (flecks[1] && h % 29 === 1) rect(tx + 4, ty + 2, 2, 2, flecks[1]);
        if (t.deco.includes('veins') && h % 7 === 3) {
          for (let i = 0; i < 5; i++) rect(tx + 1 + i, ty + 5 - i, 1, 1, t.decoColor);
        }
        if (t.deco.includes('runes') && h % 11 === 4) this.drawRune(c, tx + 2, ty + 2, h, t.decoColor);
      }
    }

    // Cavern cut-out, floor tiles and timber/metal frame.
    rect(36, 56, 120, 60, t.cavern[0]);
    rect(36, 56, 120, 20, t.cavern[1]);
    rect(36, 96, 120, 12, t.cavern[2]);
    for (let tx = 36; tx < 156; tx += 8) {
      for (let ty = FLOOR_Y; ty < 116; ty += 4) {
        rect(tx, ty, 8, 4, t.floor[hash(tx, ty) % 3]);
      }
    }
    rect(36, FLOOR_Y, 120, 1, t.speck[1]);
    rect(33, 50, 6, 66, t.frame[0]);
    rect(33, 50, 2, 66, t.frame[1]);
    rect(153, 50, 6, 66, t.frame[0]);
    rect(153, 50, 2, 66, t.frame[1]);
    rect(32, 48, 128, 6, t.frame[2]);
    rect(32, 48, 128, 2, t.frame[3]);

    // Crystal clusters on the dirt around the cavern.
    if (t.deco.includes('crystals')) {
      const [main, light] = t.crystalColor || [t.decoColor, '#ffffff'];
      for (const [x, y] of [[60, 47], [112, 47], [140, 47], [6, 70], [4, 112], [166, 118], [184, 52]]) {
        this.drawCrystals(c, x, y, main, light);
      }
    }
    return canvas;
  }

  drawCrystals(c, x, y, main, light) {
    const spikes = [[0, 9], [3, 6], [-3, 7]];
    for (const [dx, h] of spikes) {
      c.fillStyle = main;
      c.fillRect(x + dx, y - h, 2, h);
      c.fillStyle = light;
      c.fillRect(x + dx, y - h, 1, Math.min(3, h));
    }
  }

  drawRune(c, x, y, h, color) {
    const shapes = [
      [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]],
      [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]],
      [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]],
    ];
    c.fillStyle = color;
    for (const [dx, dy] of shapes[h % shapes.length]) c.fillRect(x + dx, y + dy, 1, 1);
  }

  /** Fixed positions for ambient twinkles, outside the built areas. */
  twinklePoints(regionId) {
    if (!this.twinkleCache) this.twinkleCache = {};
    if (!this.twinkleCache[regionId]) {
      const pts = [];
      for (let i = 0; pts.length < 14 && i < 200; i++) {
        const h = hash(i * 31 + regionId, i * 17);
        const x = h % VIEW_W;
        const y = 4 + ((h >>> 8) % 120);
        if (!inBuiltArea(x, y)) pts.push({ x, y, phase: (h % 100) / 16 });
      }
      this.twinkleCache[regionId] = pts;
    }
    return this.twinkleCache[regionId];
  }

  // ---- input / events -------------------------------------------------------

  /** True when a virtual-space point should count as a hit on the rock. */
  hitTest(x, y) {
    return x >= 48 && x <= ROCK_X + ROCK_W + 16
      && y >= FLOOR_Y - ROCK_H - 16 && y <= FLOOR_Y + 8;
  }

  mineralColors(id) {
    const s = this.game.minerals.byId[id]?.sprite;
    return s ? { main: s.light, accent: s.main } : { main: '#ffd23f', accent: '#ffd23f' };
  }

  chipColors() {
    const r = this.theme.rock;
    return [r.top, r.mid, r.dark];
  }

  onMined({ units, burst, x, y, mineralId }) {
    this.swingT = 0;
    this.shake = this.shakeOn ? 1 : 0;
    this.flash = burst ? 1 : 0.5;
    const col = this.mineralColors(mineralId);
    const cx = ROCK_X;
    const cy = FLOOR_Y - ROCK_H / 2;
    this.particles.emit({
      x: cx, y: cy, count: burst ? 26 : 6, speed: burst ? 70 : 45,
      angle: -Math.PI / 2, spread: Math.PI * 1.2, life: 0.7, size: 2,
      colors: [...this.chipColors(), col.main, col.accent],
    });
    const tx = Number.isFinite(x) ? x : cx;
    const ty = Number.isFinite(y) ? y : FLOOR_Y - ROCK_H - 4;
    const name = this.game.minerals.byId[mineralId]?.name ?? '';
    const amount = Math.max(1, Math.round(units));
    this.particles.floatText(
      `${burst ? 'BONUS ' : ''}+${formatNumber(amount)} ${name}`.trim(),
      Math.min(Math.max(tx, 34), VIEW_W - 34), Math.max(ty - 6, 12),
      burst ? '#ff9d2e' : col.main,
    );
  }

  onSold({ coins, auto }) {
    this.particles.emit({
      x: ROCK_X, y: FLOOR_Y - ROCK_H - 4, count: auto ? 6 : 16, speed: 60,
      angle: -Math.PI / 2, spread: Math.PI, life: 0.9, size: 2, gravity: 170,
      colors: ['#ffd23f', '#fff0a0', '#ffb300'],
    });
    this.particles.floatText(
      `${auto ? 'AUTO ' : 'SOLD '}+${formatNumber(Math.floor(coins))}`,
      ROCK_X, FLOOR_Y - ROCK_H - 14, auto ? '#9dffc0' : '#ffd23f',
    );
  }

  onStorageFull() {
    if (this.time - this.fullWarnAt < 0.6) return;
    this.fullWarnAt = this.time;
    this.particles.floatText('STORAGE FULL', ROCK_X, FLOOR_Y - ROCK_H - 8, '#ff6b6b');
  }

  /** Big celebratory burst the first time a mineral is found. */
  onDiscovery({ mineral, reward }) {
    const col = mineral.sprite;
    this.flash = 1;
    this.particles.emit({
      x: ROCK_X, y: FLOOR_Y - ROCK_H, count: 44, speed: 95, angle: -Math.PI / 2,
      spread: Math.PI * 1.6, life: 1.1, size: 2, gravity: 90,
      colors: [col.main, col.light, '#ffffff'],
    });
    this.particles.floatText(`DISCOVERED: ${mineral.name.toUpperCase()}!`, ROCK_X, 34, col.light);
    if (reward > 0) this.particles.floatText(`+${formatNumber(reward)} RP`, ROCK_X, 46, '#7fd0ff');
  }

  onPrestige({ cores }) {
    this.flash = 1;
    this.particles.emit({
      x: ROCK_X, y: FLOOR_Y - ROCK_H, count: 60, speed: 110, angle: -Math.PI / 2,
      spread: Math.PI * 2, life: 1.4, size: 2, gravity: 40,
      colors: ['#b57cff', '#e0c8ff', '#ffffff'],
    });
    this.particles.floatText(`+${formatNumber(cores)} ANCIENT CORES`, ROCK_X, 40, '#d6b3ff');
  }

  onRegionChanged({ region }) {
    this.transitionT = 0;
    this.transitionName = region.name;
    this.particles.items.length = 0;
  }

  // ---- update ---------------------------------------------------------------

  update(realDt) {
    const dt = this.anim.step(realDt); // visual time: scaled by the animation-speed setting
    this.time += dt;
    this.swingT = Math.min(1, this.swingT + dt / 0.18);
    this.flash = Math.max(0, this.flash - dt * 5);
    this.shake = Math.max(0, this.shake - dt * 6);
    this.transitionT = Math.min(1, this.transitionT + dt / 1.1);
    this.game.canvasRenderer.backdrop = this.getBackground();
    this.updateMachines(dt);
    this.visuals.update(dt);
    this.fx.update(dt, this.theme);
    this.particles.update(dt);
  }

  /** Advances the hired-miner and drill-rig animations (and their chips). */
  updateMachines(dt) {
    const machines = this.game.state.machines;
    const producing = !this.game.production.storageFull;

    if (machines.basic_miner > 0) {
      const interval = Math.max(0.3, 1.4 - machines.basic_miner * 0.02);
      if (producing) this.hiredTimer += dt;
      if (this.hiredTimer >= interval) {
        this.hiredTimer = 0;
        this.hiredSwing = 0;
      }
      const before = this.hiredSwing;
      this.hiredSwing = Math.min(1, this.hiredSwing + dt / 0.2);
      if (before < 1 && this.hiredSwing >= 1) this.emitChips(ROCK_X + 16, FLOOR_Y - 14, -0.5, 3);
    }

    if (machines.advanced_miner > 0 && producing) {
      const speed = 3 + Math.min(6, Math.log2(1 + machines.advanced_miner));
      this.rigPhase += dt * speed;
      const down = Math.sin(this.rigPhase) > 0.95;
      if (down && !this.rigStruck) {
        this.rigStruck = true;
        this.emitChips(ROCK_X, FLOOR_Y - ROCK_H, -Math.PI / 2, 4);
      } else if (!down && Math.sin(this.rigPhase) < 0.5) {
        this.rigStruck = false;
      }
    }
  }

  emitChips(x, y, angle, count) {
    this.particles.emit({
      x, y, count, speed: 32, angle, spread: 1.4, life: 0.5, size: 1,
      colors: this.chipColors(),
    });
  }

  // ---- drawing --------------------------------------------------------------

  draw(ctx) {
    ctx.drawImage(this.getBackground(), 0, 0);
    this.drawTwinkles(ctx);
    this.visuals.drawBack(ctx);
    this.drawTorches(ctx);
    this.visuals.drawFront(ctx);
    this.drawRock(ctx);
    this.drawRig(ctx);
    this.fx.drawScene(ctx);
    this.drawWorker(ctx, MINER_X, this.swingT, { phase: 0 });
    const hiredLevel = this.game.state.machines.basic_miner;
    if (hiredLevel > 0) {
      const tier = Math.min(SHIRTS.length - 1, this.game.machines.tier('basic_miner'));
      this.drawWorker(ctx, HIRED_X, this.hiredSwing, {
        mirror: true, shirt: SHIRTS[tier], helmet: HELMETS[tier], phase: 1.7,
      });
    }
    this.particles.draw(ctx);
    this.drawLighting(ctx);
    this.fx.drawOverlay(ctx);
    this.drawTransition(ctx);
  }

  drawTwinkles(ctx) {
    const color = this.theme.twinkle;
    if (!color) return;
    ctx.save();
    ctx.fillStyle = color;
    for (const p of this.twinklePoints(this.region.id)) {
      const a = (Math.sin(this.time * 2.2 + p.phase) + 1) / 2;
      if (a < 0.35) continue;
      ctx.globalAlpha = a;
      ctx.fillRect(p.x, p.y, 1, 1);
      if (a > 0.8) {
        ctx.fillRect(p.x - 1, p.y, 3, 1);
        ctx.fillRect(p.x, p.y - 1, 1, 3);
      }
    }
    ctx.restore();
  }

  drawTorches(ctx) {
    for (const t of TORCHES) {
      const flick = Math.sin(this.time * 9 + t.x) * 0.5 + Math.sin(this.time * 17 + t.x * 2) * 0.5;
      ctx.fillStyle = '#6b4a22';
      ctx.fillRect(t.x, t.y, 2, 10);
      ctx.fillStyle = '#3a2a1c';
      ctx.fillRect(t.x - 1, t.y + 2, 4, 2);
      const h = 4 + Math.round(flick * 1.5);
      ctx.fillStyle = '#ff7a1a';
      ctx.fillRect(t.x - 1, t.y - h, 4, h);
      ctx.fillStyle = '#ffb02e';
      ctx.fillRect(t.x, t.y - h + 1, 2, h - 1);
      ctx.fillStyle = '#ffe27a';
      ctx.fillRect(t.x, t.y - 2, 2, 2);
    }
  }

  drawRock(ctx) {
    const rock = this.theme.rock;
    const sx = Math.round(Math.sin(this.time * 70) * this.shake * 2);
    const cx = ROCK_X + sx;
    ctx.fillStyle = '#0d0907';
    ctx.fillRect(cx - ROCK_W - 3, FLOOR_Y, ROCK_W * 2 + 6, 2);

    const lit = this.flash > 0.3;
    for (let r = 0; r < ROCK_H; r++) {
      const dy = ROCK_H - 1 - r;
      const w = Math.max(2, Math.round(ROCK_W * Math.sqrt(1 - (dy / ROCK_H) ** 2)));
      const y = FLOOR_Y - ROCK_H + r;
      const base = r < 8 ? rock.top : r < 18 ? rock.mid : rock.low;
      ctx.fillStyle = lit ? rock.light : base;
      ctx.fillRect(cx - w, y, w * 2, 1);
      ctx.fillStyle = lit ? '#ffffff' : rock.light;
      ctx.fillRect(cx - w, y, 2, 1);
      ctx.fillStyle = rock.dark;
      ctx.fillRect(cx + w - 3, y, 3, 1);
    }
    // Ore flecks use the colours of this region's minerals.
    const minerals = this.game.regions.mineralsOf(this.region.id);
    FLECK_POS.forEach(([dx, dy], i) => {
      const m = minerals[i % minerals.length];
      ctx.fillStyle = i % 3 === 0 ? rock.dark : m.sprite.main;
      ctx.fillRect(cx + dx, FLOOR_Y + dy, 2, 2);
    });
    const cracks = Math.floor(this.game.rockProgress * CRACKS.length);
    ctx.fillStyle = rock.dark;
    for (let i = 0; i < cracks; i++) {
      ctx.fillRect(cx + CRACKS[i][0], FLOOR_Y + CRACKS[i][1], 1, 3);
    }
  }

  /** Overhead drill rig, shown once an Advanced Miner is owned. */
  drawRig(ctx) {
    const level = this.game.state.machines.advanced_miner;
    if (level <= 0) return;
    const tier = Math.min(RIG_COLORS.length - 1, this.game.machines.tier('advanced_miner'));
    const color = RIG_COLORS[tier];
    const idle = this.game.production.storageFull;
    const offset = idle ? 0 : (Math.sin(this.rigPhase) + 1) / 2;
    const rect = (x, y, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };

    rect(84, 54, 32, 3, '#4a4a52');
    rect(84, 54, 32, 1, '#6a6a76');
    rect(92, 57, 16, 7, color);
    rect(92, 57, 16, 2, '#ffffff33');
    rect(94, 60, 3, 3, '#14100c');
    rect(103, 60, 3, 3, idle ? '#6b2a2a' : '#7dff9a');
    const len = 6 + Math.round(offset * 6);
    rect(98, 64, 4, len, '#9aa0aa');
    const y = 64 + len;
    rect(96, y, 8, 2, '#c9ccd4');
    rect(97, y + 2, 6, 2, '#aab0ba');
    rect(99, y + 4, 2, 2, '#8a909a');
  }

  /** A miner with a swinging pickaxe; mirrored for the hired worker. */
  drawWorker(ctx, x, swingT, { mirror = false, shirt = '#2f6fb5', helmet = '#ffd23f', phase = 0 }) {
    ctx.save();
    ctx.translate(x, 0);
    if (mirror) ctx.scale(-1, 1);
    const rect = (rx, ry, w, h, color) => { ctx.fillStyle = color; ctx.fillRect(rx, ry, w, h); };
    const bob = swingT >= 1 ? Math.round(Math.sin(this.time * 3 + phase) * 0.6) : 0;
    const by = FLOOR_Y + bob;

    rect(-3, by - 6, 2, 6, '#3b3b8a');
    rect(1, by - 6, 2, 6, '#3b3b8a');
    rect(-4, by - 14, 8, 8, shirt);
    rect(-4, by - 8, 8, 1, '#6b4a22');
    rect(-3, by - 19, 6, 5, '#f0c294');
    rect(-4, by - 22, 8, 3, helmet);
    rect(3, by - 21, 2, 2, '#fff6b0');
    rect(-2, by - 17, 1, 1, '#2a1c14');
    rect(1, by - 17, 1, 1, '#2a1c14');

    let angle;
    if (swingT >= 1) angle = -0.55 + Math.sin(this.time * 2 + phase) * 0.08;
    else if (swingT < 0.5) angle = lerp(-0.55, -1.4, swingT * 2);
    else angle = lerp(-1.4, 0.3, (swingT - 0.5) * 2);
    const hx = 6;
    const hy = by - 12;
    rect(3, by - 13, 4, 3, shirt);
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    for (let i = 0; i <= 13; i++) {
      rect(Math.round(hx + cos * i), Math.round(hy + sin * i), 2, 2, '#8a5a2b');
    }
    const tx = hx + cos * 13;
    const ty = hy + sin * 13;
    for (let k = -3; k <= 3; k++) {
      rect(Math.round(tx - sin * k), Math.round(ty + cos * k), 2, 2, '#c9ccd4');
    }
    rect(hx, hy, 2, 2, '#f0c294');
    ctx.restore();
  }

  drawLighting(ctx) {
    const light = this.theme.light;
    ctx.save();
    for (const t of TORCHES) {
      const r = 38 + Math.sin(this.time * 9 + t.x) * 3;
      const g = ctx.createRadialGradient(t.x, t.y - 2, 2, t.x, t.y - 2, r);
      g.addColorStop(0, `rgba(${light},0.30)`);
      g.addColorStop(1, `rgba(${light},0)`);
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = g;
      ctx.fillRect(t.x - r, t.y - r, r * 2, r * 2);
    }
    // Pulsing glow from the rock in the deeper regions.
    if (this.theme.twinkle) {
      const pulse = 0.12 + 0.05 * Math.sin(this.time * 2);
      const g = ctx.createRadialGradient(ROCK_X, FLOOR_Y - 14, 2, ROCK_X, FLOOR_Y - 14, 34);
      g.addColorStop(0, `rgba(${light},${pulse})`);
      g.addColorStop(1, `rgba(${light},0)`);
      ctx.fillStyle = g;
      ctx.fillRect(ROCK_X - 34, FLOOR_Y - 48, 68, 68);
    }
    // Soft light shafts drifting through the cavern.
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 3; i++) {
      const a = 0.035 + 0.025 * Math.sin(this.time * 0.6 + i * 2.1);
      const x = 62 + i * 34 + Math.sin(this.time * 0.25 + i) * 4;
      ctx.fillStyle = `rgba(${light},${a})`;
      ctx.beginPath();
      ctx.moveTo(x, 28);
      ctx.lineTo(x + 9, 28);
      ctx.lineTo(x + 30, FLOOR_Y);
      ctx.lineTo(x + 14, FLOOR_Y);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
    const v = ctx.createRadialGradient(ROCK_X, 80, 30, ROCK_X, 80, 130);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = v;
    ctx.fillRect(0, 28, VIEW_W, VIEW_H - 28);
    ctx.restore();
  }

  /** Fade-in from black with the region name banner. */
  drawTransition(ctx) {
    const t = this.transitionT;
    if (t >= 1) return;
    ctx.save();
    ctx.globalAlpha = Math.pow(1 - t, 1.5);
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    const textAlpha = t < 0.15 ? t / 0.15 : t < 0.7 ? 1 : (1 - t) / 0.3;
    ctx.globalAlpha = Math.max(0, textAlpha);
    ctx.font = '700 12px "Pixelify Sans", monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#14100c';
    ctx.fillText(this.transitionName, VIEW_W / 2 + 1, 41);
    ctx.fillStyle = '#ffd23f';
    ctx.fillText(this.transitionName, VIEW_W / 2, 40);
    ctx.restore();
  }
}
