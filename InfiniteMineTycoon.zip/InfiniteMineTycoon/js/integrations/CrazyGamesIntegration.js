/**
 * CrazyGamesIntegration — the only module that touches the CrazyGames SDK
 * (v3, https://sdk.crazygames.com/crazygames-sdk-v3.js, loaded in index.html).
 *
 * Only documented calls are used:
 *   SDK.init(), SDK.environment ('local' | 'crazygames' | 'disabled'),
 *   SDK.game.loadingStart/loadingStop/gameplayStart/gameplayStop,
 *   SDK.ad.requestAd('midgame' | 'rewarded', { adStarted, adFinished, adError }),
 *   SDK.ad.hasAdblock(), SDK.data.getItem/setItem/removeItem (progress and settings),
 *   SDK.game.settings.muteAudio + SDK.game.addSettingsChangeListener/removeSettingsChangeListener.
 *
 * Without the SDK (own server, blocked script, 'disabled' domain) every method
 * is a safe no-op: no ads, saves stay in LocalStorage, the game plays normally.
 */
const INIT_TIMEOUT_MS = 8000;
const AD_SAFETY_MS = 3 * 60 * 1000; // never leave the game paused if an ad never reports back

export class CrazyGamesIntegration {
  constructor() {
    this.sdk = null;
    this.environment = 'none'; // 'none' | 'local' | 'crazygames' | 'disabled'
    this.active = false; // SDK initialised and usable
    this.adblock = false;
    this.adActive = false;
    this.playing = false;
    this.modalOpen = false;
    this.game = null;
    this.lastAdAt = Date.now(); // no ad in the first minutes of a session
    this.audioMuted = false; // portal-wide mute (SDK game.settings.muteAudio)
    this.settingsListener = null;
  }

  /** Human-readable platform name for the Settings tab. */
  get label() {
    if (this.environment === 'crazygames') return 'CrazyGames';
    if (this.environment === 'local') return 'CrazyGames SDK (local test)';
    return 'Standalone (no SDK)';
  }

  /** Cloud-capable storage for SaveSystem (SDK data module), or null. */
  get storage() {
    if (!this.active) return null;
    const data = this.sdk.data;
    return {
      getItem: (k) => data.getItem(k),
      setItem: (k, v) => data.setItem(k, v),
      removeItem: (k) => data.removeItem(k),
    };
  }

  /** Current value of the portal's mute setting (false without the SDK). */
  readMuteSetting() {
    if (!this.active) return false;
    try {
      return this.sdk.game.settings?.muteAudio === true;
    } catch (err) {
      return false;
    }
  }

  /**
   * CrazyGames can mute games from its own player UI. That setting takes priority over the in-game
   * audio options, so it is applied as its own mute reason which the player's toggles cannot lift.
   */
  bindAudioSetting() {
    const apply = (muted) => {
      this.audioMuted = !!muted;
      this.game.audio.setMuted('platform', this.audioMuted);
      this.game.bus.emit('platformAudioChanged', { muted: this.audioMuted });
    };
    apply(this.readMuteSetting());
    this.settingsListener = (settings) => apply(settings?.muteAudio === true);
    this.safe((s) => s.game.addSettingsChangeListener(this.settingsListener));
  }

  get adsAvailable() {
    return this.active && !this.adblock;
  }

  config(key, fallback) {
    const v = this.game?.config.ads?.[key];
    return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
  }

  safe(fn) {
    if (!this.active) return undefined;
    try {
      return fn(this.sdk);
    } catch (err) {
      console.warn('CrazyGames SDK call failed.', err);
      return undefined;
    }
  }

  /** Initialises the SDK if it loaded. Never rejects. */
  async init() {
    const sdk = window.CrazyGames?.SDK;
    if (!sdk) return;
    try {
      await Promise.race([
        sdk.init(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('SDK init timed out')), INIT_TIMEOUT_MS)),
      ]);
      this.environment = sdk.environment;
    } catch (err) {
      console.warn('CrazyGames SDK could not be initialised.', err);
      return;
    }
    // 'disabled' = unsupported domain: the docs say every SDK call would throw.
    if (this.environment !== 'crazygames' && this.environment !== 'local') return;
    this.sdk = sdk;
    this.active = true;
    try {
      this.adblock = !!(await sdk.ad.hasAdblock());
    } catch (err) {
      this.adblock = false;
    }
  }

  loadingStart() { this.safe((s) => s.game.loadingStart()); }

  loadingStop() { this.safe((s) => s.game.loadingStop()); }

  /** Connects to a game: gameplay events, pause handling and ad breaks. */
  attach(game) {
    this.game = game;
    const { bus } = game;
    this.bindAudioSetting();
    bus.on('started', () => this.refreshGameplay());
    bus.on('pauseChanged', () => this.refreshGameplay()); // hidden tab or ad = a break in gameplay
    bus.on('modalOpened', () => { this.modalOpen = true; this.refreshGameplay(); });
    bus.on('modalClosed', () => { this.modalOpen = false; this.refreshGameplay(); });
    // A completed prestige is a natural break: offer a midgame ad (rate limited).
    bus.on('prestiged', () => setTimeout(() => this.midgameBreak(), 2500));
  }

  /** gameplayStart while the player is actually playing, gameplayStop for menus, dialogs and ads. */
  refreshGameplay() {
    const want = !!this.game?.started && !this.modalOpen && !this.adActive && this.game.pauseReasons.size === 0;
    if (want === this.playing) return;
    this.playing = want;
    this.safe((s) => (want ? s.game.gameplayStart() : s.game.gameplayStop()));
  }

  /**
   * Requests an ad. Resolves { ok: true } when it finished, or
   * { ok: false, code } (adsDisabled, unfilled, adblock, adCooldown, other, unavailable).
   * The game is paused and muted for the duration of the ad.
   */
  requestAd(type) {
    if (!this.adsAvailable) return Promise.resolve({ ok: false, code: this.adblock ? 'adblock' : 'unavailable' });
    if (this.adActive) return Promise.resolve({ ok: false, code: 'other' });
    return new Promise((resolve) => {
      let settled = false;
      let safety = null;
      const finish = (result) => {
        if (settled) return;
        settled = true;
        clearTimeout(safety);
        this.endAd();
        resolve(result);
      };
      try {
        this.sdk.ad.requestAd(type, {
          adStarted: () => {
            this.beginAd();
            safety = setTimeout(() => finish({ ok: false, code: 'other' }), AD_SAFETY_MS);
          },
          adFinished: () => finish({ ok: true }),
          adError: (error) => finish({ ok: false, code: error?.code || 'other' }),
        });
      } catch (err) {
        finish({ ok: false, code: 'other' });
      }
    });
  }

  beginAd() {
    this.adActive = true;
    this.game.setPaused('ad', true);
    this.game.audio.setMuted('ad', true);
    this.refreshGameplay();
  }

  endAd() {
    this.lastAdAt = Date.now();
    if (!this.adActive) return;
    this.adActive = false;
    this.game.setPaused('ad', false);
    this.game.audio.setMuted('ad', false);
    this.refreshGameplay();
  }

  /** Midgame ad at a natural break, at most once per cooldown (default 3 minutes). */
  midgameBreak() {
    const cooldown = this.config('midgameCooldownSeconds', 180) * 1000;
    if (!this.adsAvailable || this.adActive || this.modalOpen) return;
    if (Date.now() - this.lastAdAt < cooldown) return;
    this.requestAd('midgame');
  }
}
