/**
 * MathUtils — exponential cost math and random helpers.
 * Cost of level L is baseCost × growth^L; buying n levels costs the
 * geometric series sum.
 */
export const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

/** Total cost of buying `count` levels starting from `level`. Infinity if it overflows. */
export function geometricCost(baseCost, growth, level, count) {
  if (!(count > 0)) return 0;
  const first = baseCost * Math.pow(growth, level);
  const total = growth === 1 ? first * count : (first * (Math.pow(growth, count) - 1)) / (growth - 1);
  return Number.isFinite(total) ? total : Infinity;
}

/** Largest n (<= cap) whose total cost fits in `budget`. */
export function maxAffordable(baseCost, growth, level, budget, cap = Infinity) {
  if (!(budget > 0) || !(cap > 0)) return 0;
  const first = baseCost * Math.pow(growth, level);
  if (!Number.isFinite(first) || first > budget) return 0;
  let n = growth === 1
    ? Math.floor(budget / first)
    : Math.floor(Math.log((budget * (growth - 1)) / first + 1) / Math.log(growth));
  n = Math.min(Number.isFinite(n) ? n : 0, cap);
  // Correct tiny floating point errors from the closed form.
  for (let i = 0; i < 4 && n > 0 && geometricCost(baseCost, growth, level, n) > budget; i++) n--;
  for (let i = 0; i < 4 && n < cap && geometricCost(baseCost, growth, level, n + 1) <= budget; i++) n++;
  return Math.max(0, n);
}

/**
 * Describes a purchase for a buy mode (1, 10 or 'max').
 * With 'max' and nothing affordable it quotes a single level so the UI can
 * still show a price.
 */
export function quotePurchase(baseCost, growth, level, mode, budget, cap = Infinity) {
  let count;
  if (mode === 'max') {
    count = maxAffordable(baseCost, growth, level, budget, cap);
    if (count === 0 && cap >= 1) count = 1;
  } else {
    count = Math.min(mode, cap);
  }
  if (!(count > 0)) return { count: 0, cost: 0, affordable: false };
  const cost = geometricCost(baseCost, growth, level, count);
  return { count, cost, affordable: Number.isFinite(cost) && cost <= budget };
}

/** Picks a key using positive weights (object of key -> weight). */
export function weightedPick(weights, rng = Math.random) {
  let total = 0;
  for (const k in weights) total += weights[k];
  if (!(total > 0)) return null;
  let r = rng() * total;
  let last = null;
  for (const k in weights) {
    if (!(weights[k] > 0)) continue;
    last = k;
    r -= weights[k];
    if (r < 0) return k;
  }
  return last;
}
