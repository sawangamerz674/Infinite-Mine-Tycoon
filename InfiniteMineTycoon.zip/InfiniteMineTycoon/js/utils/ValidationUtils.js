/**
 * ValidationUtils — guards for numbers and loaded data.
 */
export const isFiniteNumber = (v) => typeof v === 'number' && Number.isFinite(v);

export function safeNumber(v, fallback = 0) {
  return isFiniteNumber(v) ? v : fallback;
}

export function requireFields(obj, fields, label) {
  for (const f of fields) {
    if (obj == null || !(f in obj)) throw new Error(`${label}: missing field "${f}"`);
  }
}

export function requireUniqueIds(list, label) {
  const seen = new Set();
  for (const item of list) {
    if (seen.has(item.id)) throw new Error(`${label}: duplicate id "${item.id}"`);
    seen.add(item.id);
  }
}
