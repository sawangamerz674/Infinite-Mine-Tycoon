/**
 * NumberFormatter — large-number and duration formatting for the UI.
 * Pure functions, no DOM access.
 */
let suffixes = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'Dc'];

export function configureNumberFormat(list) {
  if (Array.isArray(list) && list.length > 1) suffixes = list.slice();
}

let notation = 'short'; // 'short' (K, M, B...) | 'scientific' | 'full'

export function setNotation(mode) {
  if (['short', 'scientific', 'full'].includes(mode)) notation = mode;
}

function trim(n, decimals) {
  return String(parseFloat(n.toFixed(decimals)));
}

export function formatNumber(value) {
  if (typeof value !== 'number' || Number.isNaN(value)) return '0';
  if (!Number.isFinite(value)) return value > 0 ? '∞' : '-∞';
  if (value < 0) return '-' + formatNumber(-value);
  if (value < 1000) {
    if (Number.isInteger(value)) return String(value);
    return trim(value, value < 10 ? 2 : 1);
  }
  if (notation === 'scientific') return value.toExponential(2).replace('e+', 'e');
  if (notation === 'full' && value < 1e15) return Math.floor(value).toLocaleString('en-US');
  let tier = Math.floor(Math.log10(value) / 3);
  if (tier >= suffixes.length) return value.toExponential(2).replace('e+', 'e');
  let scaled = value / Math.pow(1000, tier);
  const decimals = scaled < 10 ? 2 : scaled < 100 ? 1 : 0;
  // Rounding can push 999.9K up to "1000K"; promote to the next tier instead.
  if (Number(scaled.toFixed(decimals)) >= 1000 && tier + 1 < suffixes.length) {
    tier += 1;
    scaled = value / Math.pow(1000, tier);
    return trim(scaled, scaled < 10 ? 2 : 1) + suffixes[tier];
  }
  return trim(scaled, decimals) + suffixes[tier];
}

export function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(Number.isFinite(totalSeconds) ? totalSeconds : 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n) => String(n).padStart(2, '0');
  if (h > 0) return `${h}h ${pad(m)}m ${pad(sec)}s`;
  if (m > 0) return `${m}m ${pad(sec)}s`;
  return `${sec}s`;
}
