/**
 * MiningSystem — manual mining: how much one tap yields and where it goes.
 */
export class MiningSystem {
  constructor(game) {
    this.game = game;
  }

  /** Units per tap: base + Pickaxe Power levels. */
  get tapYield() {
    return (this.game.config.manualMining.baseUnitsPerTap + this.game.upgrades.getEffect('tapYieldBonus'))
      * this.game.research.getEffect('tapMultiplier')
      * this.game.upgrades.getEffect('miningSpeed');
  }

  /** Mines `multiplier` × tapYield units into storage. */
  tap(multiplier = 1) {
    const requested = Math.max(0, this.tapYield * multiplier);
    const result = this.game.minerals.distribute(requested);
    this.game.state.stats.mineralsExtracted += result.accepted;
    return { ...result, requested };
  }
}
