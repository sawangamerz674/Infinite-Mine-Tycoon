/**
 * BoostSystem — a timed income boost granted by watching an optional
 * rewarded ad (see CrazyGamesIntegration) or bought with coins. Multiplies production while
 * `state.boostSeconds` > 0; the timer only runs while the game is running.
 */
export class BoostSystem {
  constructor(game) {
    this.game = game;
    this.lastEmit = -1;
  }

  get cfg() {
    const a = this.game.config.ads || {};
    return {
      seconds: a.boostSeconds ?? 300,
      multiplier: a.boostMultiplier ?? 2,
      max: a.boostMaxSeconds ?? 1800,
      coinCostFactor: a.boostCoinCostFactor ?? 0.9, // price of the no-ad option, as a share of the income it adds
    };
  }

  get remaining() {
    return this.game.state.boostSeconds;
  }

  get active() {
    return this.remaining > 0;
  }

  multiplier() {
    return this.active ? this.cfg.multiplier : 1;
  }

  /** Adds boost time (capped). */
  grant(seconds = this.cfg.seconds) {
    const s = this.game.state;
    s.boostSeconds = Math.min(this.cfg.max, s.boostSeconds + seconds);
    this.game.bus.emit('boostChanged', s.boostSeconds);
  }

  /** Coins asked for the no-ad option: a bit less than the extra income the boost adds. */
  coinCost() {
    return Math.ceil(this.game.production.coinsPerSecond() * this.cfg.seconds * (this.cfg.multiplier - 1) * this.cfg.coinCostFactor);
  }

  /** The alternative to watching an ad. Not available while a boost is running (no stacking). */
  buyWithCoins() {
    const cost = this.coinCost();
    if (this.active || !(cost > 0) || !this.game.state.spendCoins(cost)) return false;
    this.grant();
    return true;
  }

  update(dt) {
    const s = this.game.state;
    if (s.boostSeconds <= 0) return;
    s.boostSeconds = Math.max(0, s.boostSeconds - dt);
    const whole = Math.ceil(s.boostSeconds);
    if (whole !== this.lastEmit) {
      this.lastEmit = whole;
      this.game.bus.emit('boostChanged', s.boostSeconds);
    }
  }
}
