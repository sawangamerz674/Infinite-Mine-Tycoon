/**
 * TreasureSystem — a hidden treasure room occasionally opens in the rock
 * above the cavern. The player taps the chest before it closes again for a
 * reward: coins (scaled to current income), Research Points, or a cache of
 * the region's rarest mineral. Purely optional; nothing is lost by ignoring it.
 * Timing and rewards are configured in config/game.config.json > treasure.
 */
import { safeNumber } from '../utils/ValidationUtils.js';

export class TreasureSystem {
  constructor(game) {
    this.game = game;
    this.active = null; // { life, total } while a chest is available
    this.timer = this.nextDelay();
  }

  get cfg() {
    const t = this.game.config.treasure || {};
    return {
      min: t.minIntervalSeconds ?? 90,
      max: t.maxIntervalSeconds ?? 180,
      life: t.lifetimeSeconds ?? 25,
      coinSeconds: t.coinSeconds ?? 120,
      minCoins: t.minCoins ?? 50,
      researchChance: t.researchChance ?? 0.2,
      researchBase: t.researchBase ?? 15,
      cacheChance: t.cacheChance ?? 0.12,
    };
  }

  nextDelay() {
    const { min, max } = this.cfg;
    return min + Math.random() * Math.max(0, max - min);
  }

  /** Clears any chest and restarts the timer (after load / prestige / reset). */
  reset() {
    this.active = null;
    this.timer = this.nextDelay();
  }

  update(dt) {
    if (this.active) {
      this.active.life -= dt;
      if (this.active.life <= 0) {
        this.active = null;
        this.timer = this.nextDelay();
        this.game.bus.emit('treasureExpired');
      }
      return;
    }
    this.timer -= dt;
    if (this.timer <= 0) {
      const life = this.cfg.life;
      this.active = { life, total: life };
      this.game.bus.emit('treasureAppeared');
    }
  }

  /** Opens the chest. Returns the reward description, or null if none is available. */
  open() {
    if (!this.active) return null;
    const g = this.game;
    const c = this.cfg;
    this.active = null;
    this.timer = this.nextDelay();

    const roll = Math.random();
    let reward = null;
    if (roll < c.cacheChance) reward = this.cache();
    if (!reward && roll < c.cacheChance + c.researchChance) {
      const amount = Math.max(1, Math.round(c.researchBase * g.state.currentRegion * (0.8 + Math.random() * 0.4)));
      g.addResearchPoints(amount);
      reward = { type: 'research', amount };
    }
    if (!reward) {
      const income = g.production.coinsPerSecond();
      const amount = Math.max(c.minCoins, Math.floor(safeNumber(income * c.coinSeconds) * (0.75 + Math.random() * 0.5)));
      g.earn(amount);
      reward = { type: 'coins', amount };
    }
    g.state.stats.treasuresFound += 1;
    g.bus.emit('treasureOpened', reward);
    return reward;
  }

  /** A stash of the rarest mineral of the current region (needs storage room). */
  cache() {
    const g = this.game;
    const minerals = g.minerals.available().slice().sort((x, y) => y.value - x.value);
    const best = minerals[0];
    if (!best) return null;
    const units = Math.max(5, Math.round(g.production.unitsPerSecond() * 20));
    const stored = g.minerals.add(best.id, units);
    if (stored <= 0) return null;
    return { type: 'cache', amount: Math.floor(stored), mineral: best };
  }
}
