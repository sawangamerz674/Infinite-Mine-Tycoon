/**
 * AchievementSystem — progress tracking, completion, Research Point rewards
 * and a small permanent production bonus per completed achievement.
 * An achievement is { stat, target }; stat names are resolved by value().
 */
export class AchievementSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.achievements;
    this.bonusEach = game.data.balance.achievements.productionBonusEach;
    this.timer = 0;
  }

  isDone(id) {
    return !!this.game.state.achievements[id];
  }

  completedCount() {
    return this.list.filter((a) => this.isDone(a.id)).length;
  }

  /** Permanent production multiplier from completed achievements. */
  productionMultiplier() {
    return 1 + this.bonusEach * this.completedCount();
  }

  value(stat) {
    const g = this.game;
    const s = g.state;
    if (stat.startsWith('discovered:')) return s.discovered[stat.slice(11)] ? 1 : 0;
    switch (stat) {
      case 'lifetimeCoins': return s.lifetimeCoins;
      case 'totalClicks': return s.totalClicks;
      case 'mineralsExtracted': return s.stats.mineralsExtracted;
      case 'mineralsSold': return s.stats.mineralsSold;
      case 'managersHired': return g.workers.hired('manager');
      case 'workerTypesHired': return g.workers.list.filter((w) => g.workers.hired(w.id) > 0).length;
      case 'totalPurchases':
        return s.stats.machinePurchases + s.stats.upgradePurchases + s.stats.workersHired + s.stats.workerTraining;
      case 'maxMachineLevel': return Math.max(0, ...g.machines.list.map((m) => g.machines.level(m.id)));
      case 'machineTypesOwned': return g.machines.list.filter((m) => g.machines.level(m.id) > 0).length;
      case 'researchCount': return g.research.count();
      case 'unlockedRegions': return s.unlockedRegions;
      case 'prestigeCount': return s.prestigeCount;
      case 'treasuresFound': return s.stats.treasuresFound;
      default: return 0;
    }
  }

  /** { value, target, fraction } for the UI. */
  progress(def) {
    const value = this.isDone(def.id) ? def.target : Math.min(this.value(def.stat), def.target);
    return { value, target: def.target, fraction: Math.min(1, value / def.target) };
  }

  check() {
    for (const def of this.list) {
      if (this.isDone(def.id) || this.value(def.stat) < def.target) continue;
      this.game.state.achievements[def.id] = true;
      const rp = def.reward?.researchPoints ?? 0;
      if (rp > 0) this.game.addResearchPoints(rp);
      this.game.bus.emit('achievementCompleted', { def, researchPoints: rp });
    }
  }

  update(dt) {
    this.timer += dt;
    if (this.timer >= 0.5) {
      this.timer = 0;
      this.check();
    }
  }
}
