/**
 * MilestoneSystem — celebrates large-number milestones in lifetime coins
 * (1K, 1M, 1B ... one per thousand-fold step). The first reading after a
 * load or import is taken as the baseline so milestones are never replayed.
 */
import { formatNumber } from '../utils/NumberFormatter.js';

export class MilestoneSystem {
  constructor(game) {
    this.game = game;
    this.tier = null;
    this.timer = 0;
    game.bus.on('stateReplaced', () => { this.tier = null; });
  }

  /** Thousand-fold tier of lifetime coins: 0 below 1K, 1 for 1K, 2 for 1M ... */
  currentTier() {
    const coins = this.game.state.lifetimeCoins;
    return coins >= 1000 ? Math.floor(Math.log10(coins) / 3) : 0;
  }

  update(dt) {
    this.timer += dt;
    if (this.timer < 0.5) return;
    this.timer = 0;
    const tier = this.currentTier();
    if (this.tier === null) { this.tier = tier; return; }
    if (tier > this.tier) {
      this.tier = tier;
      const value = Math.pow(1000, tier);
      this.game.bus.emit('milestoneReached', { tier, value, label: `${formatNumber(value)} COINS` });
    }
  }
}
