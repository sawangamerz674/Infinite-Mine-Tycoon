/**
 * EconomySystem — multipliers and selling.
 *
 * Multipliers combine upgrade effects with any extra sources registered by
 * later systems (workers, research, prestige) via registerMultiplier():
 *   production = BaseRate × Level × Workers × Research × Prestige × Upgrades
 */
import { safeNumber } from '../utils/ValidationUtils.js';

const UPGRADE_EFFECT = { production: 'productionMultiplier', selling: 'sellMultiplier' };

export class EconomySystem {
  constructor(game) {
    this.game = game;
    this.extra = { production: [], selling: [] };
  }

  /** kind: 'production' | 'selling'. fn returns a number >= 0. */
  registerMultiplier(kind, fn) {
    this.extra[kind].push(fn);
  }

  getMultiplier(kind) {
    let m = this.game.upgrades.getEffect(UPGRADE_EFFECT[kind]);
    for (const fn of this.extra[kind]) m *= Math.max(0, safeNumber(fn(), 1));
    return safeNumber(m, 1);
  }

  sellValue(id) {
    return this.game.minerals.byId[id].value * this.getMultiplier('selling');
  }

  /** What Sell All would pay right now (whole units only). */
  previewSellAll() {
    const perUnit = this.game.data.balance.researchPerUnit;
    let coins = 0;
    let units = 0;
    let research = 0;
    for (const m of this.game.minerals.list) {
      const whole = Math.floor(this.game.state.minerals[m.id] + 1e-9);
      if (whole <= 0) continue;
      coins += whole * this.sellValue(m.id);
      research += whole * perUnit[m.rarity];
      units += whole;
    }
    return {
      coins: safeNumber(coins),
      units,
      research: safeNumber(research * this.game.research.getEffect('researchGain')),
    };
  }

  sellAll(auto = false) {
    const state = this.game.state;
    const perUnit = this.game.data.balance.researchPerUnit;
    let coins = 0;
    let units = 0;
    let research = 0;
    for (const m of this.game.minerals.list) {
      const whole = Math.floor(state.minerals[m.id] + 1e-9);
      if (whole <= 0) continue;
      coins += whole * this.sellValue(m.id);
      research += whole * perUnit[m.rarity];
      units += whole;
      state.minerals[m.id] = Math.max(0, state.minerals[m.id] - whole);
    }
    coins = safeNumber(coins);
    if (units === 0 || coins <= 0) return { coins: 0, units: 0, research: 0 };
    this.game.earn(coins);
    research = this.game.addResearchPoints(research * this.game.research.getEffect('researchGain'));
    state.stats.mineralsSold += units;
    state.stats.coinsFromSales += coins;
    this.game.bus.emit('sold', { coins, units, auto, research });
    return { coins, units, research };
  }
}
