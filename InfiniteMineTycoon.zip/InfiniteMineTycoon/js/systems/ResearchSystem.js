/**
 * ResearchSystem — one-time technologies bought with Research Points,
 * grouped in five categories and chained by `requires`.
 * Effects are looked up by type with getEffect():
 *   mode 'multiply' -> product of values (1 when none researched)
 *   mode 'add'      -> sum of values (0 when none researched)
 * Each tech carries `persists`, which PrestigeSystem uses to decide
 * whether it survives a reset.
 */
export class ResearchSystem {
  constructor(game) {
    this.game = game;
    this.categories = game.data.research.categories;
    this.techs = game.data.research.techs;
    this.byId = game.data.techMap;
    this.modes = {};
    for (const t of this.techs) this.modes[t.effect.type] = t.effect.mode;
    this.cache = {};
  }

  isResearched(id) {
    return !!this.game.state.researched[id];
  }

  count() {
    return Object.keys(this.game.state.researched).length;
  }

  techsOf(categoryId) {
    return this.techs.filter((t) => t.category === categoryId);
  }

  missingRequirements(tech) {
    return tech.requires.filter((id) => !this.isResearched(id)).map((id) => this.byId[id]);
  }

  /** 'done' | 'locked' | 'available' */
  status(tech) {
    if (this.isResearched(tech.id)) return 'done';
    return this.missingRequirements(tech).length ? 'locked' : 'available';
  }

  canAfford(tech) {
    return this.game.state.researchPoints >= tech.cost;
  }

  research(id) {
    const tech = this.byId[id];
    if (!tech || this.status(tech) !== 'available' || !this.canAfford(tech)) return false;
    this.game.state.researchPoints -= tech.cost;
    this.game.state.researched[id] = true;
    this.cache = {};
    this.game.bus.emit('researchCompleted', { tech });
    return true;
  }

  /**
   * Total bonus for an effect type: researched techs combined with the
   * permanent Ancient Core upgrades (multiplicative types only).
   */
  getEffect(type) {
    const base = this.techEffect(type);
    return this.modes[type] === 'multiply' ? base * this.game.prestige.getEffect(type) : base;
  }

  techEffect(type) {
    if (type in this.cache) return this.cache[type];
    const mode = this.modes[type];
    let value = mode === 'add' ? 0 : 1;
    for (const t of this.techs) {
      if (t.effect.type !== type || !this.isResearched(t.id)) continue;
      if (mode === 'add') value += t.effect.value;
      else value *= t.effect.value;
    }
    this.cache[type] = value;
    return value;
  }
}
