/**
 * SaveSystem — versioned, validated saves in LocalStorage.
 *
 * Envelope: { version, savedAt, checksum, data }. `data` is the GameState
 * plus the session's bonus-strike hit counter. Every load and import goes
 * through sanitize(), which rebuilds a clean state from known ids only, so a
 * damaged or hand-edited save can never inject NaN, negative amounts or
 * unknown content. A save is never overwritten with an unhealthy state, the
 * previous good save is kept as a backup, and unreadable saves are moved
 * aside (never deleted) before the game starts fresh.
 *
 * Export format: "IMT1:" + base64(JSON envelope). Plain JSON is accepted too.
 */
import { GameState } from '../core/GameState.js';
import { isFiniteNumber } from '../utils/ValidationUtils.js';

export const SAVE_VERSION = 1;
const KEY = 'infinite_mine_tycoon_save';
const BACKUP_KEY = `${KEY}_backup`;
const CORRUPT_KEY = `${KEY}_corrupt`;
const EXPORT_PREFIX = 'IMT1:';
const MAX_SAVE_BYTES = 900 * 1024; // the CrazyGames data module stops backing up above 1 MB
const MAX_VALUE = 1e300;

/**
 * Upgrades an older envelope to the next version. MIGRATIONS[n] converts a
 * version-n envelope into version n+1. Version 1 is the first format, so the
 * table starts empty; add an entry here whenever SAVE_VERSION is raised.
 */
const MIGRATIONS = {};

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const num = (v, d = 0, min = 0, max = MAX_VALUE) => (isFiniteNumber(v) ? Math.min(max, Math.max(min, v)) : d);
const int = (v, d = 0, min = 0, max = 1e9) => Math.floor(num(v, d, min, max));

function checksum(text) {
  let h = 0x811c9dc5; // FNV-1a
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

function hasBadNumber(value) {
  if (typeof value === 'number') return !Number.isFinite(value) || value < 0;
  if (Array.isArray(value)) return value.some(hasBadNumber);
  if (isObj(value)) return Object.values(value).some(hasBadNumber);
  return false;
}

export class SaveSystem {
  constructor(game) {
    this.game = game;
    this.legacy = this.localStore();
    // CrazyGames data module when available (cloud save), otherwise LocalStorage.
    this.store = game.platform?.storage ?? this.legacy;
    this.available = this.testStorage();
    if (!this.available && this.store !== this.legacy && this.legacy) {
      // The SDK data module failed its probe: keep the player's progress in LocalStorage instead.
      this.store = this.legacy;
      this.available = this.testStorage();
    }
    this.migratedFromLegacy = false;
    this.loadStatus = 'new'; // 'new' | 'loaded' | 'backup' | 'corrupt'
    this.lastSavedAt = 0;
    this.timer = 0;
    window.addEventListener('pagehide', () => this.save('pagehide'));
    game.bus.on('prestiged', () => this.save('prestige'));
  }

  localStore() {
    try {
      return window.localStorage;
    } catch (err) {
      return null;
    }
  }

  /** Reads a key from the main store, falling back to LocalStorage (older local saves). */
  getRaw(key) {
    let raw = this.store.getItem(key);
    if (raw == null && this.legacy && this.legacy !== this.store) {
      try { raw = this.legacy.getItem(key); } catch (err) { raw = null; }
    }
    return raw;
  }

  testStorage() {
    if (!this.store) return false;
    try {
      this.store.setItem(`${KEY}_probe`, '1');
      this.store.removeItem(`${KEY}_probe`);
      return true;
    } catch (err) {
      return false;
    }
  }

  get config() {
    const c = this.game.config.save || {};
    return { intervalSeconds: Math.max(5, num(c.intervalSeconds, 30, 5, 3600)) };
  }

  // ---- building and reading envelopes -----------------------------------------------

  buildEnvelope() {
    const g = this.game;
    g.state.lastSeen = Date.now();
    const data = JSON.parse(JSON.stringify(g.state));
    data.hits = g.hits;
    const body = JSON.stringify(data);
    return { version: SAVE_VERSION, savedAt: Date.now(), checksum: checksum(body), data };
  }

  /** Validates an envelope object. Returns { ok, error?, state?, hits?, savedAt?, version? }. */
  readEnvelope(env) {
    if (!isObj(env)) return { ok: false, error: 'Not a save file.' };
    if (!Number.isInteger(env.version) || env.version < 1) return { ok: false, error: 'Missing save version.' };
    if (env.version > SAVE_VERSION) return { ok: false, error: 'This save is from a newer version of the game.' };
    if (!isObj(env.data) || typeof env.checksum !== 'string') return { ok: false, error: 'Save data is incomplete.' };
    if (checksum(JSON.stringify(env.data)) !== env.checksum) return { ok: false, error: 'Save data is damaged (checksum mismatch).' };
    let current = env;
    while (current.version < SAVE_VERSION) {
      const migrate = MIGRATIONS[current.version];
      if (!migrate) return { ok: false, error: `No migration from save version ${current.version}.` };
      current = migrate(current);
    }
    const { state, hits } = this.sanitize(current.data);
    return { ok: true, state, hits, savedAt: num(env.savedAt, 0), version: env.version };
  }

  /** Rebuilds a clean state from untrusted data: known ids only, finite non-negative numbers. */
  sanitize(d) {
    const g = this.game;
    const data = isObj(d) ? d : {};
    const fresh = new GameState(g.config, g.data);
    const out = {};
    out.boostSeconds = num(data.boostSeconds, 0, 0, g.config.ads?.boostMaxSeconds ?? 1800);
    for (const k of ['coins', 'researchPoints', 'ancientCores', 'lifetimeCoins', 'totalClicks', 'playtime', 'highestRate',
      'runCoins', 'runPlaytime', 'totalCoresEarned']) {
      out[k] = num(data[k], fresh[k]);
    }
    out.lifetimeCoins = Math.max(out.lifetimeCoins, out.runCoins);
    out.prestigeCount = int(data.prestigeCount);
    out.lastSeen = num(data.lastSeen, 0, 0, Date.now());
    out.unlockedRegions = int(data.unlockedRegions, 1, 1, g.data.regions.length);
    out.currentRegion = int(data.currentRegion, 1, 1, out.unlockedRegions);
    out.autoSellEnabled = typeof data.autoSellEnabled === 'boolean' ? data.autoSellEnabled : true;

    const mapOf = (src, template, fn) => Object.fromEntries(
      Object.keys(template).map((id) => [id, fn(isObj(src) ? src[id] : undefined, id)]),
    );
    const flags = (src, ids) => Object.fromEntries(ids.filter((id) => isObj(src) && src[id] === true).map((id) => [id, true]));

    out.minerals = mapOf(data.minerals, fresh.minerals, (v) => num(v));
    out.machines = mapOf(data.machines, fresh.machines, (v) => int(v));
    out.upgrades = mapOf(data.upgrades, fresh.upgrades, (v) => int(v));
    out.workers = mapOf(data.workers, fresh.workers, (v) => ({ hired: int(v?.hired), level: int(v?.level) }));
    out.stats = mapOf(data.stats, fresh.stats, (v) => num(v));
    out.discovered = flags(data.discovered, Object.keys(g.data.mineralMap));
    out.researched = flags(data.researched, Object.keys(g.data.techMap));
    out.achievements = flags(data.achievements, g.data.achievements.map((a) => a.id));
    out.prestigeUpgrades = Object.fromEntries(g.data.prestige.upgrades
      .map((u) => [u.id, int(isObj(data.prestigeUpgrades) ? data.prestigeUpgrades[u.id] : 0, 0, 0, u.maxLevel)])
      .filter(([, lv]) => lv > 0));
    const limit = g.data.prestige.settings.historyLimit;
    out.prestigeHistory = (Array.isArray(data.prestigeHistory) ? data.prestigeHistory : [])
      .filter(isObj).slice(-limit)
      .map((h) => ({ at: num(h.at), cores: int(h.cores), runCoins: num(h.runCoins), runSeconds: num(h.runSeconds) }));
    return { state: out, hits: int(data.hits) };
  }

  // ---- storage ----------------------------------------------------------------------------

  read(key) {
    const raw = this.getRaw(key);
    if (raw == null) return { status: 'none' };
    try {
      const result = this.readEnvelope(JSON.parse(raw));
      return result.ok ? { status: 'ok', result, raw } : { status: 'bad', error: result.error, raw };
    } catch (err) {
      return { status: 'bad', error: 'Save is not valid JSON.', raw };
    }
  }

  /** Loads the saved game at startup. Sets and returns loadStatus. */
  load() {
    if (!this.available) return this.loadStatus;
    let primary;
    let backup;
    try {
      primary = this.read(KEY);
      if (primary.status === 'ok') return this.finishLoad(primary.result, 'loaded');
      backup = this.read(BACKUP_KEY);
      if (primary.status === 'bad') {
        this.store.setItem(CORRUPT_KEY, primary.raw); // keep the unreadable save for recovery
      }
      if (backup.status === 'ok') return this.finishLoad(backup.result, 'backup');
      if (primary.status === 'bad' || backup.status === 'bad') this.loadStatus = 'corrupt';
    } catch (err) {
      console.warn('Save could not be read.', err);
      this.loadStatus = 'corrupt';
    }
    return this.loadStatus;
  }

  finishLoad(result, status) {
    this.game.replaceState(result.state, result.hits);
    this.lastSavedAt = result.savedAt;
    this.loadStatus = status;
    this.migrateLegacy();
    return status;
  }

  /**
   * One-time move of a LocalStorage save (from before the CrazyGames data module) into the
   * data module, as the docs recommend. The old copy is removed only after the new one is verified.
   */
  migrateLegacy() {
    if (!this.legacy || this.legacy === this.store) return;
    try {
      const old = this.legacy.getItem(KEY);
      if (old == null) return;
      if (this.store.getItem(KEY) == null) {
        this.store.setItem(KEY, old);
        const oldBackup = this.legacy.getItem(BACKUP_KEY);
        if (oldBackup != null && this.store.getItem(BACKUP_KEY) == null) this.store.setItem(BACKUP_KEY, oldBackup);
        if (this.store.getItem(KEY) !== old) return;
        this.migratedFromLegacy = true;
      }
      this.legacy.removeItem(KEY);
      this.legacy.removeItem(BACKUP_KEY);
    } catch (err) {
      console.warn('Could not move the local save into the platform storage.', err);
    }
  }

  /** Saves now. Returns true on success; emits 'saved' or 'saveFailed'. */
  save(reason = 'manual') {
    const g = this.game;
    if (!g.started && reason !== 'manual' && reason !== 'reset') return false;
    if (!this.available) return this.fail('Saving is not available in this browser.');
    if (hasBadNumber(g.state)) return this.fail('Game data looks invalid, so the existing save was not overwritten.');
    try {
      const env = this.buildEnvelope();
      const json = JSON.stringify(env);
      if (json.length > MAX_SAVE_BYTES) return this.fail('The save is too large to store.');
      const check = this.readEnvelope(JSON.parse(json));
      if (!check.ok) return this.fail('Save failed validation and was not written.');
      const previous = this.read(KEY);
      if (previous.status === 'ok') this.store.setItem(BACKUP_KEY, previous.raw);
      this.store.setItem(KEY, json);
      if (this.store.getItem(KEY) !== json) return this.fail('Save could not be verified.');
      this.lastSavedAt = env.savedAt;
      g.bus.emit('saved', { at: env.savedAt, reason });
      return true;
    } catch (err) {
      return this.fail('Saving failed (storage full or blocked).');
    }
  }

  fail(message) {
    this.game.bus.emit('saveFailed', { message });
    return false;
  }

  /** Called every game tick; autosaves on the configured interval. */
  update(dt) {
    if (!this.game.settings.get('autosave')) return;
    this.timer += dt;
    if (this.timer >= this.config.intervalSeconds) {
      this.timer = 0;
      this.save('auto');
    }
  }

  // ---- export / import -----------------------------------------------------------------------

  exportCode() {
    return EXPORT_PREFIX + btoa(unescape(encodeURIComponent(JSON.stringify(this.buildEnvelope()))));
  }

  /** Validates pasted/loaded text without changing the game. */
  parseImport(text) {
    let raw = typeof text === 'string' ? text.trim() : '';
    if (!raw) return { ok: false, error: 'Nothing to import.' };
    try {
      if (raw.startsWith(EXPORT_PREFIX)) raw = decodeURIComponent(escape(atob(raw.slice(EXPORT_PREFIX.length).replace(/\s+/g, ''))));
      return this.readEnvelope(JSON.parse(raw));
    } catch (err) {
      return { ok: false, error: 'This is not a valid Infinite Mine Tycoon save.' };
    }
  }

  /** Applies a result from parseImport() and saves it. */
  applyImport(result) {
    if (!result?.ok) return false;
    this.game.replaceState(result.state, result.hits);
    this.save('import');
    this.game.bus.emit('imported');
    return true;
  }

  // ---- reset --------------------------------------------------------------------------------------

  /** Wipes all progress (settings are kept). Callers must have confirmed with the player. */
  resetProgress() {
    const g = this.game;
    g.replaceState(new GameState(g.config, g.data), 0);
    if (this.available) {
      try {
        this.store.removeItem(KEY);
        this.store.removeItem(BACKUP_KEY);
        this.store.removeItem(CORRUPT_KEY);
      } catch (err) {
        console.warn('Could not clear the save.', err);
      }
    }
    this.save('reset');
    g.bus.emit('gameReset');
  }
}
