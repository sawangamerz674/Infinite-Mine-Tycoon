/**
 * RegionSystem — the five underground regions: unlocking (in order, for
 * coins), travelling between unlocked regions and unlock rewards.
 * The current region decides which minerals the player and machines mine.
 */
export class RegionSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.regions;
    this.byId = game.data.regionMap;
  }

  get current() {
    return this.byId[this.game.state.currentRegion];
  }

  isUnlocked(id) {
    return id <= this.game.state.unlockedRegions;
  }

  /** Regions unlock strictly in order. */
  canUnlock(id) {
    return id === this.game.state.unlockedRegions + 1 && !!this.byId[id];
  }

  cost(id) {
    return this.byId[id]?.unlockCost ?? Infinity;
  }

  mineralsOf(id) {
    return this.game.data.minerals.filter((m) => m.region === id);
  }

  /** Spends coins, unlocks the region, grants its reward and travels there. */
  unlock(id) {
    if (!this.canUnlock(id)) return false;
    const region = this.byId[id];
    if (!this.game.state.spendCoins(region.unlockCost)) return false;
    this.game.state.unlockedRegions = id;
    const rp = region.reward?.researchPoints ?? 0;
    if (rp > 0) this.game.addResearchPoints(rp);
    this.game.bus.emit('regionUnlocked', { id, region, researchPoints: rp });
    this.select(id);
    return true;
  }

  select(id) {
    if (!this.isUnlocked(id) || id === this.game.state.currentRegion) return false;
    this.game.state.currentRegion = id;
    this.game.bus.emit('regionChanged', { id, region: this.byId[id] });
    return true;
  }
}
