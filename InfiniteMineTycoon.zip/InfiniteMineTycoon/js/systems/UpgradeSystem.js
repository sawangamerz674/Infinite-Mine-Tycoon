/**
 * UpgradeSystem — permanent-per-run upgrades bought with coins.
 * Cost of level L is baseCost × growth^L. Effects come from upgrades.json:
 *   mode 'add'           -> perLevel × level          (e.g. +1 unit per tap)
 *   mode 'addMultiplier' -> 1 + perLevel × level      (e.g. +25% output)
 *   mode 'multiplier'    -> perLevel ^ level          (e.g. x1.4 storage)
 */
import { quotePurchase } from '../utils/MathUtils.js';
import { formatNumber } from '../utils/NumberFormatter.js';

export class UpgradeSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.upgrades;
    this.byId = game.data.upgradeMap;
  }

  level(id) {
    return this.game.state.upgrades[id] || 0;
  }

  remainingLevels(def) {
    return def.maxLevel ? Math.max(0, def.maxLevel - this.level(def.id)) : Infinity;
  }

  effectValue(def, level) {
    const { mode, perLevel } = def.effect;
    if (mode === 'add') return perLevel * level;
    if (mode === 'addMultiplier') return 1 + perLevel * level;
    return Math.pow(perLevel, level);
  }

  /** Combined effect of all upgrades of a type (identity value if none). */
  getEffect(type) {
    let additive = null;
    let value = 1;
    for (const def of this.list) {
      if (def.effect.type !== type) continue;
      const v = this.effectValue(def, this.level(def.id));
      if (def.effect.mode === 'add') additive = (additive ?? 0) + v;
      else value *= v;
    }
    return additive !== null ? additive : value;
  }

  formatEffect(def, level) {
    const v = this.effectValue(def, level);
    const { display, suffix = '' } = def.effect;
    if (display === 'add') return `+${formatNumber(v)}${suffix}`;
    if (display === 'percent') return `+${formatNumber(Math.round((v - 1) * 100))}%`;
    return `x${formatNumber(Math.round(v * 100) / 100)}`;
  }

  quote(def, mode) {
    return quotePurchase(def.baseCost, def.growth, this.level(def.id), mode,
      this.game.state.coins, this.remainingLevels(def));
  }

  /** Buys upgrade levels for the given mode; returns levels bought. */
  buy(id, mode) {
    const def = this.byId[id];
    if (!def) return 0;
    const q = this.quote(def, mode);
    if (q.count <= 0 || !q.affordable || !this.game.state.spendCoins(q.cost)) return 0;
    this.game.state.upgrades[id] = this.level(id) + q.count;
    this.game.state.stats.upgradePurchases += q.count;
    this.game.bus.emit('upgradePurchased', { id, count: q.count, level: this.level(id) });
    return q.count;
  }
}
