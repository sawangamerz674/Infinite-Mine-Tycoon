/**
 * StatisticsSystem — turns raw game state into the labelled rows shown in
 * the Statistics tab. Rows for workers, prestige etc. are added with the
 * systems that produce those numbers.
 */
import { formatNumber, formatDuration } from '../utils/NumberFormatter.js';

export class StatisticsSystem {
  constructor(game) {
    this.game = game;
  }

  getRows() {
    const g = this.game;
    const s = g.state;
    return [
      { label: 'Current coins', value: formatNumber(Math.floor(s.coins)) },
      { label: 'Lifetime coins earned', value: formatNumber(Math.floor(s.lifetimeCoins)) },
      { label: 'Coins per second', value: formatNumber(g.production.coinsPerSecond()) },
      { label: 'Highest production rate', value: formatNumber(s.highestRate) },
      { label: 'Minerals per second', value: formatNumber(g.production.unitsPerSecond()) },
      { label: 'Total minerals extracted', value: formatNumber(Math.floor(s.stats.mineralsExtracted)) },
      { label: 'Mined by machines', value: formatNumber(Math.floor(s.stats.mineralsProduced)) },
      { label: 'Minerals sold', value: formatNumber(s.stats.mineralsSold) },
      { label: 'Machine levels purchased', value: formatNumber(s.stats.machinePurchases) },
      { label: 'Upgrades purchased', value: formatNumber(s.stats.upgradePurchases) },
      { label: 'Workers hired', value: formatNumber(s.stats.workersHired) },
      { label: 'Worker training levels', value: formatNumber(s.stats.workerTraining) },
      { label: 'Automatic sales', value: formatNumber(s.stats.autoSells) },
      { label: 'Regions unlocked', value: `${s.unlockedRegions} / ${g.regions.list.length}` },
      { label: 'Minerals discovered', value: `${Object.keys(s.discovered).length} / ${g.minerals.list.length}` },
      { label: 'Research Points earned', value: formatNumber(Math.floor(s.stats.researchEarned)) },
      { label: 'Research completed', value: `${g.research.count()} / ${g.research.techs.length}` },
      { label: 'Achievements', value: `${g.achievements.completedCount()} / ${g.achievements.list.length}` },
      { label: 'Treasure chests opened', value: formatNumber(s.stats.treasuresFound) },
      { label: 'Prestiges', value: formatNumber(s.prestigeCount) },
      { label: 'Ancient Cores earned', value: formatNumber(s.totalCoresEarned) },
      { label: 'Offline coins collected', value: formatNumber(Math.floor(s.stats.offlineCoins)) },
      { label: 'Total taps', value: formatNumber(s.totalClicks) },
      { label: 'Total playtime', value: formatDuration(s.playtime) },
    ];
  }
}
