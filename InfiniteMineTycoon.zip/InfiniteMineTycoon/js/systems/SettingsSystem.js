/**
 * SettingsSystem — player preferences (audio, display, saving). Stored in
 * their own LocalStorage key so resetting progress never touches them.
 * Every value is validated against SCHEMA on load and on change.
 */
import { setNotation } from '../utils/NumberFormatter.js';

const KEY = 'infinite_mine_tycoon_settings';

export const SCHEMA = {
  musicEnabled: { type: 'bool', default: true },
  musicVolume: { type: 'range', min: 0, max: 1, default: 0.5 },
  sfxVolume: { type: 'range', min: 0, max: 1, default: 0.7 },
  notation: { type: 'enum', values: ['short', 'scientific', 'full'], default: 'short' },
  particles: { type: 'enum', values: ['low', 'normal', 'high'], default: 'normal' },
  animationSpeed: { type: 'range', min: 0.25, max: 2, default: 1 },
  screenShake: { type: 'bool', default: true },
  floatingText: { type: 'bool', default: true },
  autosave: { type: 'bool', default: true },
};

function coerce(def, value) {
  switch (def.type) {
    case 'bool': return typeof value === 'boolean' ? value : def.default;
    case 'range': return typeof value === 'number' && Number.isFinite(value)
      ? Math.min(def.max, Math.max(def.min, value)) : def.default;
    case 'enum': return def.values.includes(value) ? value : def.default;
    default: return def.default;
  }
}

export class SettingsSystem {
  constructor(game) {
    this.game = game;
    // Players who ask their system for reduced motion start with calmer visuals.
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    this.defaults = Object.fromEntries(Object.entries(SCHEMA).map(([k, def]) => [k, def.default]));
    if (calm) Object.assign(this.defaults, { screenShake: false, particles: 'low' });
    this.values = { ...this.defaults };
    this.load();
    setNotation(this.values.notation);
  }

  get(key) {
    return this.values[key];
  }

  set(key, value) {
    const def = SCHEMA[key];
    if (!def) return false;
    const next = coerce(def, value);
    if (next === this.values[key]) return false;
    this.values[key] = next;
    if (key === 'notation') setNotation(next);
    this.persist();
    this.game.bus.emit('settingsChanged', { key, value: next });
    return true;
  }

  resetAll() {
    for (const k of Object.keys(SCHEMA)) this.set(k, this.defaults[k]);
  }

  load() {
    try {
      const raw = this.read();
      if (!raw) return;
      const saved = JSON.parse(raw)?.values;
      if (!saved || typeof saved !== 'object') return;
      for (const [k, def] of Object.entries(SCHEMA)) {
        this.values[k] = saved[k] === undefined ? this.defaults[k] : coerce(def, saved[k]);
      }
    } catch (err) {
      console.warn('Settings could not be loaded, using defaults.', err);
    }
  }

  /** Player options live in the CrazyGames data module when it is active (so they follow the player), else LocalStorage. */
  get store() {
    return this.game.platform?.storage ?? this.localStore();
  }

  localStore() {
    try { return window.localStorage; } catch (err) { return null; }
  }

  /** Reads the saved options; older LocalStorage copies are used (and migrated) when the data module has none. */
  read() {
    let raw = null;
    try { raw = this.store?.getItem(KEY) ?? null; } catch (err) { raw = null; }
    if (raw == null && this.game.platform?.active) {
      const legacy = this.localStore();
      try { raw = legacy?.getItem(KEY) ?? null; } catch (err) { raw = null; }
      if (raw != null) {
        try { this.store.setItem(KEY, raw); } catch (err) { /* migrated on the next change instead */ }
      }
    }
    return raw;
  }

  persist() {
    try {
      this.store?.setItem(KEY, JSON.stringify({ version: 1, values: this.values }));
    } catch (err) {
      console.warn('Settings could not be saved.', err);
    }
  }
}
