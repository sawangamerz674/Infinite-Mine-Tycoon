/**
 * MachineSystem — purchasing and levelling machines.
 * Two kinds: 'producer' machines mine units per second; 'support' machines
 * (conveyor, elevator, processor) add an empire-wide bonus per level.
 * Level 0 means "not owned". Every `milestoneEvery` levels the machine's
 * output (or bonus) is multiplied.
 */
import { quotePurchase } from '../utils/MathUtils.js';

export class MachineSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.machines;
    this.byId = game.data.machineMap;
    this.milestones = game.data.balance.machines;
  }

  level(id) {
    return this.game.state.machines[id] || 0;
  }

  isSupport(def) {
    return def.kind === 'support';
  }

  isUnlocked(def) {
    const need = def.unlock?.lifetimeCoins ?? 0;
    const region = def.unlock?.region ?? 1;
    return this.game.state.lifetimeCoins >= need && this.game.state.unlockedRegions >= region;
  }

  unlockText(def) {
    const parts = [];
    const region = def.unlock?.region ?? 1;
    if (this.game.state.unlockedRegions < region) {
      parts.push(`unlock ${this.game.regions.byId[region].name}`);
    }
    const need = def.unlock?.lifetimeCoins ?? 0;
    if (this.game.state.lifetimeCoins < need) {
      parts.push(`earn ${need.toLocaleString('en-US')} lifetime coins`);
    }
    const text = parts.join(' and ');
    return text ? text[0].toUpperCase() + text.slice(1) : '';
  }

  milestoneMultiplier(level) {
    const { milestoneEvery, milestoneMultiplier } = this.milestones;
    return Math.pow(milestoneMultiplier, Math.floor(level / milestoneEvery));
  }

  nextMilestone(level) {
    const every = this.milestones.milestoneEvery;
    return (Math.floor(level / every) + 1) * every;
  }

  /** Visual tier 0..n, one step per milestone (used by the renderer). */
  tier(id) {
    return Math.floor(this.level(id) / this.milestones.milestoneEvery);
  }

  /** Units per second a producer machine makes (before the mineral split). */
  production(id, atLevel = this.level(id)) {
    const def = this.byId[id];
    if (!def || this.isSupport(def) || atLevel <= 0) return 0;
    return def.baseRate * atLevel * this.milestoneMultiplier(atLevel)
      * this.game.economy.getMultiplier('production');
  }

  /** Total bonus from support machines of an effect type (0 if none owned). */
  supportBonus(type, def = null, atLevel = null) {
    let total = 0;
    for (const d of this.list) {
      if (!this.isSupport(d) || d.effect.type !== type) continue;
      if (def && def.id !== d.id) continue;
      const lv = def && atLevel !== null ? atLevel : this.level(d.id);
      const boost = d.effect.boostKey ? this.game.research.getEffect(d.effect.boostKey) : 1;
      total += d.effect.perLevel * lv * this.milestoneMultiplier(lv) * boost * this.game.upgrades.getEffect('supportSpeed');
    }
    return total;
  }

  quote(def, mode) {
    const discount = this.game.workers.getEffect('machineCostDiscount');
    return quotePurchase(def.baseCost * (1 - discount), def.growth, this.level(def.id), mode, this.game.state.coins);
  }

  /** Buys levels for the given mode; returns levels bought. */
  buy(id, mode) {
    const def = this.byId[id];
    if (!def || !this.isUnlocked(def)) return 0;
    const q = this.quote(def, mode);
    if (q.count <= 0 || !q.affordable || !this.game.state.spendCoins(q.cost)) return 0;
    this.game.state.machines[id] = this.level(id) + q.count;
    this.game.state.stats.machinePurchases += q.count;
    this.game.bus.emit('machinePurchased', { id, count: q.count, level: this.level(id) });
    return q.count;
  }
}
