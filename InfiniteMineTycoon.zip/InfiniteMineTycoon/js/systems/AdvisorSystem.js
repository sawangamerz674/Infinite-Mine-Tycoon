/**
 * AdvisorSystem — optional "Ask the Foreman" tips powered by the advisor server.
 *
 * The browser only sends a compact summary of the game (ids and numbers, no personal
 * data); the server holds the API key and talks to the model. If the server is not
 * reachable (static hosting, CrazyGames, offline) the feature stays hidden and the
 * game is unaffected.
 *
 * Events: 'advisorAvailable' (true) once the server answers the health check.
 */
export class AdvisorSystem {
  constructor(game) {
    this.game = game;
    this.available = false;
    this.busy = false;
    this.lastAsk = 0;
  }

  get cfg() {
    const c = this.game.config.ai || {};
    return {
      enabled: c.enabled !== false,
      baseUrl: typeof c.baseUrl === 'string' ? c.baseUrl.replace(/\/$/, '') : '',
      cooldown: Number.isFinite(c.cooldownSeconds) ? c.cooldownSeconds : 20,
      timeout: Number.isFinite(c.timeoutSeconds) ? c.timeoutSeconds : 12,
    };
  }

  /** Asks the server whether the advisor is configured. Never throws. */
  async probe() {
    const c = this.cfg;
    // Never contact an external server from inside the CrazyGames portal.
    if (!c.enabled || this.game.platform?.active) return false;
    try {
      const res = await this.request(`${c.baseUrl}/api/health`, { method: 'GET' }, 3);
      const body = await res.json();
      this.available = res.ok && body?.enabled === true;
    } catch {
      this.available = false;
    }
    if (this.available) this.game.bus.emit('advisorAvailable', true);
    return this.available;
  }

  /** Seconds until the next question is allowed. */
  cooldownLeft(now = Date.now()) {
    return Math.max(0, Math.ceil(this.cfg.cooldown - (now - this.lastAsk) / 1000));
  }

  /** Compact, privacy-free snapshot of the run. */
  summary() {
    const g = this.game;
    const s = g.state;
    const next = g.regions.canUnlock(s.unlockedRegions + 1)
      ? { id: s.unlockedRegions + 1, cost: g.regions.cost(s.unlockedRegions + 1) }
      : null;
    const workers = {};
    for (const [id, w] of Object.entries(s.workers)) if (w?.hired > 0) workers[id] = { hired: w.hired, level: w.level };
    const cap = g.minerals.capacity();
    return {
      region: s.currentRegion,
      coins: s.coins,
      coinsPerSecond: g.production.coinsPerSecond(),
      researchPoints: s.researchPoints,
      storagePercent: cap > 0 ? Math.min(100, (g.minerals.used() / cap) * 100) : 0,
      autoSell: s.autoSellEnabled,
      machines: Object.fromEntries(Object.entries(s.machines).filter(([, lv]) => lv > 0)),
      workers,
      upgrades: Object.fromEntries(Object.entries(s.upgrades).filter(([, lv]) => lv > 0)),
      researched: Object.keys(s.researched).filter((id) => s.researched[id]),
      nextRegion: next,
      prestigeCount: s.prestigeCount,
      cores: s.ancientCores,
      canPrestige: g.prestige.isEligible(),
    };
  }

  /** Returns { ok: true, tip } or { ok: false, error } with a message fit for the player. */
  async ask() {
    if (!this.available) return { ok: false, error: 'The Foreman is not available.' };
    if (this.busy) return { ok: false, error: 'The Foreman is already thinking.' };
    const wait = this.cooldownLeft();
    if (wait > 0) return { ok: false, error: `The Foreman needs ${wait}s to catch his breath.` };
    this.busy = true;
    this.lastAsk = Date.now();
    try {
      const res = await this.request(`${this.cfg.baseUrl}/api/advisor`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.summary()),
      }, this.cfg.timeout);
      const body = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, error: typeof body.error === 'string' ? body.error : 'The Foreman is unavailable right now.' };
      if (typeof body.tip !== 'string' || !body.tip) return { ok: false, error: 'The Foreman had nothing to say.' };
      return { ok: true, tip: body.tip };
    } catch {
      return { ok: false, error: 'Could not reach the Foreman.' };
    } finally {
      this.busy = false;
    }
  }

  async request(url, options, timeoutSeconds) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutSeconds * 1000);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }
}
