/**
 * AudioSystem — original, synthesised sound effects and a quiet ambient
 * music loop made with the Web Audio API (no audio files, no licences).
 * The AudioContext is only created after the first user gesture to respect
 * browser autoplay rules. Music and effects have independent volumes.
 */
const SCALE = [220, 261.63, 293.66, 329.63, 392, 440, 523.25]; // A minor pentatonic-ish
const BEAT = 0.6;
// Pad roots per region: deeper regions sound lower and stranger.
const ROOTS = {
  1: [110, 98, 87.31, 98], 2: [98, 87.31, 73.42, 87.31], 3: [110, 130.81, 98, 82.41],
  4: [123.47, 110, 92.5, 110], 5: [82.41, 73.42, 65.41, 73.42],
};
const MIN_GAP = { mine: 0.04, drill: 0.2, full: 0.5 }; // seconds between repeats

export class AudioSystem {
  constructor(game) {
    this.game = game;
    this.ctx = null;
    this.noise = null;
    this.last = {};
    this.drillTimer = 0;
    this.muteReasons = new Set();
    this.musicTimer = null;
    this.nextBeat = 0;
    this.beat = 0;
    this.bindEvents();
    const unlock = () => {
      this.unlock();
      if (this.ctx) {
        for (const e of ['pointerdown', 'keydown']) window.removeEventListener(e, unlock, true);
      }
    };
    for (const e of ['pointerdown', 'keydown']) window.addEventListener(e, unlock, true);
    document.addEventListener('visibilitychange', () => this.onVisibility());
  }

  bindEvents() {
    const { bus } = this.game;
    bus.on('mined', ({ burst }) => this.play(burst ? 'strike' : 'mine'));
    bus.on('sold', ({ auto }) => this.play(auto ? 'coinSoft' : 'coin'));
    bus.on('offlineCollected', () => this.play('coin'));
    for (const e of ['upgradePurchased', 'workerTrained', 'prestigeUpgradeBought']) bus.on(e, () => this.play('upgrade'));
    bus.on('machinePurchased', () => this.play('machine'));
    bus.on('workerHired', () => this.play('hire'));
    bus.on('researchCompleted', () => this.play('research'));
    bus.on('mineralDiscovered', () => this.play('discover'));
    bus.on('achievementCompleted', () => this.play('achievement'));
    bus.on('regionUnlocked', () => this.play('region'));
    bus.on('prestiged', () => this.play('prestige'));
    bus.on('storageFull', () => this.play('full'));
    bus.on('treasureAppeared', () => this.play('bell'));
    bus.on('treasureOpened', () => this.play('treasure'));
    bus.on('milestoneReached', () => this.play('milestone'));
    bus.on('regionChanged', () => this.play('whoosh'));
    // iOS/Safari keep the context suspended after backgrounding until a real gesture resumes it.
    document.addEventListener('pointerup', () => {
      if (this.ctx && this.ctx.state !== 'running' && !this.muteReasons.size) this.ctx.resume().catch(() => {});
    });
    document.addEventListener('click', (e) => { if (e.target.closest?.('button')) this.play('click'); });
    bus.on('settingsChanged', ({ key }) => {
      if (key === 'musicEnabled' || key === 'musicVolume' || key === 'sfxVolume') this.applyVolumes();
    });
    bus.on('frame', (dt) => this.updateMachines(dt));
  }

  /** Creates the context (first gesture only) and starts music if enabled. */
  unlock() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      try {
        this.ctx = new Ctx();
      } catch (err) {
        console.warn('Audio unavailable.', err);
        return;
      }
      this.master = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();
      this.sfxGain.connect(this.master);
      this.musicGain.connect(this.master);
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.applyVolumes(true);
    }
    if (this.muteReasons.size) this.ctx.suspend().catch(() => {}); // e.g. CrazyGames mute is active
    else if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    this.startMusic();
  }

  get musicOn() {
    const s = this.game.settings;
    return s.get('musicEnabled') && s.get('musicVolume') > 0;
  }

  applyVolumes(instant = false) {
    if (!this.ctx) return;
    const s = this.game.settings;
    const t = this.ctx.currentTime;
    const apply = (param, v) => (instant ? (param.value = v) : param.setTargetAtTime(v, t, 0.05));
    apply(this.sfxGain.gain, s.get('sfxVolume'));
    apply(this.musicGain.gain, s.get('musicEnabled') ? s.get('musicVolume') * 0.35 : 0);
    if (this.musicOn) this.startMusic();
    else this.stopMusic();
  }

  onVisibility() {
    this.setMuted('hidden', document.hidden);
  }

  /** Silences all audio while any reason ('hidden', 'ad') is active. */
  setMuted(reason, on) {
    if (on) this.muteReasons.add(reason);
    else this.muteReasons.delete(reason);
    if (!this.ctx) return;
    if (this.muteReasons.size) this.ctx.suspend().catch(() => {});
    else this.ctx.resume().catch(() => {});
  }

  // ---- building blocks ------------------------------------------------------------

  tone({ freq, to, type = 'square', dur = 0.1, vol = 0.2, delay = 0, bus = this.sfxGain }) {
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (to) osc.frequency.exponentialRampToValueAtTime(to, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(bus);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  hiss({ dur = 0.08, vol = 0.2, freq = 1500, q = 1, delay = 0 }) {
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = freq;
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.sfxGain);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.05);
  }

  // ---- sound effects ----------------------------------------------------------------

  play(name) {
    const sound = this.sounds[name];
    if (!this.ctx || !sound || this.ctx.state !== 'running') return;
    if (this.game.settings.get('sfxVolume') <= 0) return;
    const now = this.ctx.currentTime;
    if (now - (this.last[name] ?? -1) < (MIN_GAP[name] ?? 0.05)) return;
    this.last[name] = now;
    sound.call(this);
  }

  get sounds() {
    return {
      mine() { this.hiss({ dur: 0.06, vol: 0.25, freq: 1800 }); this.tone({ freq: 150, to: 70, type: 'sine', dur: 0.09, vol: 0.3 }); },
      strike() {
        this.hiss({ dur: 0.14, vol: 0.4, freq: 1200 });
        this.tone({ freq: 220, to: 440, type: 'square', dur: 0.16, vol: 0.18 });
        this.tone({ freq: 90, to: 45, type: 'sine', dur: 0.2, vol: 0.4 });
      },
      coin() { this.tone({ freq: 988, dur: 0.08, vol: 0.14 }); this.tone({ freq: 1319, dur: 0.16, vol: 0.14, delay: 0.07 }); },
      coinSoft() { this.tone({ freq: 1319, dur: 0.1, vol: 0.07 }); },
      upgrade() { this.tone({ freq: 440, to: 660, type: 'triangle', dur: 0.12, vol: 0.25 }); this.tone({ freq: 880, type: 'triangle', dur: 0.16, vol: 0.25, delay: 0.1 }); },
      machine() { this.hiss({ dur: 0.12, vol: 0.3, freq: 400 }); this.tone({ freq: 95, to: 60, type: 'square', dur: 0.16, vol: 0.2 }); this.tone({ freq: 523, type: 'triangle', dur: 0.1, vol: 0.18, delay: 0.12 }); },
      hire() { this.tone({ freq: 330, type: 'triangle', dur: 0.1, vol: 0.25 }); this.tone({ freq: 495, type: 'triangle', dur: 0.14, vol: 0.25, delay: 0.09 }); },
      research() { this.tone({ freq: 600, to: 900, type: 'sine', dur: 0.14, vol: 0.28 }); this.tone({ freq: 1200, type: 'sine', dur: 0.12, vol: 0.18, delay: 0.1 }); },
      discover() { [1200, 1500, 1800, 2400].forEach((f, i) => this.tone({ freq: f, type: 'sine', dur: 0.18, vol: 0.18, delay: i * 0.07 })); },
      achievement() { [784, 988, 1175].forEach((f, i) => this.tone({ freq: f, type: 'sine', dur: 0.3, vol: 0.22, delay: i * 0.11 })); },
      region() { [261.63, 329.63, 392, 523.25].forEach((f, i) => this.tone({ freq: f, type: 'triangle', dur: 0.4, vol: 0.28, delay: i * 0.12 })); },
      prestige() {
        this.tone({ freq: 110, to: 440, type: 'sawtooth', dur: 0.9, vol: 0.2 });
        [220, 277.18, 329.63, 440].forEach((f, i) => this.tone({ freq: f, type: 'sine', dur: 1.2, vol: 0.2, delay: 0.3 + i * 0.05 }));
        this.hiss({ dur: 0.9, vol: 0.2, freq: 600 });
      },
      click() { this.tone({ freq: 700, to: 500, type: 'square', dur: 0.04, vol: 0.06 }); },
      bell() { this.tone({ freq: 1568, type: 'sine', dur: 0.5, vol: 0.12 }); this.tone({ freq: 2093, type: 'sine', dur: 0.6, vol: 0.08, delay: 0.12 }); },
      treasure() { [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => this.tone({ freq: f, type: 'triangle', dur: 0.25, vol: 0.22, delay: i * 0.07 })); this.hiss({ dur: 0.3, vol: 0.12, freq: 4000 }); },
      milestone() { [392, 523.25, 659.25, 784, 1046.5].forEach((f, i) => this.tone({ freq: f, type: 'square', dur: 0.3, vol: 0.12, delay: i * 0.09 })); this.tone({ freq: 130.8, type: 'sine', dur: 1.2, vol: 0.35 }); },
      whoosh() { this.hiss({ dur: 0.7, vol: 0.2, freq: 500, q: 0.6 }); this.tone({ freq: 300, to: 80, type: 'sine', dur: 0.7, vol: 0.18 }); },
      full() { this.tone({ freq: 130, to: 100, type: 'square', dur: 0.14, vol: 0.12 }); },
      drill() { this.hiss({ dur: 0.035, vol: 0.07, freq: 900, q: 2 }); },
    };
  }

  /** Quiet rhythmic machine noise while production is running. */
  updateMachines(dt) {
    if (!this.ctx) return;
    const g = this.game;
    const owned = g.machines.list.some((m) => g.machines.level(m.id) > 0);
    if (!owned || g.production.storageFull) return;
    this.drillTimer += dt;
    if (this.drillTimer >= 0.5) {
      this.drillTimer = 0;
      this.play('drill');
    }
  }

  // ---- music --------------------------------------------------------------------------

  startMusic() {
    if (!this.ctx || this.musicTimer || !this.musicOn) return;
    this.nextBeat = this.ctx.currentTime + 0.1;
    this.musicTimer = setInterval(() => this.scheduleMusic(), 250);
    this.scheduleMusic();
  }

  stopMusic() {
    clearInterval(this.musicTimer);
    this.musicTimer = null;
  }

  scheduleMusic() {
    if (!this.ctx || this.ctx.state !== 'running') {
      if (this.ctx) this.nextBeat = Math.max(this.nextBeat, this.ctx.currentTime + 0.1);
      return;
    }
    while (this.nextBeat < this.ctx.currentTime + 1.2) {
      const t = this.nextBeat - this.ctx.currentTime;
      if (this.beat % 8 === 0) {
        const roots = ROOTS[this.game.state.currentRegion] || ROOTS[1];
        const root = roots[(this.beat / 8) % 4];
        this.tone({ freq: root, type: 'sine', dur: 4.2, vol: 0.5, delay: t, bus: this.musicGain });
        this.tone({ freq: root * 1.5, type: 'sine', dur: 4.2, vol: 0.3, delay: t, bus: this.musicGain });
      }
      const pick = (this.beat * 7 + Math.floor(this.beat / 3) * 5) % 11;
      if (pick < SCALE.length && this.beat % 2 === 0) {
        this.tone({ freq: SCALE[pick], type: 'triangle', dur: 0.9, vol: 0.4, delay: t, bus: this.musicGain });
      }
      if (this.game.state.currentRegion >= 4 && this.beat % 4 === 1) {
        this.tone({ freq: SCALE[this.beat % SCALE.length] * 4, type: 'sine', dur: 1.4, vol: 0.12, delay: t, bus: this.musicGain });
      }
      this.beat += 1;
      this.nextBeat += BEAT;
    }
  }
}
