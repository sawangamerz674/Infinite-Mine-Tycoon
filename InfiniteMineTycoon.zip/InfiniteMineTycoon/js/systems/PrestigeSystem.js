/**
 * PrestigeSystem — Ancient Cores. A prestige resets the current run (coins,
 * minerals, machines, upgrades, workers, regions and non-persistent research)
 * in exchange for Ancient Cores, which are spent on a permanent upgrade tree
 * and also grant a small production bonus each.
 *
 *   cores = floor(coreScale × (runCoins / coreDivisor) ^ coreExponent)
 *
 * Effects of the tree are folded into ResearchSystem.getEffect() so every
 * existing system benefits without knowing about prestige.
 */
import { safeNumber } from '../utils/ValidationUtils.js';

export class PrestigeSystem {
  constructor(game) {
    this.game = game;
    this.settings = game.data.prestige.settings;
    this.list = game.data.prestige.upgrades;
    this.byId = game.data.prestigeMap;
    this.cache = {};
  }

  // ---- eligibility & reward ---------------------------------------------------

  get runCoins() {
    return this.game.state.runCoins;
  }

  isEligible() {
    return this.runCoins >= this.settings.minRunCoins;
  }

  /** 0..1 progress toward the first eligible run. */
  progress() {
    return Math.min(1, this.runCoins / this.settings.minRunCoins);
  }

  /** Ancient Cores a prestige would grant right now (0 if not eligible). */
  pendingCores() {
    if (!this.isEligible()) return 0;
    const s = this.settings;
    const raw = s.coreScale * Math.pow(this.runCoins / s.coreDivisor, s.coreExponent);
    return Math.max(1, Math.floor(safeNumber(raw)));
  }

  /** Production multiplier from all Ancient Cores ever earned. */
  coreMultiplier() {
    return 1 + this.settings.coreProductionBonus * this.game.state.totalCoresEarned;
  }

  /** Researched techs that will be lost on prestige. */
  lostTechs() {
    return this.game.research.techs.filter((t) => this.game.research.isResearched(t.id) && !t.persists);
  }

  // ---- permanent upgrades -------------------------------------------------------

  level(id) {
    return this.game.state.prestigeUpgrades[id] || 0;
  }

  isMaxed(id) {
    return this.level(id) >= this.byId[id].maxLevel;
  }

  cost(id) {
    const u = this.byId[id];
    return Math.ceil(u.baseCost * Math.pow(u.growth, this.level(id)));
  }

  canBuy(id) {
    return !!this.byId[id] && !this.isMaxed(id) && this.game.state.ancientCores >= this.cost(id);
  }

  buy(id) {
    if (!this.canBuy(id)) return false;
    this.game.state.ancientCores -= this.cost(id);
    this.game.state.prestigeUpgrades[id] = this.level(id) + 1;
    this.cache = {};
    this.game.bus.emit('prestigeUpgradeBought', { id, level: this.level(id) });
    return true;
  }

  /** Combined permanent effect of a type: product (multiply) or sum (add). */
  getEffect(type) {
    if (type in this.cache) return this.cache[type];
    let mul = 1;
    let add = 0;
    let isAdd = false;
    for (const u of this.list) {
      if (u.effect.type !== type) continue;
      const lv = this.level(u.id);
      if (u.effect.mode === 'add') { isAdd = true; add += u.effect.perLevel * lv; }
      else mul *= 1 + u.effect.perLevel * lv;
    }
    this.cache[type] = isAdd ? add : mul;
    return this.cache[type];
  }

  // ---- the reset ------------------------------------------------------------------

  /**
   * Performs the prestige. Requires `{ confirmed: true }` so nothing can reset
   * progress without the player's explicit confirmation (see PrestigePanel).
   */
  prestige({ confirmed } = {}) {
    if (confirmed !== true || !this.isEligible()) return null;
    const g = this.game;
    const s = g.state;
    const cores = this.pendingCores();
    const entry = {
      at: Date.now(),
      cores,
      runCoins: s.runCoins,
      runSeconds: s.runPlaytime,
    };

    s.prestigeCount += 1;
    s.ancientCores += cores;
    s.totalCoresEarned += cores;
    s.prestigeHistory.push(entry);
    if (s.prestigeHistory.length > this.settings.historyLimit) s.prestigeHistory.shift();

    const lost = this.lostTechs();
    for (const t of lost) delete s.researched[t.id];
    g.research.cache = {};
    this.cache = {};

    s.resetRun(g.config, g.data, { startRegions: 1 + Math.floor(this.getEffect('startRegions')) });
    g.hits = 0;
    g.production.storageFull = false;
    g.workers.sellTimer = 0;
    g.offline.pending = null;
    g.treasure.reset();

    g.bus.emit('prestiged', { cores, entry, lostTechs: lost.length, count: s.prestigeCount });
    g.bus.emit('regionChanged', { id: 1, region: g.regions.current });
    return entry;
  }
}
