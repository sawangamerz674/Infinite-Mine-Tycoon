/**
 * WorkerSystem — hiring and training workers, their bonuses, and the
 * Manager's automatic selling.
 *
 * Each category has `hired` workers and a shared training `level`:
 *   strength = hired × perWorker × (1 + level × levelBoost)
 * Hiring cost  = baseCost × growth^hired
 * Training cost = upgradeBaseCost × upgradeGrowth^level (needs >= 1 hired)
 */
import { quotePurchase } from '../utils/MathUtils.js';

const NO_QUOTE = { count: 0, cost: 0, affordable: false };

export class WorkerSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.workers;
    this.byId = game.data.workerMap;
    this.sellTimer = 0;
  }

  hired(id) {
    return this.game.state.workers[id]?.hired || 0;
  }

  level(id) {
    return this.game.state.workers[id]?.level || 0;
  }

  isUnlocked(def) {
    return this.game.state.lifetimeCoins >= (def.unlock?.lifetimeCoins ?? 0);
  }

  unlockText(def) {
    return `Earn ${def.unlock.lifetimeCoins.toLocaleString('en-US')} lifetime coins to unlock`;
  }

  strength(def, hired = this.hired(def.id), level = this.level(def.id)) {
    return hired * (def.perWorker || 0) * (1 + level * (def.levelBoost || 0))
      * this.game.research.getEffect('workerEffect') * this.game.upgrades.getEffect('workerEfficiency');
  }

  /**
   * Combined effect of all workers of a type: a multiplier (1 = none) for
   * 'bonus' workers, a 0..max fraction for 'discount' workers.
   */
  getEffect(type) {
    let sum = 0;
    let max = Infinity;
    let discount = false;
    for (const def of this.list) {
      if (def.effect.type !== type) continue;
      sum += this.strength(def);
      if (def.effect.display === 'discount') {
        discount = true;
        max = Math.min(max, def.effect.max ?? 0.5);
      }
    }
    return discount ? Math.min(sum, max) : 1 + sum;
  }

  // ---- manager / auto-sell ---------------------------------------------------

  get manager() {
    return this.byId.manager;
  }

  /**
   * Auto-sell is built in: whenever storage is full it sells after a short cooldown.
   * This returns that cooldown in seconds. A Manager, training, research and the
   * Automation Efficiency upgrade only make it faster; none of them is required.
   */
  autoSellInterval(hired = this.hired('manager'), level = this.level('manager')) {
    const e = this.manager?.effect ?? { baseInterval: 3, hireSpeed: 0.5, levelSpeed: 0.25, minInterval: 0.5, firstHire: 0.5 };
    const speed = 1 + (hired > 0 ? (e.firstHire ?? 0.5) + e.hireSpeed * (hired - 1) + e.levelSpeed * level : 0);
    return Math.max(e.minInterval, e.baseInterval / speed / this.game.research.getEffect('autoSellSpeed') / this.game.upgrades.getEffect('automationSpeed'));
  }

  setAutoSell(enabled) {
    this.game.state.autoSellEnabled = !!enabled;
    this.game.bus.emit('autoSellChanged', !!enabled);
  }

  update(dt) {
    // Sell only while storage is full; the timer counts how long it has been full.
    if (!this.game.state.autoSellEnabled || !this.game.minerals.isFull()) {
      this.sellTimer = 0;
      return;
    }
    this.sellTimer += dt;
    if (this.sellTimer >= this.autoSellInterval()) {
      this.sellTimer = 0;
      const result = this.game.economy.sellAll(true);
      if (result.units > 0) this.game.state.stats.autoSells += 1;
    }
  }

  // ---- purchasing -----------------------------------------------------------------

  quoteHire(def, mode) {
    const discount = Math.min(0.6, this.game.research.getEffect('workerHireDiscount'));
    return quotePurchase(def.baseCost * (1 - discount), def.growth, this.hired(def.id), mode, this.game.state.coins);
  }

  quoteTrain(def, mode) {
    if (this.hired(def.id) <= 0) return NO_QUOTE;
    return quotePurchase(def.upgradeBaseCost, def.upgradeGrowth, this.level(def.id), mode, this.game.state.coins);
  }

  hire(id, mode) {
    const def = this.byId[id];
    if (!def || !this.isUnlocked(def)) return 0;
    const q = this.quoteHire(def, mode);
    if (q.count <= 0 || !q.affordable || !this.game.state.spendCoins(q.cost)) return 0;
    this.game.state.workers[id].hired += q.count;
    this.game.state.stats.workersHired += q.count;
    this.game.bus.emit('workerHired', { id, count: q.count, hired: this.hired(id) });
    return q.count;
  }

  train(id, mode) {
    const def = this.byId[id];
    if (!def || !this.isUnlocked(def)) return 0;
    const q = this.quoteTrain(def, mode);
    if (q.count <= 0 || !q.affordable || !this.game.state.spendCoins(q.cost)) return 0;
    this.game.state.workers[id].level += q.count;
    this.game.state.stats.workerTraining += q.count;
    this.game.bus.emit('workerTrained', { id, count: q.count, level: this.level(id) });
    return q.count;
  }

  // ---- display ----------------------------------------------------------------------

  /** Text for the worker's current (or hypothetical) bonus. */
  describe(def, hired = this.hired(def.id), level = this.level(def.id)) {
    const e = def.effect;
    if (e.display === 'autoSell') {
      const s = this.autoSellInterval(hired, level);
      return `Full storage sells after ${Math.round(s * 10) / 10}s`;
    }
    const v = this.strength(def, hired, level);
    if (e.display === 'discount') return `-${Math.round(Math.min(v, e.max ?? 0.5) * 1000) / 10}% ${e.label}`;
    return `+${Math.round(v * 1000) / 10}% ${e.label}`;
  }
}
