/**
 * MineralSystem — mineral definitions, availability, storage, discovery and
 * how mined units are split between the minerals of the current region.
 */
import { weightedPick } from '../utils/MathUtils.js';
import { isFiniteNumber } from '../utils/ValidationUtils.js';

export class MineralSystem {
  constructor(game) {
    this.game = game;
    this.list = game.data.minerals;
    this.byId = game.data.mineralMap;
  }

  get regionId() {
    return this.game.state.currentRegion;
  }

  isUnlocked(mineral) {
    return (mineral.unlock?.region ?? 1) <= this.game.state.unlockedRegions;
  }

  isDiscovered(id) {
    return !!this.game.state.discovered[id];
  }

  unlockText(mineral) {
    return `Unlock region ${mineral.unlock?.region ?? 1}`;
  }

  /** Minerals that can currently be mined in the active region. */
  available() {
    return this.list.filter((m) => m.region === this.regionId && this.isUnlocked(m));
  }

  /** Spawn share (0..1) of each available mineral; research can favour the rarest. */
  shares() {
    const available = this.available();
    const rareId = available.length > 1
      ? available.reduce((best, m) => (m.value > best.value ? m : best)).id
      : null;
    const rareBoost = this.game.research.getEffect('rareWeight');
    const weights = {};
    let total = 0;
    for (const m of available) {
      weights[m.id] = m.weight * (m.id === rareId ? rareBoost : 1);
      total += weights[m.id];
    }
    const out = {};
    for (const m of available) out[m.id] = total > 0 ? weights[m.id] / total : 0;
    return out;
  }

  // ---- storage -------------------------------------------------------------

  capacity() {
    const g = this.game;
    const base = g.data.balance.storage.baseCapacity + g.machines.supportBonus('storageBonus');
    return Math.floor(base * g.upgrades.getEffect('storageMultiplier')
      * g.workers.getEffect('storageMultiplier') * g.research.getEffect('storageMultiplier'));
  }

  used() {
    let total = 0;
    for (const id in this.game.state.minerals) total += this.game.state.minerals[id];
    return total;
  }

  free() {
    return Math.max(0, this.capacity() - this.used());
  }

  isFull() {
    return this.free() <= 1e-9;
  }

  /** Stores up to `amount` units; returns how many were accepted. */
  add(id, amount) {
    if (!isFiniteNumber(amount) || amount <= 0 || !(id in this.game.state.minerals)) return 0;
    const accepted = Math.min(amount, this.free());
    if (accepted <= 0) return 0;
    this.game.state.minerals[id] += accepted;
    if (!this.game.state.discovered[id]) this.game.discoverMineral(id);
    return accepted;
  }

  /**
   * Distributes mined units between the available minerals.
   * Small whole amounts roll per unit; larger amounts split by share.
   */
  distribute(units) {
    const shares = this.shares();
    const byMineral = {};
    let accepted = 0;
    const limit = this.game.data.balance.mining.individualRollLimit;

    if (Number.isInteger(units) && units <= limit) {
      for (let i = 0; i < units; i++) {
        const id = weightedPick(shares);
        if (!id) break;
        const got = this.add(id, 1);
        byMineral[id] = (byMineral[id] || 0) + got;
        accepted += got;
      }
    } else {
      for (const id in shares) {
        const got = this.add(id, units * shares[id]);
        byMineral[id] = got;
        accepted += got;
      }
    }

    let main = null;
    for (const id in byMineral) if (!main || byMineral[id] > byMineral[main]) main = id;
    return { accepted, byMineral, main };
  }
}
