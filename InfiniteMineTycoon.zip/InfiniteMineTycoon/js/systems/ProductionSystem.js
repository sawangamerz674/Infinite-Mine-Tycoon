/**
 * ProductionSystem — turns machine output into stored minerals every frame.
 * Machine output is split across the region's minerals by spawn share and
 * scaled by each mineral's mining speed. Production stops when storage is
 * full (selling frees space).
 */
export class ProductionSystem {
  constructor(game) {
    this.game = game;
    this.storageFull = false;
  }

  /** Units per second for each available mineral. */
  getRates() {
    const machines = this.game.machines;
    let total = 0;
    for (const def of machines.list) total += machines.production(def.id);
    const rates = {};
    if (total <= 0) return rates;
    const shares = this.game.minerals.shares();
    total *= this.game.upgrades.getEffect('miningSpeed');
    for (const m of this.game.minerals.available()) {
      rates[m.id] = total * shares[m.id] * m.miningSpeed;
    }
    return rates;
  }

  unitsPerSecond() {
    return Object.values(this.getRates()).reduce((a, b) => a + b, 0);
  }

  /** Coins per second if everything produced were sold. */
  coinsPerSecond() {
    const rates = this.getRates();
    let coins = 0;
    for (const id in rates) coins += rates[id] * this.game.economy.sellValue(id);
    return coins;
  }

  update(dt) {
    const rates = this.getRates();
    const stats = this.game.state.stats;
    let full = false;
    for (const id in rates) {
      const wanted = rates[id] * dt;
      const accepted = this.game.minerals.add(id, wanted);
      stats.mineralsProduced += accepted;
      stats.mineralsExtracted += accepted;
      if (accepted < wanted - 1e-9) full = true;
    }
    this.storageFull = full;
    const cps = this.coinsPerSecond();
    if (cps > this.game.state.highestRate) this.game.state.highestRate = cps;
  }
}
