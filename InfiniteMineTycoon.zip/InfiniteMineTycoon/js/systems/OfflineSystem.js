/**
 * OfflineSystem — progress while the player is away. Two sources feed it:
 *   - the tab being hidden (the game loop is paused, so the time is credited
 *     here when the player returns), and
 *   - a saved `state.lastSeen` timestamp, checked at start (persisted by
 *     SaveSystem).
 * Elapsed time is validated, capped, and reduced by an efficiency factor. The
 * reward is shown in a popup and only applied when the player collects it.
 *
 * Auto-sell is built in (on by default): machines are assumed to keep selling whenever
 * storage fills, limited by capacity per fill-and-sell cycle, and the reward is coins +
 * Research Points. If the player turned auto-sell off, output only fills storage.
 */
import { safeNumber } from '../utils/ValidationUtils.js';

const MAX_SANE_SECONDS = 60 * 60 * 24 * 365; // anything longer is treated as a bad clock

export class OfflineSystem {
  constructor(game) {
    this.game = game;
    this.pending = null; // computed report awaiting collection
    this.hiddenAt = 0;
    this.stampTimer = 0;
  }

  get cfg() {
    const c = this.game.config.offline || {};
    return {
      baseHours: safeNumber(c.baseHours, 2),
      maxHours: safeNumber(c.maxHours, 24),
      efficiency: Math.min(1, Math.max(0, safeNumber(c.efficiency, 0.5))),
      minSeconds: safeNumber(c.minSeconds, 30),
    };
  }

  /** Maximum credited offline time in seconds (base + Time Capsule, hard-limited). */
  capSeconds() {
    const c = this.cfg;
    const hours = Math.min(c.maxHours, c.baseHours + this.game.prestige.getEffect('offlineHours'));
    return Math.max(0, hours) * 3600;
  }

  /** Seconds since a timestamp; 0 for missing, non-finite, future or absurd values. */
  elapsedSince(timestamp, now = Date.now()) {
    if (typeof timestamp !== 'number' || !Number.isFinite(timestamp) || timestamp <= 0) return 0;
    const seconds = (now - timestamp) / 1000;
    if (!Number.isFinite(seconds) || seconds < 0 || seconds > MAX_SANE_SECONDS) return 0;
    return seconds;
  }

  /** Called every game tick: keeps the "last seen" timestamp fresh. */
  update(dt) {
    this.stampTimer += dt;
    if (this.stampTimer >= 5) {
      this.stampTimer = 0;
      this.game.state.lastSeen = Date.now();
    }
  }

  markAway() {
    this.hiddenAt = Date.now();
    this.game.state.lastSeen = this.hiddenAt;
  }

  /** Tab became visible again. */
  handleReturn() {
    const seconds = this.elapsedSince(this.hiddenAt);
    this.hiddenAt = 0;
    return this.report(seconds);
  }

  /** At start: use the saved timestamp, if any. */
  checkSaved() {
    return this.report(this.elapsedSince(this.game.state.lastSeen));
  }

  /**
   * Computes the reward for `seconds` away and queues it as `pending`.
   * Returns the (merged) pending report, or null when nothing is earned.
   */
  report(seconds) {
    const result = this.calculate(seconds);
    if (!result) return this.pending;
    this.pending = this.pending ? this.merge(this.pending, result) : result;
    this.game.bus.emit('offlineEarnings', this.pending);
    return this.pending;
  }

  calculate(seconds) {
    const g = this.game;
    const c = this.cfg;
    if (!Number.isFinite(seconds) || seconds < c.minSeconds) return null;
    const cap = this.capSeconds();
    const credited = Math.min(seconds, cap);
    const rates = g.production.getRates();
    const total = Object.values(rates).reduce((a, b) => a + b, 0);
    if (!(total > 0) || !(credited > 0)) return null;

    const cooldown = g.workers.autoSellInterval();
    const selling = g.state.autoSellEnabled; // built in: no purchase needed
    const wanted = total * credited * c.efficiency;
    let scale = 1;
    if (selling) {
      // One cycle = time to fill storage + the auto-sell cooldown; each cycle sells `capacity` units.
      const capacity = g.minerals.capacity();
      const perSecond = capacity / (capacity / total + cooldown);
      scale = Math.min(1, perSecond / total);
    } else {
      scale = Math.min(1, g.minerals.free() / wanted);
    }

    const perUnit = g.data.balance.researchPerUnit;
    const gain = g.research.getEffect('researchGain');
    const units = {};
    let coins = 0;
    let research = 0;
    let sum = 0;
    for (const id in rates) {
      const u = safeNumber(rates[id] * credited * c.efficiency * scale);
      if (u <= 0) continue;
      units[id] = u;
      sum += u;
      if (selling) {
        coins += u * g.economy.sellValue(id);
        research += u * perUnit[g.minerals.byId[id].rarity] * gain;
      }
    }
    if (sum <= 0) return null;
    return {
      mode: selling ? 'sell' : 'store',
      away: seconds,
      credited,
      capped: seconds > cap,
      cap,
      efficiency: c.efficiency,
      coins: safeNumber(coins),
      research: safeNumber(research),
      units,
      total: sum,
    };
  }

  merge(a, b) {
    const units = { ...a.units };
    for (const id in b.units) units[id] = (units[id] || 0) + b.units[id];
    return {
      ...b,
      mode: b.mode,
      away: a.away + b.away,
      credited: a.credited + b.credited,
      capped: a.capped || b.capped,
      coins: a.coins + b.coins,
      research: a.research + b.research,
      units,
      total: a.total + b.total,
    };
  }

  /** Applies the pending reward (optionally multiplied, e.g. after a rewarded ad). */
  collect(multiplier = 1) {
    const base = this.pending;
    if (!base) return null;
    this.pending = null;
    const m = Number.isFinite(multiplier) && multiplier >= 1 ? multiplier : 1;
    const units = {};
    for (const id in base.units) units[id] = base.units[id] * m;
    const r = { ...base, units, coins: base.coins * m, research: base.research * m, total: base.total * m };
    const g = this.game;
    const s = g.state;
    let stored = 0;
    if (r.mode === 'sell') {
      g.earn(r.coins);
      g.addResearchPoints(r.research);
      s.stats.mineralsSold += Math.floor(r.total);
      s.stats.coinsFromSales += r.coins;
      s.stats.offlineCoins += r.coins;
      for (const id in r.units) {
        if (r.units[id] >= 1 && !s.discovered[id]) g.discoverMineral(id);
      }
    } else {
      for (const id in r.units) stored += g.minerals.add(id, r.units[id]);
    }
    s.stats.mineralsProduced += r.mode === 'sell' ? r.total : stored;
    s.stats.mineralsExtracted += r.mode === 'sell' ? r.total : stored;
    s.stats.offlineSeconds += r.credited;
    g.bus.emit('offlineCollected', { ...r, stored });
    return { ...r, stored };
  }
}
