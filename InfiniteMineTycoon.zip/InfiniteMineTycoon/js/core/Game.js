/**
 * Game — composes state, systems, loop, renderer and input. Contains no
 * DOM code beyond the canvas pointer binding; the UI listens to game.bus.
 *
 * Events emitted:
 *   'mined'            { units, burst, x, y, mineralId }  after a manual hit
 *   'storageFull'      { x, y }                           tap rejected, no space
 *   'sold'             { coins, units }                   after Sell All
 *   'machinePurchased' { id, count, level }
 *   'upgradePurchased' { id, count, level }
 *   'workerHired'      { id, count, hired }
 *   'workerTrained'    { id, count, level }
 *   'autoSellChanged'  enabled
 *   'mineralDiscovered' { id, mineral, reward }
 *   'regionUnlocked'   { id, region, researchPoints }
 *   'regionChanged'    { id, region }
 *   'researchCompleted' { tech }
 *   'achievementCompleted' { def, researchPoints }
 *   'sold' also carries { auto } (true for Manager auto-sales)
 *   'prestiged'        { cores, entry, lostTechs, count }
 *   'prestigeUpgradeBought' { id, level }
 *   'offlineEarnings'  report (pending, awaiting collection)
 *   'offlineCollected' report + { stored }
 *   'settingsChanged'  { key, value }
 *   'saved'            { at, reason }   'saveFailed' { message }
 *   'stateReplaced'    after a load / import / reset
 *   'imported' / 'gameReset'
 *   'boostChanged'     seconds left
 *   'modalOpened' / 'modalClosed'
 *   'treasureAppeared' / 'treasureExpired' / 'treasureOpened' { type, amount, mineral? }
 *   'milestoneReached' { tier, value, label }
 *   'frame'            dt                                 once per update tick
 *   'started'
 */
import { EventBus } from './EventBus.js';
import { GameState } from './GameState.js';
import { GameLoop } from './GameLoop.js';
import { CanvasRenderer } from '../rendering/CanvasRenderer.js';
import { MineRenderer, VIEW_W, VIEW_H } from '../rendering/MineRenderer.js';
import { MineralSystem } from '../systems/MineralSystem.js';
import { UpgradeSystem } from '../systems/UpgradeSystem.js';
import { EconomySystem } from '../systems/EconomySystem.js';
import { MachineSystem } from '../systems/MachineSystem.js';
import { WorkerSystem } from '../systems/WorkerSystem.js';
import { RegionSystem } from '../systems/RegionSystem.js';
import { ResearchSystem } from '../systems/ResearchSystem.js';
import { AchievementSystem } from '../systems/AchievementSystem.js';
import { PrestigeSystem } from '../systems/PrestigeSystem.js';
import { OfflineSystem } from '../systems/OfflineSystem.js';
import { SettingsSystem } from '../systems/SettingsSystem.js';
import { AudioSystem } from '../systems/AudioSystem.js';
import { TreasureSystem } from '../systems/TreasureSystem.js';
import { MilestoneSystem } from '../systems/MilestoneSystem.js';
import { BoostSystem } from '../systems/BoostSystem.js';
import { SaveSystem } from '../systems/SaveSystem.js';
import { AdvisorSystem } from '../systems/AdvisorSystem.js';
import { ProductionSystem } from '../systems/ProductionSystem.js';
import { MiningSystem } from '../systems/MiningSystem.js';
import { StatisticsSystem } from '../systems/StatisticsSystem.js';

export class Game {
  constructor(config, data, platform = null) {
    this.config = config;
    this.platform = platform; // CrazyGamesIntegration (or null)
    this.pauseReasons = new Set();
    this.data = data;
    this.bus = new EventBus();
    this.state = new GameState(config, data);
    this.settings = new SettingsSystem(this);
    this.audio = new AudioSystem(this);

    this.regions = new RegionSystem(this);
    this.research = new ResearchSystem(this);
    this.prestige = new PrestigeSystem(this);
    this.offline = new OfflineSystem(this);
    this.upgrades = new UpgradeSystem(this);
    this.minerals = new MineralSystem(this);
    this.economy = new EconomySystem(this);
    this.machines = new MachineSystem(this);
    this.workers = new WorkerSystem(this);
    this.production = new ProductionSystem(this);
    this.mining = new MiningSystem(this);
    this.achievements = new AchievementSystem(this);
    this.statistics = new StatisticsSystem(this);
    this.boost = new BoostSystem(this);
    this.treasure = new TreasureSystem(this);
    this.milestones = new MilestoneSystem(this);
    this.advisor = new AdvisorSystem(this);
    this.save = new SaveSystem(this);

    // Support machines and workers feed the shared production / selling multipliers.
    this.economy.registerMultiplier('production', () => this.workers.getEffect('productionMultiplier')
      * (1 + this.machines.supportBonus('productionMultiplier'))
      * this.research.getEffect('productionMultiplier')
      * this.achievements.productionMultiplier()
      * this.prestige.coreMultiplier()
      * this.boost.multiplier());
    this.economy.registerMultiplier('selling', () => this.workers.getEffect('sellMultiplier')
      * (1 + this.machines.supportBonus('sellMultiplier'))
      * this.research.getEffect('sellMultiplier'));

    this.buyMode = 1; // 1, 10 or 'max'
    this.hits = 0; // successful manual hits, drives the bonus strike
    this.lastClickAt = 0;
    this.started = false;
  }

  init(canvas) {
    this.canvasRenderer = new CanvasRenderer(canvas, VIEW_W, VIEW_H);
    this.mineRenderer = new MineRenderer(this, this.bus);
    this.loop = new GameLoop(
      (dt) => this.update(dt),
      () => this.render(),
      { maxDelta: this.config.maxFrameDelta },
    );

    canvas.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const p = this.canvasRenderer.toVirtual(e.clientX, e.clientY);
      if (this.treasure.active && this.mineRenderer.fx.hitTreasure(p.x, p.y)) this.treasure.open();
      else if (this.mineRenderer.hitTest(p.x, p.y)) this.manualMine(p.x, p.y);
    });

    document.addEventListener('visibilitychange', () => {
      if (!this.started) return;
      if (document.hidden) {
        this.offline.markAway();
        this.save.save('hidden');
        this.setPaused('hidden', true);
      } else {
        this.setPaused('hidden', false);
        this.offline.handleReturn();
      }
    });
  }

  start() {
    if (!this.started) {
      this.started = true;
      this.bus.emit('started');
    }
    this.syncLoop();
    this.offline.checkSaved();
  }

  /** Pauses the game for a reason ('hidden' tab, 'ad' break); it runs when no reason is left. */
  setPaused(reason, on) {
    if (on) this.pauseReasons.add(reason);
    else this.pauseReasons.delete(reason);
    this.syncLoop();
    this.bus.emit('pauseChanged');
  }

  syncLoop() {
    if (!this.started || !this.loop) return;
    if (this.pauseReasons.size === 0) this.loop.start();
    else this.loop.stop();
  }

  /**
   * Replaces the player's progress with an already-sanitised state (load,
   * import or reset) and refreshes everything derived from it.
   */
  replaceState(clean, hits = 0) {
    Object.assign(this.state, clean);
    this.hits = hits;
    this.research.cache = {};
    this.prestige.cache = {};
    this.offline.pending = null;
    this.offline.hiddenAt = 0;
    this.workers.sellTimer = 0;
    this.production.storageFull = false;
    this.treasure.reset();
    this.bus.emit('stateReplaced');
    this.bus.emit('regionChanged', { id: this.state.currentRegion, region: this.regions.current });
  }

  setBuyMode(mode) {
    if (mode !== 1 && mode !== 10 && mode !== 'max') return;
    this.buyMode = mode;
    this.bus.emit('buyModeChanged', mode);
  }

  /** 0..1 progress toward the next bonus strike. */
  get rockProgress() {
    const n = this.config.manualMining.hitsPerBonusStrike;
    return (this.hits % n) / n;
  }

  /** Bonus-strike payout multiplier (config plus research). */
  get bonusStrikeMultiplier() {
    return this.config.manualMining.bonusStrikeMultiplier + this.research.getEffect('bonusStrikeBonus');
  }

  /** Adds Research Points (safe against invalid values); returns the amount added. */
  addResearchPoints(amount) {
    if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) return 0;
    this.state.researchPoints += amount;
    this.state.stats.researchEarned += amount;
    return amount;
  }

  /** Called once, the first time a mineral reaches storage. */
  discoverMineral(id) {
    const mineral = this.data.mineralMap[id];
    this.state.discovered[id] = true;
    const reward = this.addResearchPoints(this.data.balance.discoveryReward[mineral.rarity] || 0);
    this.bus.emit('mineralDiscovered', { id, mineral, reward });
  }

  /** Single entry point for adding coins. */
  earn(amount) {
    return this.state.addCoins(amount);
  }

  manualMine(x, y) {
    const cfg = this.config.manualMining;
    const now = performance.now();
    if (now - this.lastClickAt < cfg.clickCooldownMs) return 0;
    this.lastClickAt = now;

    this.state.totalClicks += 1;
    const burst = (this.hits + 1) % cfg.hitsPerBonusStrike === 0;
    const result = this.mining.tap(burst ? this.bonusStrikeMultiplier : 1);
    if (result.accepted <= 0) {
      this.bus.emit('storageFull', { x, y });
      return 0;
    }
    this.hits += 1;
    this.bus.emit('mined', { units: result.accepted, burst, x, y, mineralId: result.main });
    return result.accepted;
  }

  update(dt) {
    this.state.playtime += dt;
    this.state.runPlaytime += dt;
    this.offline.update(dt);
    this.save.update(dt);
    this.boost.update(dt);
    this.treasure.update(dt);
    this.milestones.update(dt);
    this.production.update(dt);
    this.workers.update(dt);
    this.achievements.update(dt);
    this.mineRenderer.update(dt);
    this.bus.emit('frame', dt);
  }

  render() {
    const ctx = this.canvasRenderer.begin();
    this.mineRenderer.draw(ctx);
    this.canvasRenderer.end();
  }
}
