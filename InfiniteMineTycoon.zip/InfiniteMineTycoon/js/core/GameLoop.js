/**
 * GameLoop — requestAnimationFrame loop with a clamped delta time so a
 * long stall (tab switch, debugger) never produces a huge simulation step.
 */
export class GameLoop {
  constructor(update, render, { maxDelta = 0.25 } = {}) {
    this.update = update;
    this.render = render;
    this.maxDelta = maxDelta;
    this.running = false;
    this.last = 0;
    this.rafId = 0;
    this.frame = this.frame.bind(this);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.rafId = requestAnimationFrame(this.frame);
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.rafId);
  }

  frame(now) {
    if (!this.running) return;
    const dt = Math.min(Math.max((now - this.last) / 1000, 0), this.maxDelta);
    this.last = now;
    this.update(dt);
    this.render(dt);
    this.rafId = requestAnimationFrame(this.frame);
  }
}
