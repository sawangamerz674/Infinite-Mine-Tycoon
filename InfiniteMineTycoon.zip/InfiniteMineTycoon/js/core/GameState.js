/**
 * GameState — the single source of truth for player progress.
 * Plain serialisable data only. Currency changes go through the safe
 * methods so values can never become negative, NaN or Infinity.
 */
const isValidAmount = (n) => typeof n === 'number' && Number.isFinite(n);

export class GameState {
  constructor(config = {}, data = { minerals: [], machines: [], upgrades: [], workers: [] }) {
    const start = isValidAmount(config.startingCoins) ? Math.max(0, config.startingCoins) : 0;
    this.coins = start;
    this.researchPoints = 0;
    this.ancientCores = 0;
    this.lifetimeCoins = 0;
    this.totalClicks = 0;
    this.playtime = 0; // seconds
    this.highestRate = 0; // coins per second
    this.unlockedRegions = 1;
    this.currentRegion = 1;
    this.researched = {}; // tech id -> true
    this.achievements = {}; // achievement id -> true
    this.prestigeCount = 0;
    this.totalCoresEarned = 0; // Ancient Cores earned ever (spent cores still count)
    this.prestigeUpgrades = {}; // prestige upgrade id -> level
    this.prestigeHistory = []; // newest last: { at, cores, runCoins, runSeconds }
    this.runCoins = 0; // coins earned since the last prestige
    this.runPlaytime = 0; // seconds since the last prestige
    this.boostSeconds = 0; // remaining rewarded-ad income boost
    this.lastSeen = 0; // ms timestamp, refreshed while playing (offline progress)

    this.minerals = Object.fromEntries(data.minerals.map((m) => [m.id, 0])); // stored units
    this.discovered = {}; // mineral id -> true once one unit was stored
    this.machines = Object.fromEntries(data.machines.map((m) => [m.id, 0])); // levels
    this.upgrades = Object.fromEntries(data.upgrades.map((u) => [u.id, 0])); // levels
    // hired = number of workers, level = training level shared by the category
    this.workers = Object.fromEntries(data.workers.map((w) => [w.id, { hired: 0, level: 0 }]));
    this.autoSellEnabled = true;

    this.stats = {
      mineralsExtracted: 0, // all units mined (taps + machines)
      mineralsProduced: 0, // units mined by machines
      mineralsSold: 0,
      coinsFromSales: 0,
      autoSells: 0,
      machinePurchases: 0, // machine levels bought
      upgradePurchases: 0,
      workersHired: 0,
      workerTraining: 0, // training levels bought
      researchEarned: 0, // Research Points gained in total
      treasuresFound: 0, // treasure chests opened
      offlineCoins: 0, // coins collected from offline progress
      offlineSeconds: 0, // offline time that was credited
    };
  }

  /**
   * Resets everything that belongs to a single run (prestige). Cores, research
   * points, discoveries, achievements, statistics and history are untouched.
   */
  resetRun(config, data, { startRegions = 1 } = {}) {
    const fresh = new GameState(config, data);
    this.coins = fresh.coins;
    this.minerals = fresh.minerals;
    this.machines = fresh.machines;
    this.upgrades = fresh.upgrades;
    this.workers = fresh.workers;
    this.unlockedRegions = Math.max(1, Math.min(data.regions.length, startRegions));
    this.currentRegion = 1;
    this.runCoins = 0;
    this.runPlaytime = 0;
  }

  /** Adds coins; returns the amount actually added (0 if invalid). */
  addCoins(amount) {
    if (!isValidAmount(amount) || amount <= 0) return 0;
    this.coins += amount;
    this.lifetimeCoins += amount;
    this.runCoins += amount;
    return amount;
  }

  /** Spends coins; returns true only if the player could afford it. */
  spendCoins(amount) {
    if (!isValidAmount(amount) || amount < 0 || amount > this.coins) return false;
    this.coins -= amount;
    return true;
  }
}
