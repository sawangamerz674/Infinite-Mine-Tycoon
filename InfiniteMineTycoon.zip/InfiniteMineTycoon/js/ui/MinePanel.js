/**
 * MinePanel — the "Mine" tab: region info, Mine button, storage and Sell
 * All, the mineral list (stock, price, output) and bonus-strike progress.
 */
import { formatNumber } from '../utils/NumberFormatter.js';
import { createMineralIcon } from '../rendering/SpriteRenderer.js';
import { StorageWidget } from './StorageWidget.js';
import { AdvisorCard } from './AdvisorCard.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class MinePanel {
  constructor(game, root, toasts) {
    this.game = game;
    this.root = root;
    this.toasts = toasts;
    this.accumulator = 0;
    this.rows = [];
    this.build();
    for (const e of ['mined', 'sold', 'upgradePurchased', 'machinePurchased', 'regionChanged',
      'regionUnlocked', 'researchCompleted', 'mineralDiscovered', 'prestiged']) {
      game.bus.on(e, () => this.render());
    }
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.25) {
        this.accumulator = 0;
        this.render();
      }
    });
    this.render();
  }

  build() {
    this.title = el('h2', 'panel-title');
    this.sub = el('p', 'panel-sub');
    this.root.append(this.title, this.sub);
    this.buildRegionNav();

    const mineBtn = el('button', 'btn btn-primary btn-big', 'Mine!');
    mineBtn.addEventListener('click', () => this.game.manualMine());
    this.root.append(mineBtn);

    this.storage = new StorageWidget(this.game);
    this.root.append(this.storage.el);

    const strike = el('div', 'strike');
    const cfg = this.game.config.manualMining;
    this.power = el('div', 'strike-label');
    strike.append(this.power);
    this.strikeInfo = el('div', 'strike-label');
    this.hitsPerStrike = cfg.hitsPerBonusStrike;
    strike.append(this.strikeInfo);
    const bar = el('div', 'progress');
    this.fill = el('div', 'progress-fill');
    bar.append(this.fill);
    strike.append(bar);
    this.root.append(strike);

    this.advisorCard = new AdvisorCard(this.game);
    this.root.append(this.advisorCard.el);

    this.root.append(el('h3', 'section-title', 'Minerals'));
    for (const mineral of this.game.minerals.list) {
      const row = el('div', 'mineral-row');
      row.dataset.rarity = mineral.rarity;
      const icon = createMineralIcon(mineral);
      const info = el('div', 'mineral-info');
      const name = el('div', 'mineral-name');
      const meta = el('div', 'mineral-meta');
      info.append(name, meta);
      const stock = el('div', 'mineral-stock');
      row.append(icon, info, stock);
      this.root.append(row);
      this.rows.push({ mineral, row, icon, name, meta, stock });
    }
  }

  /** Region selector: one button per region (travel, unlock, or locked). */
  buildRegionNav() {
    this.regionNav = el('div', 'region-nav');
    this.regionBtns = this.game.regions.list.map((region) => {
      const btn = el('button', 'region-btn');
      btn.addEventListener('click', () => {
        const rs = this.game.regions;
        if (rs.isUnlocked(region.id)) rs.select(region.id);
        else if (rs.canUnlock(region.id)) rs.unlock(region.id);
      });
      this.regionNav.append(btn);
      return { region, btn };
    });
    this.regionNote = el('div', 'region-note');
    this.root.append(this.regionNav, this.regionNote);
  }

  renderRegions() {
    const g = this.game;
    const rs = g.regions;
    for (const { region, btn } of this.regionBtns) {
      const unlocked = rs.isUnlocked(region.id);
      const next = rs.canUnlock(region.id);
      const affordable = next && g.state.coins >= region.unlockCost;
      btn.classList.toggle('active', region.id === g.state.currentRegion);
      btn.classList.toggle('can-unlock', affordable);
      btn.disabled = !unlocked && !affordable;
      setText(btn, unlocked ? `${region.id}` : next ? `${region.id} 🔒` : `${region.id} ✕`);
      btn.title = unlocked ? region.name : `${region.name} — ${formatNumber(region.unlockCost)} coins`;
    }
    const next = rs.byId[g.state.unlockedRegions + 1];
    setText(this.regionNote, next
      ? `Next: ${next.name} — ${formatNumber(next.unlockCost)} coins (+${next.reward.researchPoints} RP)`
      : 'All regions unlocked.');
  }

  render() {
    const g = this.game;
    const region = g.regions.current;
    const names = g.regions.mineralsOf(region.id).map((m) => m.name).join(' & ');
    setText(this.title, region.name);
    setText(this.sub, `Region ${region.id} · ${names}`);
    this.renderRegions();
    setText(this.strikeInfo,
      `Bonus strike: every ${this.hitsPerStrike}th hit pays x${formatNumber(g.bonusStrikeMultiplier)}`);
    setText(this.power, `Pickaxe power: ${formatNumber(g.mining.tapYield)} units / tap`);
    this.fill.style.width = `${Math.round(g.rockProgress * 100)}%`;

    const rates = g.production.getRates();
    const available = new Set(g.minerals.available().map((m) => m.id));
    for (const { mineral, row, icon, name, meta, stock } of this.rows) {
      const unlocked = g.minerals.isUnlocked(mineral);
      const inRegion = available.has(mineral.id);
      row.hidden = !inRegion;
      if (!inRegion) continue;
      row.classList.toggle('is-locked', !unlocked);
      icon.classList.toggle('locked-icon', !unlocked);
      if (!unlocked) {
        setText(name, '???');
        setText(meta, g.minerals.unlockText(mineral));
        setText(stock, '');
        continue;
      }
      const found = g.minerals.isDiscovered(mineral.id);
      setText(name, `${mineral.name} · ${mineral.rarity}${found ? '' : ' · undiscovered'}`);
      const price = `${formatNumber(g.economy.sellValue(mineral.id))} coins each`;
      const rate = rates[mineral.id] > 0 ? ` · +${formatNumber(rates[mineral.id])}/s` : '';
      setText(meta, inRegion ? price + rate : price);
      setText(stock, formatNumber(Math.floor(g.state.minerals[mineral.id])));
    }
  }
}
