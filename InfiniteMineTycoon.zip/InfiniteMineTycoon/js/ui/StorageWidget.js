/**
 * StorageWidget — storage bar plus the Sell All button. Shared by the Mine
 * and Machines tabs so the player can always empty storage.
 */
import { formatNumber } from '../utils/NumberFormatter.js';

export class StorageWidget {
  constructor(game) {
    this.game = game;
    this.accumulator = 0;

    this.el = document.createElement('div');
    this.el.className = 'storage';

    this.label = document.createElement('div');
    this.label.className = 'storage-label';
    const bar = document.createElement('div');
    bar.className = 'progress';
    this.fill = document.createElement('div');
    this.fill.className = 'progress-fill';
    bar.append(this.fill);

    this.sellBtn = document.createElement('button');
    this.sellBtn.className = 'btn btn-primary btn-sell';
    this.sellBtn.addEventListener('click', () => game.economy.sellAll());

    this.autoBtn = document.createElement('button');
    this.autoBtn.className = 'btn btn-small btn-auto';
    this.autoBtn.addEventListener('click', () => game.workers.setAutoSell(!game.state.autoSellEnabled));

    this.el.append(this.label, bar, this.sellBtn, this.autoBtn);

    for (const e of ['mined', 'sold', 'upgradePurchased', 'machinePurchased', 'autoSellChanged', 'stateReplaced']) {
      game.bus.on(e, () => this.update());
    }
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.2) {
        this.accumulator = 0;
        this.update();
      }
    });
    this.update();
  }

  update() {
    const m = this.game.minerals;
    const used = m.used();
    const cap = m.capacity();
    const full = m.isFull();
    const text = `Storage ${formatNumber(Math.floor(used))} / ${formatNumber(cap)}${full ? ' (FULL)' : ''}`;
    if (this.label.textContent !== text) this.label.textContent = text;
    this.fill.style.width = `${Math.min(100, (used / cap) * 100)}%`;
    this.fill.classList.toggle('full', full);

    const preview = this.game.economy.previewSellAll();
    const btn = preview.units > 0 ? `Sell all (+${formatNumber(preview.coins)} coins)` : 'Nothing to sell';
    if (this.sellBtn.textContent !== btn) this.sellBtn.textContent = btn;
    this.sellBtn.disabled = preview.units === 0;
    const on = this.game.state.autoSellEnabled;
    const auto = `Auto-sell when full: ${on ? 'ON' : 'OFF'}`;
    if (this.autoBtn.textContent !== auto) this.autoBtn.textContent = auto;
    this.autoBtn.classList.toggle('on', on);
  }
}
