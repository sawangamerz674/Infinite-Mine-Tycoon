/**
 * ResearchPanel — the "Research" tab: Research Points balance and five
 * categories of technology cards. Cards show status (done / locked /
 * available), cost and a Research button; everything updates live.
 */
import { formatNumber } from '../utils/NumberFormatter.js';
import { iconImage } from '../rendering/IconFactory.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class ResearchPanel {
  constructor(game, root) {
    this.game = game;
    this.root = root;
    this.cards = [];
    this.accumulator = 0;
    this.build();
    game.bus.on('researchCompleted', () => this.render());
    game.bus.on('sold', () => this.render());
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.4) {
        this.accumulator = 0;
        if (root.classList.contains('active')) this.render();
      }
    });
    this.render();
  }

  build() {
    const r = this.game.research;
    this.root.append(el('h2', 'panel-title', 'Research'));
    this.balance = el('div', 'rp-balance');
    this.root.append(this.balance);
    this.root.append(el(
      'p', 'panel-sub',
      'Earn Research Points by selling minerals, discovering new ones, unlocking regions and completing achievements.',
    ));

    for (const cat of r.categories) {
      const head = el('div', 'research-head');
      const title = el('h3', 'section-title');
      const catIcon = iconImage(`cat:${cat.id}`, 'section-icon');
      if (catIcon) title.append(catIcon);
      title.append(cat.name);
      head.append(title);
      const count = el('span', 'research-count');
      head.append(count);
      this.root.append(head, el('p', 'card-desc', cat.description));
      const entry = { cat, count, techs: [] };
      for (const tech of r.techsOf(cat.id)) {
        const card = el('div', 'card tech-card');
        const top = el('div', 'card-head');
        const name = el('span', 'card-name', tech.name);
        const status = el('span', 'badge-lv');
        const who = el('span', 'card-who');
        const techIcon = iconImage(`cat:${cat.id}`);
        if (techIcon) who.append(techIcon);
        who.append(name);
        top.append(who, status);
        const desc = el('div', 'card-desc', tech.description);
        const req = el('div', 'card-preview');
        const btn = el('button', 'btn btn-primary btn-small');
        btn.addEventListener('click', () => {
          if (r.research(tech.id)) this.render();
        });
        card.append(top, desc, req, btn);
        this.root.append(card);
        entry.techs.push({ tech, card, status, req, btn });
      }
      this.cards.push(entry);
    }
  }

  render() {
    const g = this.game;
    const r = g.research;
    setText(this.balance, `Research Points: ${formatNumber(Math.floor(g.state.researchPoints))}`);
    for (const { cat, count, techs } of this.cards) {
      const done = r.techsOf(cat.id).filter((t) => r.isResearched(t.id)).length;
      setText(count, `${done} / ${techs.length}`);
      for (const { tech, card, status, req, btn } of techs) {
        const st = r.status(tech);
        card.classList.toggle('is-done', st === 'done');
        card.classList.toggle('is-locked', st === 'locked');
        setText(status, st === 'done' ? 'Researched' : st === 'locked' ? 'Locked' : `${formatNumber(tech.cost)} RP`);
        const missing = st === 'locked' ? r.missingRequirements(tech) : [];
        setText(req, missing.length
          ? `Requires: ${missing.map((t) => t.name).join(', ')}`
          : '');
        req.hidden = missing.length === 0;
        btn.hidden = st === 'done';
        btn.disabled = st !== 'available' || !r.canAfford(tech);
        setText(btn, st === 'locked' ? 'Locked' : r.canAfford(tech) ? 'Research' : `Need ${formatNumber(tech.cost)} RP`);
      }
    }
  }
}
