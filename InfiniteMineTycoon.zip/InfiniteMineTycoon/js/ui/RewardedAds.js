/**
 * RewardedAds — shared flow for optional, player-requested rewarded ads.
 * The reward is granted only when the ad finished; failures never block play.
 */
const MESSAGES = {
  adblock: 'Ads are blocked, so this reward is unavailable. The game works fine without it.',
  unfilled: 'No ad is available right now. Try again in a little while.',
  adCooldown: 'Please wait a moment before watching another ad.',
  adsDisabled: 'Ads are not available right now.',
};

/** Returns true when the reward was granted. */
export async function watchRewarded(game, toasts, onReward) {
  const platform = game.platform;
  if (!platform?.adsAvailable) {
    toasts.show(MESSAGES.adsDisabled, { duration: 3500 });
    return false;
  }
  const result = await platform.requestAd('rewarded');
  if (result.ok) {
    onReward();
    return true;
  }
  toasts.show(MESSAGES[result.code] || 'The ad could not be shown. No reward was lost.', { duration: 3800 });
  return false;
}
