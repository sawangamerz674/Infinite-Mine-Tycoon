/**
 * BuyModeBar — the x1 / x10 / Max selector shared by the Machines and
 * Workers tabs. Both bars stay in sync through game.buyMode.
 */
const MODES = [[1, 'x1'], [10, 'x10'], ['max', 'Max']];

export class BuyModeBar {
  constructor(game) {
    this.game = game;
    this.el = document.createElement('div');
    this.el.className = 'buy-modes';
    const label = document.createElement('span');
    label.className = 'buy-label';
    label.textContent = 'Buy:';
    this.el.append(label);
    this.buttons = MODES.map(([mode, text]) => {
      const btn = document.createElement('button');
      btn.className = 'seg';
      btn.textContent = text;
      btn.addEventListener('click', () => game.setBuyMode(mode));
      this.el.append(btn);
      return { mode, btn };
    });
    game.bus.on('buyModeChanged', () => this.update());
    this.update();
  }

  update() {
    for (const { mode, btn } of this.buttons) btn.classList.toggle('active', mode === this.game.buyMode);
  }
}
