/**
 * NotificationManager — short-lived toast messages (max 3 visible).
 */
export class NotificationManager {
  constructor(root, maxVisible = 3) {
    this.root = root;
    this.maxVisible = maxVisible;
  }

  show(message, { type = 'info', duration = 2800 } = {}) {
    while (this.root.children.length >= this.maxVisible) this.root.firstChild.remove();
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    this.root.append(toast);
    setTimeout(() => {
      toast.classList.add('leaving');
      setTimeout(() => toast.remove(), 250);
    }, duration);
  }
}
