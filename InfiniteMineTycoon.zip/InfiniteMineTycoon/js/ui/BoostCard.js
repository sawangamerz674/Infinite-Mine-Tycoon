/**
 * BoostCard — the optional income boost. Two equal choices, per the CrazyGames rewarded-ad rules:
 * watch a short video (only offered when ads can be served) or pay coins. Nothing here is required
 * to progress, and the reward is granted only after the ad reports it finished.
 */
import { formatNumber } from '../utils/NumberFormatter.js';
import { watchRewarded } from './RewardedAds.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class BoostCard {
  constructor(game, toasts) {
    this.game = game;
    this.toasts = toasts;
    this.el = el('div', 'card boost-card');
    this.text = el('div', 'card-desc');
    this.row = el('div', 'btn-row');
    this.videoBtn = el('button', 'btn btn-small');
    this.videoBtn.append(el('span', 'video-icon'), document.createTextNode(' Watch a video'));
    this.coinBtn = el('button', 'btn btn-small');
    this.row.append(this.videoBtn, this.coinBtn);
    this.el.append(el('div', 'card-name', 'Income Boost'), this.text, this.row);

    this.videoBtn.addEventListener('click', async () => {
      this.videoBtn.disabled = true;
      await watchRewarded(this.game, this.toasts, () => {
        this.game.boost.grant();
        this.toasts.show('Income boost active!', { type: 'region' });
      });
      this.render();
    });
    this.coinBtn.addEventListener('click', () => {
      if (this.game.boost.buyWithCoins()) this.toasts.show('Income boost active!', { type: 'region' });
      this.render();
    });
    game.bus.on('boostChanged', () => this.render());
    this.render();
  }

  render() {
    const g = this.game;
    const b = g.boost;
    const p = g.platform;
    const videoOffered = !!p?.adsAvailable;
    this.videoBtn.hidden = !videoOffered;
    this.videoBtn.disabled = !!p?.adActive;
    const mins = Math.floor(b.remaining / 60);
    const secs = String(Math.floor(b.remaining % 60)).padStart(2, '0');
    const base = b.active
      ? `x${b.cfg.multiplier} income is active: ${mins}:${secs} left.`
      : `Optional: x${b.cfg.multiplier} income for ${Math.round(b.cfg.seconds / 60)} minutes.`;
    const blocked = p?.active && p.adblock ? ' Ads are blocked, so only the coin option is available.' : '';
    setText(this.text, base + blocked);

    const cost = b.coinCost();
    this.coinBtn.disabled = b.active || !(cost > 0) || g.state.coins < cost;
    setText(this.coinBtn, cost > 0 ? `Use ${formatNumber(cost)} coins` : 'Build machines first');
  }
}
