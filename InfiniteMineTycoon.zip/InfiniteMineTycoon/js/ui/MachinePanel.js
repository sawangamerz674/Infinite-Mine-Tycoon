/**
 * MachinePanel — the "Machines" tab: buy mode (x1 / x10 / Max), producer and
 * support machines with level, output/bonus and milestone info, and the
 * upgrade list with current and next-level effects.
 */
import { formatNumber } from '../utils/NumberFormatter.js';
import { StorageWidget } from './StorageWidget.js';
import { BuyModeBar } from './BuyModeBar.js';
import { iconImage } from '../rendering/IconFactory.js';
import { BoostCard } from './BoostCard.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class MachinePanel {
  constructor(game, root, toasts) {
    this.game = game;
    this.root = root;
    this.accumulator = 0;
    this.machineCards = [];
    this.upgradeCards = [];

    root.append(el('h2', 'panel-title', 'Machines'));
    this.storage = new StorageWidget(game);
    root.append(this.storage.el);
    root.append(new BuyModeBar(game).el);
    // Optional income boost (rewarded video or coins). Lives here, not on the tapping screen, per the ad rules.
    this.boostCard = new BoostCard(game, toasts);
    root.append(this.boostCard.el);

    root.append(el('h3', 'section-title', 'Machines'));
    for (const def of game.machines.list) this.machineCards.push(this.buildCard(def, 'machine'));
    root.append(el('h3', 'section-title', 'Upgrades'));
    for (const def of game.upgrades.list) this.upgradeCards.push(this.buildCard(def, 'upgrade'));

    for (const e of ['machinePurchased', 'upgradePurchased', 'workerHired', 'workerTrained', 'sold', 'buyModeChanged']) {
      game.bus.on(e, () => this.render());
    }
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.2) {
        this.accumulator = 0;
        if (root.classList.contains('active')) { this.render(); this.boostCard.render(); }
      }
    });
    this.render();
  }

  buildCard(def, kind) {
    const card = el('div', 'card item-card');
    const head = el('div', 'card-head');
    const name = el('span', 'card-name', def.name);
    const level = el('span', 'badge-lv');
    const icon = iconImage(def.id);
    const who = el('span', 'card-who');
    if (icon) who.append(icon);
    who.append(name);
    head.append(who, level);
    const desc = el('p', 'card-desc', def.description);
    const stats = el('p', 'card-stats');
    const btn = el('button', 'btn btn-primary btn-small');
    btn.addEventListener('click', () => {
      if (kind === 'machine') this.game.machines.buy(def.id, this.game.buyMode);
      else this.game.upgrades.buy(def.id, this.game.buyMode);
    });
    card.append(head, desc, stats, btn);
    this.root.append(card);
    return { def, kind, card, level, stats, btn };
  }

  label(verb, quote) {
    const mode = this.game.buyMode === 'max' ? `Max (${quote.count})` : `x${quote.count}`;
    return `${verb} ${mode} · ${formatNumber(quote.cost)} coins`;
  }

  render() {
    for (const card of this.machineCards) this.renderMachine(card);
    for (const card of this.upgradeCards) this.renderUpgrade(card);
  }

  supportText(def, lv) {
    const e = def.effect;
    const m = this.game.machines;
    const fmt = (v) => (e.display === 'percent' ? `${Math.round(v * 1000) / 10}%` : formatNumber(v));
    const total = m.supportBonus(e.type, def, lv);
    const per = fmt(e.perLevel);
    const now = lv > 0 ? ` · now +${fmt(total)}` : '';
    const next = m.nextMilestone(lv);
    return `+${per} ${e.label} per level${now} · Lv ${next}: x${m.milestones.milestoneMultiplier} bonus`;
  }

  renderMachine({ def, card, level, stats, btn }) {
    const g = this.game;
    const lv = g.machines.level(def.id);
    const unlocked = g.machines.isUnlocked(def);
    card.classList.toggle('is-locked', !unlocked);
    setText(level, lv > 0 ? `Lv ${formatNumber(lv)}` : 'Not owned');
    btn.classList.toggle('hidden', !unlocked);
    if (!unlocked) {
      setText(stats, g.machines.unlockText(def));
      return;
    }
    if (g.machines.isSupport(def)) {
      setText(stats, this.supportText(def, lv));
    } else if (lv === 0) {
      const perLevel = def.baseRate * g.economy.getMultiplier('production');
      setText(stats, `+${formatNumber(perLevel)} units/s per level`);
    } else {
      const next = g.machines.nextMilestone(lv);
      const mult = g.machines.milestones.milestoneMultiplier;
      setText(stats, `Output ${formatNumber(g.machines.production(def.id))} units/s · Lv ${next}: x${mult} output`);
    }
    const quote = g.machines.quote(def, g.buyMode);
    setText(btn, this.label(lv === 0 ? 'Buy' : 'Upgrade', quote));
    btn.disabled = !quote.affordable;
  }

  renderUpgrade({ def, level, stats, btn }) {
    const g = this.game;
    const lv = g.upgrades.level(def.id);
    setText(level, `Lv ${formatNumber(lv)}`);
    const quote = g.upgrades.quote(def, g.buyMode);
    if (quote.count === 0) {
      setText(stats, `${g.upgrades.formatEffect(def, lv)} (max level)`);
      setText(btn, 'Maxed');
      btn.disabled = true;
      return;
    }
    setText(stats, `${g.upgrades.formatEffect(def, lv)} → ${g.upgrades.formatEffect(def, lv + quote.count)}`);
    setText(btn, this.label('Buy', quote));
    btn.disabled = !quote.affordable;
  }
}
