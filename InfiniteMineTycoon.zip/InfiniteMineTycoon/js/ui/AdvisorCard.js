/**
 * AdvisorCard — "Ask the Foreman" card in the Mine tab. Hidden until the advisor
 * server reports it is configured, so builds without the server show nothing.
 * The tip is inserted as text (never HTML).
 */
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

export class AdvisorCard {
  constructor(game) {
    this.game = game;
    this.el = el('div', 'card advisor-card');
    this.el.hidden = true;
    this.tip = el('div', 'card-desc advisor-tip', 'Stuck? Ask the Foreman what to do next.');
    this.tip.setAttribute('aria-live', 'polite');
    this.btn = el('button', 'btn btn-small', 'Ask the Foreman');
    this.btn.addEventListener('click', () => this.ask());
    this.el.append(el('div', 'card-name', "Foreman's Tip"), this.tip, this.btn);

    game.bus.on('advisorAvailable', () => { this.el.hidden = false; });
    game.bus.on('frame', () => this.tick());
    this.el.hidden = !game.advisor.available;
  }

  async ask() {
    this.btn.disabled = true;
    this.tip.textContent = 'The Foreman is thinking...';
    const result = await this.game.advisor.ask();
    this.tip.textContent = result.ok ? result.tip : result.error;
    this.tip.classList.toggle('is-error', !result.ok);
  }

  /** Re-enables the button when the cooldown is over. */
  tick() {
    if (this.el.hidden) return;
    const wait = this.game.advisor.cooldownLeft();
    const busy = this.game.advisor.busy;
    this.btn.disabled = busy || wait > 0;
    const label = wait > 0 && !busy ? `Ask again in ${wait}s` : 'Ask the Foreman';
    if (this.btn.textContent !== label) this.btn.textContent = label;
  }
}
