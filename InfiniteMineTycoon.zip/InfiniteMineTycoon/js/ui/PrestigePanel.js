/**
 * PrestigePanel — the "Prestige" tab: Ancient Cores, eligibility and
 * estimated reward, the explicit reset confirmation, the permanent upgrade
 * tree and the prestige history.
 */
import { formatNumber, formatDuration } from '../utils/NumberFormatter.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class PrestigePanel {
  constructor(game, root, modals) {
    this.game = game;
    this.root = root;
    this.modals = modals;
    this.cards = [];
    this.accumulator = 0;
    this.build();
    for (const e of ['prestiged', 'prestigeUpgradeBought']) game.bus.on(e, () => this.render());
    game.bus.on('stateReplaced', () => { this.history.dataset.n = ''; this.render(); });
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.4) {
        this.accumulator = 0;
        if (root.classList.contains('active')) this.render();
      }
    });
    this.render();
  }

  build() {
    const p = this.game.prestige;
    this.root.append(el('h2', 'panel-title', 'Prestige'));
    this.cores = el('div', 'core-balance');
    this.bonus = el('p', 'panel-sub');
    this.root.append(this.cores, this.bonus);

    const card = el('div', 'card prestige-card');
    this.runLine = el('div', 'card-stats');
    const bar = el('div', 'progress');
    this.fill = el('div', 'progress-fill');
    bar.append(this.fill);
    this.reward = el('div', 'prestige-reward');
    this.btn = el('button', 'btn btn-primary btn-small');
    this.btn.addEventListener('click', () => this.confirm());
    const info = el('div', 'card-desc');
    info.append(el('strong', '', 'Resets: '), 'coins, minerals, machines, upgrades, workers, regions and some research. ');
    info.append(el('strong', '', 'Keeps: '), 'Research Points, persistent research, discoveries, achievements, statistics, Ancient Cores and their upgrades.');
    card.append(this.runLine, bar, this.reward, this.btn, info);
    this.root.append(card);

    this.root.append(el('h3', 'section-title', 'Permanent Upgrades'));
    for (const u of p.list) {
      const c = el('div', 'card');
      const head = el('div', 'card-head');
      const lv = el('span', 'badge-lv');
      head.append(el('span', 'card-name', u.name), lv);
      const desc = el('div', 'card-desc', u.description);
      const stat = el('div', 'card-stats');
      const buy = el('button', 'btn btn-primary btn-small');
      buy.addEventListener('click', () => p.buy(u.id));
      c.append(head, desc, stat, buy);
      this.root.append(c);
      this.cards.push({ u, lv, stat, buy });
    }

    this.root.append(el('h3', 'section-title', 'Prestige History'));
    this.history = el('div', 'history');
    this.root.append(this.history);
  }

  effectText(u, level) {
    const v = u.effect.perLevel * level;
    if (u.effect.mode === 'add') {
      return u.effect.type === 'offlineHours' ? `+${v}h ${u.effect.label}` : `+${v} ${u.effect.label}`;
    }
    return `x${Math.round((1 + v) * 100) / 100} ${u.effect.label}`;
  }

  confirm() {
    const g = this.game;
    const p = g.prestige;
    if (!p.isEligible()) return;
    const lost = p.lostTechs();
    const body = el('div', 'confirm');
    body.append(el('p', '', `You will gain ${formatNumber(p.pendingCores())} Ancient Cores.`));
    const list = el('ul', 'how-list');
    [
      'Reset: coins, minerals, machines, upgrades, workers and regions.',
      lost.length
        ? `Lost research (${lost.length}): ${lost.map((t) => t.name).join(', ')}.`
        : 'No research will be lost.',
      'Kept: Research Points, persistent research, discoveries, achievements, statistics and Ancient Cores.',
    ].forEach((t) => list.append(el('li', '', t)));
    body.append(list, el('p', '', 'This cannot be undone.'));
    this.modals.open({
      title: 'Prestige?',
      body,
      buttons: [
        { label: 'Cancel' },
        { label: 'Prestige', primary: true, onClick: () => p.prestige({ confirmed: true }) },
      ],
    });
  }

  render() {
    const g = this.game;
    const p = g.prestige;
    const s = g.state;
    setText(this.cores, `Ancient Cores: ${formatNumber(s.ancientCores)}`);
    setText(this.bonus, `Production bonus from cores: x${Math.round(p.coreMultiplier() * 100) / 100} · Prestiges: ${s.prestigeCount}`);

    const need = p.settings.minRunCoins;
    setText(this.runLine, `This run: ${formatNumber(Math.floor(s.runCoins))} / ${formatNumber(need)} coins`);
    this.fill.style.width = `${Math.round(p.progress() * 100)}%`;
    const eligible = p.isEligible();
    setText(this.reward, eligible
      ? `Prestige now for +${formatNumber(p.pendingCores())} Ancient Cores`
      : `Earn ${formatNumber(need)} coins in one run to become eligible`);
    this.btn.disabled = !eligible;
    setText(this.btn, eligible ? 'Prestige' : 'Not eligible yet');

    for (const { u, lv, stat, buy } of this.cards) {
      const level = p.level(u.id);
      const maxed = p.isMaxed(u.id);
      setText(lv, `Lv ${level} / ${u.maxLevel}`);
      setText(stat, maxed
        ? `${this.effectText(u, level)} (max)`
        : `Now: ${this.effectText(u, level)}\nNext: ${this.effectText(u, level + 1)}`);
      buy.hidden = maxed;
      buy.disabled = !p.canBuy(u.id);
      setText(buy, `Buy · ${formatNumber(p.cost(u.id))} cores`);
    }

    const hist = s.prestigeHistory;
    const key = `${hist.length}`;
    if (this.history.dataset.n !== key) {
      this.history.dataset.n = key;
      this.history.replaceChildren();
      if (!hist.length) this.history.append(el('div', 'card-desc', 'No prestiges yet.'));
      hist.slice().reverse().slice(0, 10).forEach((h, i) => {
        this.history.append(el('div', 'stat-row',
          `#${hist.length - i} · +${formatNumber(h.cores)} cores · ${formatNumber(Math.floor(h.runCoins))} coins · ${formatDuration(h.runSeconds)}`));
      });
    }
  }
}
