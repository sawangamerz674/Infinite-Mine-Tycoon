/**
 * ModalManager — one modal at a time, closes on backdrop click or Escape.
 */
export class ModalManager {
  constructor(root) {
    this.root = root;
    this.current = null;
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !this.persistent) this.close();
    });
  }

  /**
   * @param {{title:string, body:Node|string, buttons?:{label:string, primary?:boolean, onClick?:Function}[], persistent?:boolean}} opts
   */
  open({ title, body, buttons = [{ label: 'Close' }], persistent = false }) {
    this.close(true);
    this.persistent = persistent;
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.addEventListener('pointerdown', (e) => {
      if (e.target === backdrop && !persistent) this.close();
    });

    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const h = document.createElement('h2');
    h.className = 'modal-title';
    h.textContent = title;
    const content = document.createElement('div');
    content.className = 'modal-body';
    if (typeof body === 'string') content.textContent = body;
    else content.append(body);

    const footer = document.createElement('div');
    footer.className = 'modal-footer';
    for (const b of buttons) {
      const btn = document.createElement('button');
      btn.className = 'btn' + (b.primary ? ' btn-primary' : '');
      btn.textContent = b.label;
      btn.addEventListener('click', () => {
        this.close();
        if (b.onClick) b.onClick();
      });
      footer.append(btn);
    }

    modal.append(h, content, footer);
    backdrop.append(modal);
    this.root.append(backdrop);
    this.current = backdrop;
    this.onChange?.(true);
    footer.querySelector('button')?.focus({ preventScroll: true });
  }

  close(silent = false) {
    if (this.current) {
      this.current.remove();
      this.current = null;
      this.persistent = false;
      if (!silent) this.onChange?.(false);
    }
  }
}
