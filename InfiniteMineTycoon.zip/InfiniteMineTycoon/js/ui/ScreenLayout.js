/**
 * ScreenLayout — picks one fixed UI scale per screen class so the HUD, side panel,
 * tab bar, menus and dialogs stay readable and touch-friendly from a 280px foldable
 * to a 4K monitor. The mine scene itself is scaled separately by CanvasRenderer.
 *
 *   portrait  >= 600px wide (tablets):  scale with width, up to 2.2x
 *   landscape >= 1000x560 (desktop):    scale with the smaller of width/1280 and height/720, up to 2.5x
 *   anything smaller (phones):          1x
 */
export function computeUiScale(width, height) {
  let scale = 1;
  if (height >= width) {
    if (width >= 600) scale = Math.min(2.2, width / 480);
  } else if (width >= 1000 && height >= 560) {
    scale = Math.min(2.5, Math.min(width / 1280, height / 720));
  }
  return Math.max(1, Math.round(scale * 20) / 20);
}

export function initScreenLayout(root = document.documentElement) {
  const apply = () => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    root.style.setProperty('--ui-zoom', String(computeUiScale(w, h)));
    root.dataset.orientation = h >= w ? 'portrait' : 'landscape';
  };
  apply();
  window.addEventListener('resize', apply);
  // iOS reports the new size a moment after the rotation event.
  window.addEventListener('orientationchange', () => setTimeout(apply, 250));
  window.visualViewport?.addEventListener('resize', apply);
}
