/**
 * UIManager — wires the main menu, navigation tabs and panels together.
 * Tabs for systems that arrive in later phases show an honest "unlocks in
 * Phase N" card instead of dead controls.
 */
import { HUD } from './HUD.js';
import { formatNumber, formatDuration } from '../utils/NumberFormatter.js';
import { MinePanel } from './MinePanel.js';
import { MachinePanel } from './MachinePanel.js';
import { WorkerPanel } from './WorkerPanel.js';
import { ResearchPanel } from './ResearchPanel.js';
import { SettingsPanel } from './SettingsPanel.js';
import { PrestigePanel } from './PrestigePanel.js';
import { StatisticsPanel } from './StatisticsPanel.js';
import { watchRewarded } from './RewardedAds.js';
import { ModalManager } from './ModalManager.js';
import { NotificationManager } from './NotificationManager.js';

export class UIManager {
  constructor(game) {
    this.game = game;
    this.modals = new ModalManager(document.getElementById('modal-root'));
    this.toasts = new NotificationManager(document.getElementById('toast-root'));
    this.modals.onChange = (open) => game.bus.emit(open ? 'modalOpened' : 'modalClosed');
    this.hud = new HUD(game);
    this.activeTab = 'mine';

    this.panels = {};
    document.querySelectorAll('.panel').forEach((p) => { this.panels[p.dataset.panel] = p; });

    this.minePanel = new MinePanel(game, this.panels.mine, this.toasts);
    this.machinePanel = new MachinePanel(game, this.panels.machines, this.toasts);
    this.workerPanel = new WorkerPanel(game, this.panels.workers);
    this.researchPanel = new ResearchPanel(game, this.panels.research);
    this.prestigePanel = new PrestigePanel(game, this.panels.prestige, this.modals);
    this.statsPanel = new StatisticsPanel(game, this.panels.statistics);
    this.settingsPanel = new SettingsPanel(game, this.panels.settings, this.toasts, this.modals);
    this.bindNotifications();
    this.bindMenu();
    this.bindTabs();
    this.bindKeyboard();

    game.bus.once('mined', () => {
      document.getElementById('mine-hint').classList.add('gone');
    });
  }

  /** Progression toasts: discoveries, regions, research and achievements. */
  bindNotifications() {
    const { bus } = this.game;
    const rp = (n) => (n > 0 ? ` +${Math.floor(n)} RP` : '');
    bus.on('mineralDiscovered', ({ mineral, reward }) => this.toasts.show(
      `Discovered ${mineral.name}!${rp(reward)}`, { type: 'discovery', duration: 3600 }));
    bus.on('regionUnlocked', ({ region, researchPoints }) => this.toasts.show(
      `Region unlocked: ${region.name}!${rp(researchPoints)}`, { type: 'region', duration: 4000 }));
    bus.on('researchCompleted', ({ tech }) => this.toasts.show(
      `Research complete: ${tech.name}`, { type: 'research' }));
    bus.on('prestiged', ({ cores }) => this.toasts.show(
      `Prestige complete! +${Math.floor(cores)} Ancient Cores`, { type: 'region', duration: 4000 }));
    bus.on('treasureAppeared', () => this.toasts.show('A hidden treasure room opened! Tap the chest.', { type: 'discovery', duration: 3500 }));
    bus.on('treasureOpened', ({ type, amount, mineral }) => this.toasts.show(
      type === 'coins' ? `Treasure! +${formatNumber(amount)} coins`
        : type === 'research' ? `Treasure! +${formatNumber(amount)} Research Points`
          : `Treasure! A cache of ${mineral.name} (+${formatNumber(amount)})`,
      { type: 'achievement', duration: 3500 }));
    bus.on('milestoneReached', ({ label }) => this.toasts.show(`Milestone: ${label}!`, { type: 'region', duration: 3500 }));
    bus.on('offlineEarnings', (report) => this.showOffline(report));
    bus.on('saveFailed', ({ message }) => { if (this.game.started) this.toasts.show(message, { type: 'error', duration: 4500 }); });
    bus.on('achievementCompleted', ({ def, researchPoints }) => this.toasts.show(
      `Achievement: ${def.name}${rp(researchPoints)}`, { type: 'achievement', duration: 3600 }));
  }

  /** "Welcome back" popup; rewards are applied only when collected. */
  showOffline(report) {
    if (!this.game.started) return;
    const g = this.game;
    const list = document.createElement('ul');
    list.className = 'how-list';
    const add = (t) => { const li = document.createElement('li'); li.textContent = t; list.append(li); };
    const mins = Math.max(1, Math.round(report.credited / 60));
    add(`Away for ${formatDuration(report.away)}${report.capped ? ` (credited up to ${formatDuration(report.cap)})` : ''}.`);
    add(`Crews worked at ${Math.round(report.efficiency * 100)}% efficiency for ${mins} min.`);
    if (report.mode === 'sell') {
      add(`Sold ${formatNumber(Math.floor(report.total))} minerals for ${formatNumber(Math.floor(report.coins))} coins.`);
      if (report.research >= 1) add(`Research gained: ${formatNumber(Math.floor(report.research))} RP.`);
    } else {
      add(`Mined ${formatNumber(Math.floor(report.total))} minerals into storage (up to capacity).`);
      add('Auto-sell is off. Turn it on in the Mine tab to sell automatically while you are away.');
    }
    this.modals.open({
      title: 'Welcome Back!',
      body: list,
      persistent: true,
      buttons: [
        { label: report.mode === 'sell' ? 'Collect' : 'Collect minerals', primary: true, onClick: () => g.offline.collect() },
        ...(g.platform?.adsAvailable ? [{
          label: `Watch ad: collect x${g.config.ads?.offlineRewardMultiplier ?? 2}`,
          onClick: async () => {
            const ok = await watchRewarded(g, this.toasts, () => g.offline.collect(g.config.ads?.offlineRewardMultiplier ?? 2));
            if (!ok && g.offline.pending) this.showOffline(g.offline.pending); // keep the reward waiting
          },
        }] : []),
      ],
    });
  }

  bindMenu() {
    document.getElementById('btn-play').addEventListener('click', () => this.startGame());
    document.getElementById('btn-how').addEventListener('click', () => this.showHowToPlay());
  }

  bindTabs() {
    document.querySelectorAll('.tab').forEach((tab) => {
      tab.addEventListener('click', () => this.showTab(tab.dataset.tab));
    });
  }

  bindKeyboard() {
    document.addEventListener('keydown', (e) => {
      // Portal rule: arrow keys must never scroll the page.
      if (e.code.startsWith('Arrow') && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement || e.target instanceof HTMLTextAreaElement)) e.preventDefault();
      if (e.code !== 'Space' || !this.game.started || this.activeTab !== 'mine') return;
      if (e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement) return;
      if (document.querySelector('.modal-backdrop')) return;
      e.preventDefault();
      this.game.manualMine();
    });
  }

  showTab(name) {
    if (!this.panels[name]) return;
    this.activeTab = name;
    document.querySelectorAll('.tab').forEach((t) => {
      t.classList.toggle('active', t.dataset.tab === name);
    });
    for (const [key, panel] of Object.entries(this.panels)) {
      panel.classList.toggle('active', key === name);
    }
    if (name === 'statistics') this.statsPanel.render();
  }

  startGame() {
    document.getElementById('main-menu').classList.add('hidden');
    document.getElementById('game').classList.remove('hidden');
    this.game.canvasRenderer.resize();
    this.game.start();
    const status = this.game.save.loadStatus;
    const messages = {
      loaded: 'Welcome back! Save loaded.',
      backup: 'Your save was damaged, so the backup copy was loaded.',
      corrupt: 'Your save could not be read. A new game was started (the old data was kept aside).',
    };
    this.toasts.show(messages[status] || 'Welcome, miner! Tap the rock to dig.', { duration: status === 'new' ? 2800 : 4500 });
    if (!this.game.save.available) this.toasts.show('Saving is unavailable in this browser. Use Export in Settings.', { duration: 5000 });
  }

  showHowToPlay() {
    const list = document.createElement('ul');
    list.className = 'how-list';
    [
      'Tap or click the rock (or press Space) to mine minerals into storage.',
      'Press Sell all to sell stored minerals at any time. When storage is full they are sold automatically, so mining rarely stops.',
      'Every 10th hit is a bonus strike that pays 5x.',
      'Spend coins in the Machines tab: machines mine for you, upgrades boost tapping, output, prices and storage.',
      'Pick Buy x1, x10 or Max to buy several levels at once.',
      'Storage is sold automatically whenever it is full (you can switch this off in the Mine tab). A Manager, research and upgrades shorten the delay; hire and train crews for more bonuses.',
      'Sell minerals to earn Research Points, then spend them in the Research tab. Unlock deeper regions from the Mine tab for rarer minerals.',
      'Once a run earns enough coins, Prestige for Ancient Cores: permanent bonuses that make every new run faster.',
      'Your game saves automatically. Offline earnings are collected when you return; use Settings to export, import or reset your save.',
    ].forEach((text) => {
      const li = document.createElement('li');
      li.textContent = text;
      list.append(li);
    });
    this.modals.open({ title: 'How to Play', body: list, buttons: [{ label: 'Got it', primary: true }] });
  }
}
