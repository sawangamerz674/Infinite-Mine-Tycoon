/**
 * WorkerPanel — the "Workers" tab: hire and train the five worker
 * categories, see their bonuses, and toggle the Manager's auto-selling.
 */
import { formatNumber } from '../utils/NumberFormatter.js';
import { createWorkerPortrait } from '../rendering/SpriteRenderer.js';
import { BuyModeBar } from './BuyModeBar.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

export class WorkerPanel {
  constructor(game, root) {
    this.game = game;
    this.root = root;
    this.accumulator = 0;
    this.cards = [];

    root.append(el('h2', 'panel-title', 'Workers'));
    root.append(el('p', 'panel-sub', 'Hire crews, then train them to strengthen their bonus.'));
    this.buildAutoSell();
    root.append(new BuyModeBar(game).el);
    for (const def of game.workers.list) this.cards.push(this.buildCard(def));

    for (const e of ['workerHired', 'workerTrained', 'machinePurchased', 'upgradePurchased', 'sold', 'buyModeChanged', 'autoSellChanged']) {
      game.bus.on(e, () => this.render());
    }
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.25) {
        this.accumulator = 0;
        if (root.classList.contains('active')) this.render();
      }
    });
    this.render();
  }

  buildAutoSell() {
    this.autoRow = el('div', 'card auto-card');
    this.autoText = el('div', 'auto-text');
    this.autoBtn = el('button', 'btn btn-small');
    this.autoBtn.addEventListener('click', () => {
      this.game.workers.setAutoSell(!this.game.state.autoSellEnabled);
    });
    this.autoRow.append(this.autoText, this.autoBtn);
    this.root.append(this.autoRow);
  }

  buildCard(def) {
    const card = el('div', 'card item-card worker-card');
    const head = el('div', 'card-head');
    const who = el('div', 'worker-who');
    who.append(createWorkerPortrait(def), el('span', 'card-name', def.name));
    const level = el('span', 'badge-lv');
    head.append(who, level);
    const desc = el('p', 'card-desc', def.description);
    const now = el('p', 'card-stats');
    const preview = el('p', 'card-preview');
    const buttons = el('div', 'btn-row');
    const hireBtn = el('button', 'btn btn-primary btn-small');
    const trainBtn = el('button', 'btn btn-small');
    hireBtn.addEventListener('click', () => this.game.workers.hire(def.id, this.game.buyMode));
    trainBtn.addEventListener('click', () => this.game.workers.train(def.id, this.game.buyMode));
    buttons.append(hireBtn, trainBtn);
    card.append(head, desc, now, preview, buttons);
    this.root.append(card);
    return { def, card, level, now, preview, buttons, hireBtn, trainBtn };
  }

  btnLabel(verb, quote) {
    const mode = this.game.buyMode === 'max' ? `Max (${quote.count})` : `x${quote.count}`;
    return `${verb} ${mode}\n${formatNumber(quote.cost)} coins`;
  }

  render() {
    const g = this.game;
    const w = g.workers;

    const on = g.state.autoSellEnabled;
    setText(this.autoText, `Auto-sell when full is ${on ? 'ON' : 'OFF'} · ${w.describe(w.manager)}`);
    setText(this.autoBtn, on ? 'Turn off' : 'Turn on');

    for (const { def, card, level, now, preview, buttons, hireBtn, trainBtn } of this.cards) {
      const unlocked = w.isUnlocked(def);
      const hired = w.hired(def.id);
      const lv = w.level(def.id);
      card.classList.toggle('is-locked', !unlocked);
      buttons.classList.toggle('hidden', !unlocked);
      setText(level, hired > 0 ? `${formatNumber(hired)} hired · Lv ${formatNumber(lv)}` : 'Not hired');
      if (!unlocked) {
        setText(now, w.unlockText(def));
        setText(preview, '');
        continue;
      }
      setText(now, w.describe(def));

      const hq = w.quoteHire(def, g.buyMode);
      const tq = w.quoteTrain(def, g.buyMode);
      const afterHire = w.describe(def, hired + hq.count, lv);
      const afterTrain = tq.count > 0 ? w.describe(def, hired, lv + tq.count) : null;
      setText(preview, afterTrain
        ? `Hire → ${afterHire}\nTrain → ${afterTrain}`
        : `Hire → ${afterHire}\nTrain: hire a ${def.name.toLowerCase()} first`);

      setText(hireBtn, this.btnLabel('Hire', hq));
      hireBtn.disabled = !hq.affordable;
      if (tq.count > 0) {
        setText(trainBtn, this.btnLabel('Train', tq));
        trainBtn.disabled = !tq.affordable;
      } else {
        setText(trainBtn, 'Train\n(hire first)');
        trainBtn.disabled = true;
      }
    }
  }
}
