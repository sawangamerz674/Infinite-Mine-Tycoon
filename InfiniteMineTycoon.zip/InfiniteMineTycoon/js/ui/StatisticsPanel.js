/**
 * StatisticsPanel — renders the rows provided by StatisticsSystem.
 */
export class StatisticsPanel {
  constructor(game, root) {
    this.game = game;
    this.root = root;
    this.rows = [];
    const title = document.createElement('h2');
    title.className = 'panel-title';
    title.textContent = 'Statistics';
    root.append(title);

    this.achEl = null;
    this.accumulator = 0;
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.5) {
        this.accumulator = 0;
        if (root.classList.contains('active')) this.render();
      }
    });
    this.render();
  }

  render() {
    const data = this.game.statistics.getRows();
    // Build rows on first render (the row list is fixed), then only update values.
    if (this.rows.length !== data.length) {
      for (const { label } of data) {
        const row = document.createElement('div');
        row.className = 'stat-row';
        const l = document.createElement('span');
        l.className = 'stat-label';
        l.textContent = label;
        const v = document.createElement('span');
        v.className = 'stat-value';
        row.append(l, v);
        this.root.append(row);
        this.rows.push(v);
      }
    }
    data.forEach(({ value }, i) => {
      if (this.rows[i].textContent !== value) this.rows[i].textContent = value;
    });
    this.renderAchievements();
  }

  renderAchievements() {
    const ach = this.game.achievements;
    if (!this.achEl) {
      const h = document.createElement('h3');
      h.className = 'section-title';
      h.textContent = 'Achievements';
      this.root.append(h);
      this.achEl = ach.list.map((def) => {
        const card = document.createElement('div');
        card.className = 'ach';
        const name = document.createElement('div');
        name.className = 'ach-name';
        const desc = document.createElement('div');
        desc.className = 'ach-desc';
        const bar = document.createElement('div');
        bar.className = 'progress';
        const fill = document.createElement('div');
        fill.className = 'progress-fill';
        bar.append(fill);
        card.append(name, desc, bar);
        this.root.append(card);
        name.textContent = def.name;
        desc.textContent = `${def.description} Reward: ${def.reward.researchPoints} RP`;
        return { def, card, fill };
      });
    }
    for (const { def, card, fill } of this.achEl) {
      const done = ach.isDone(def.id);
      card.classList.toggle('is-done', done);
      fill.style.width = `${Math.round(ach.progress(def).fraction * 100)}%`;
    }
  }
}
