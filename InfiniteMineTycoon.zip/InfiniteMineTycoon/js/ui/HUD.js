/**
 * HUD — top resource bar: coins, research points, ancient cores and
 * production rate. Only touches the DOM when a displayed value changes.
 */
import { formatNumber } from '../utils/NumberFormatter.js';

export class HUD {
  constructor(game) {
    this.game = game;
    this.fields = {
      coins: document.getElementById('hud-coins'),
      rp: document.getElementById('hud-rp'),
      cores: document.getElementById('hud-cores'),
      rate: document.getElementById('hud-rate'),
    };
    this.cache = {};
    this.accumulator = 0;

    game.bus.on('sold', () => {
      this.render();
      this.bump(this.fields.coins);
    });
    for (const e of ['machinePurchased', 'upgradePurchased', 'workerHired', 'workerTrained', 'researchCompleted', 'regionUnlocked', 'mineralDiscovered', 'achievementCompleted', 'prestiged', 'prestigeUpgradeBought', 'offlineCollected']) {
      game.bus.on(e, () => this.render());
    }
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 0.1) {
        this.accumulator = 0;
        this.render();
      }
    });
    this.render();
  }

  set(key, text) {
    if (this.cache[key] === text) return;
    this.cache[key] = text;
    this.fields[key].textContent = text;
  }

  bump(el) {
    el.classList.remove('bump');
    void el.offsetWidth; // restart the CSS animation
    el.classList.add('bump');
  }

  render() {
    const s = this.game.state;
    this.set('coins', formatNumber(Math.floor(s.coins)));
    this.set('rp', formatNumber(Math.floor(s.researchPoints)));
    this.set('cores', formatNumber(Math.floor(s.ancientCores)));
    this.set('rate', formatNumber(this.game.production.coinsPerSecond()));
  }
}
