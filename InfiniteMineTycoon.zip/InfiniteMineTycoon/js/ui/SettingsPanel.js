/**
 * SettingsPanel — audio, display, save management (save now, export, import)
 * and reset options with confirmation dialogs.
 */
import { SCHEMA } from '../systems/SettingsSystem.js';
import { timeAgo } from '../utils/TimeUtils.js';
import { formatNumber } from '../utils/NumberFormatter.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

const LABELS = {
  notation: { short: 'Short (1.5M)', scientific: 'Scientific (1.5e6)', full: 'Full (1,500,000)' },
  particles: { low: 'Low', normal: 'Normal', high: 'High' },
};

export class SettingsPanel {
  constructor(game, root, toasts, modals) {
    this.game = game;
    this.root = root;
    this.toasts = toasts;
    this.modals = modals;
    this.controls = {};
    this.accumulator = 0;
    this.build();
    game.bus.on('settingsChanged', () => this.sync());
    game.bus.on('stateReplaced', () => this.sync());
    game.bus.on('saved', () => this.renderSaveInfo());
    game.bus.on('frame', (dt) => {
      this.accumulator += dt;
      if (this.accumulator >= 1) {
        this.accumulator = 0;
        if (root.classList.contains('active')) this.renderSaveInfo();
      }
    });
    this.sync();
  }

  row(label, control, hint) {
    const row = el('div', 'setting-row');
    const text = el('div', 'setting-text');
    text.append(el('div', 'setting-label', label));
    if (hint) text.append(el('div', 'card-desc', hint));
    row.append(text, control);
    this.root.append(row);
    return row;
  }

  toggle(key) {
    const btn = el('button', 'toggle');
    btn.addEventListener('click', () => this.game.settings.set(key, !this.game.settings.get(key)));
    this.controls[key] = btn;
    return btn;
  }

  slider(key, preview) {
    const input = el('input', 'slider');
    input.type = 'range';
    input.min = String(SCHEMA[key].min * 100);
    input.max = String(SCHEMA[key].max * 100);
    input.step = '5';
    input.addEventListener('input', () => this.game.settings.set(key, Number(input.value) / 100));
    if (preview) input.addEventListener('change', () => this.game.audio.play(preview));
    this.controls[key] = input;
    return input;
  }

  select(key) {
    const sel = el('select', 'select');
    for (const v of SCHEMA[key].values) {
      const o = el('option', '', LABELS[key][v]);
      o.value = v;
      sel.append(o);
    }
    sel.addEventListener('change', () => this.game.settings.set(key, sel.value));
    this.controls[key] = sel;
    return sel;
  }

  button(label, onClick, cls = '') {
    const b = el('button', `btn btn-small ${cls}`.trim(), label);
    b.addEventListener('click', onClick);
    return b;
  }

  build() {
    this.root.append(el('h2', 'panel-title', 'Settings'));

    this.root.append(el('h3', 'section-title', 'Audio'));
    this.audioNote = el('div', 'card-desc', 'Sound is muted by CrazyGames. Unmute the game in the CrazyGames player to hear it; this overrides the options below.');
    this.audioNote.classList.toggle('hidden', !this.game.platform?.audioMuted);
    this.game.bus.on('platformAudioChanged', ({ muted }) => this.audioNote.classList.toggle('hidden', !muted));
    this.root.append(this.audioNote);
    this.row('Music', this.toggle('musicEnabled'));
    this.row('Music volume', this.slider('musicVolume'));
    this.row('Effects volume', this.slider('sfxVolume', 'coin'));

    this.root.append(el('h3', 'section-title', 'Display'));
    this.row('Number format', this.select('notation'));
    this.row('Particles', this.select('particles'));
    this.row('Animation speed', this.slider('animationSpeed'), 'Visual effects only; production is unaffected.');
    this.row('Screen shake', this.toggle('screenShake'));
    this.row('Floating numbers', this.toggle('floatingText'));
    const fs = this.button('Toggle', () => this.toggleFullscreen());
    this.fullscreenBtn = fs;
    // CrazyGames provides fullscreen itself and prohibits custom in-game fullscreen buttons.
    if (document.fullscreenEnabled && !this.game.platform?.active) this.row('Fullscreen', fs);

    this.root.append(el('h3', 'section-title', 'Save'));
    const platform = this.game.platform;
    this.root.append(el('div', 'card-desc',
      `Platform: ${platform?.label ?? 'Standalone (no SDK)'} · Saves: ${platform?.active ? 'CrazyGames data (synced across devices when logged in, otherwise this browser)' : 'this browser'}`));
    this.saveInfo = el('div', 'card-desc');
    this.root.append(this.saveInfo);
    this.row('Autosave', this.toggle('autosave'), 'Every 30 seconds, when the tab is hidden and when you leave.');
    const saveRow = el('div', 'btn-row');
    saveRow.append(
      this.button('Save now', () => this.saveNow()),
      this.button('Download file', () => this.download()),
    );
    this.root.append(saveRow);
    const copyRow = el('div', 'btn-row');
    copyRow.append(this.button('Copy save code', () => this.copyCode()));
    this.fileInput = el('input');
    this.fileInput.type = 'file';
    this.fileInput.accept = '.json,.txt,application/json,text/plain';
    this.fileInput.hidden = true;
    this.fileInput.addEventListener('change', () => this.importFile());
    copyRow.append(this.button('Import file', () => this.fileInput.click()), this.fileInput);
    this.root.append(copyRow);

    this.importBox = el('textarea', 'import-box');
    this.importBox.placeholder = 'Paste a save code here to import it';
    this.importBox.rows = 3;
    this.root.append(this.importBox, this.button('Import pasted code', () => this.importText(this.importBox.value)));

    this.root.append(el('h3', 'section-title', 'Reset'));
    const resetRow = el('div', 'btn-row');
    resetRow.append(
      this.button('Reset settings', () => this.confirmResetSettings()),
      this.button('Reset progress', () => this.confirmResetProgress(), 'btn-danger'),
    );
    this.root.append(resetRow);
    document.addEventListener('fullscreenchange', () => this.syncFullscreen());
  }

  sync() {
    const s = this.game.settings;
    for (const [key, c] of Object.entries(this.controls)) {
      const v = s.get(key);
      if (c.classList.contains('toggle')) {
        c.textContent = v ? 'On' : 'Off';
        c.classList.toggle('on', v);
        c.setAttribute('aria-pressed', String(v));
      } else if (c.type === 'range') {
        c.value = String(Math.round(v * 100));
      } else {
        c.value = v;
      }
    }
    this.syncFullscreen();
    this.renderSaveInfo();
  }

  syncFullscreen() {
    this.fullscreenBtn.textContent = document.fullscreenElement ? 'Exit fullscreen' : 'Enter fullscreen';
  }

  toggleFullscreen() {
    const p = document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    Promise.resolve(p).catch(() => this.toasts.show('Fullscreen is not available here.'));
  }

  renderSaveInfo() {
    const sv = this.game.save;
    const text = sv.available
      ? `Last saved: ${timeAgo(sv.lastSavedAt)}`
      : 'Saving is unavailable in this browser. Use Download file or Copy save code to keep your progress.';
    if (this.saveInfo.textContent !== text) this.saveInfo.textContent = text;
  }

  // ---- save actions ----------------------------------------------------------------------------

  saveNow() {
    if (this.game.save.save('manual')) this.toasts.show('Game saved.');
    else this.toasts.show('Could not save.', { type: 'error' });
  }

  download() {
    try {
      const blob = new Blob([this.game.save.exportCode()], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `infinite-mine-tycoon-${new Date().toISOString().slice(0, 10)}.txt`;
      document.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      this.toasts.show('Save file downloaded.');
    } catch (err) {
      this.toasts.show('Download failed. Try Copy save code.', { type: 'error' });
    }
  }

  async copyCode() {
    const code = this.game.save.exportCode();
    try {
      await navigator.clipboard.writeText(code);
      this.toasts.show('Save code copied.');
    } catch (err) {
      this.importBox.value = code; // clipboard blocked: show it so it can be copied by hand
      this.importBox.select();
      this.toasts.show('Clipboard blocked. The code is in the box below: copy it manually.', { duration: 5000 });
    }
  }

  async importFile() {
    const file = this.fileInput.files[0];
    this.fileInput.value = '';
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      this.toasts.show('That file is too large to be a save.', { type: 'error' });
      return;
    }
    this.importText(await file.text());
  }

  importText(text) {
    const result = this.game.save.parseImport(text);
    if (!result.ok) {
      this.toasts.show(result.error, { type: 'error', duration: 4500 });
      return;
    }
    const s = result.state;
    const body = el('div', 'confirm');
    body.append(el('p', '', 'This replaces your current progress with the imported save:'));
    const list = el('ul', 'how-list');
    [
      `Saved: ${timeAgo(result.savedAt)}`,
      `Coins: ${formatNumber(Math.floor(s.coins))}`,
      `Lifetime coins: ${formatNumber(Math.floor(s.lifetimeCoins))}`,
      `Prestiges: ${s.prestigeCount} · Ancient Cores: ${formatNumber(s.ancientCores)}`,
      `Regions unlocked: ${s.unlockedRegions}`,
    ].forEach((t) => list.append(el('li', '', t)));
    body.append(list, el('p', '', 'Your current progress will be lost unless you exported it.'));
    this.modals.open({
      title: 'Import save?',
      body,
      buttons: [
        { label: 'Cancel' },
        {
          label: 'Import',
          primary: true,
          onClick: () => {
            if (this.game.save.applyImport(result)) {
              this.importBox.value = '';
              this.toasts.show('Save imported.');
            }
          },
        },
      ],
    });
  }

  // ---- reset --------------------------------------------------------------------------------------

  confirmResetSettings() {
    this.modals.open({
      title: 'Reset settings?',
      body: 'Audio, display and autosave options return to their defaults. Your progress is not affected.',
      buttons: [
        { label: 'Cancel' },
        { label: 'Reset settings', primary: true, onClick: () => { this.game.settings.resetAll(); this.toasts.show('Settings reset.'); } },
      ],
    });
  }

  confirmResetProgress() {
    const body = el('div', 'confirm');
    body.append(
      el('p', '', 'This permanently deletes ALL progress: coins, machines, research, achievements, Ancient Cores and statistics, including the saved copy and its backup.'),
      el('p', '', 'Tip: use Download file first if you might want it back. Settings are kept.'),
    );
    this.modals.open({
      title: 'Reset all progress?',
      body,
      buttons: [
        { label: 'Cancel' },
        {
          label: 'Delete everything',
          primary: true,
          onClick: () => { this.game.save.resetProgress(); this.toasts.show('Progress reset. A new game begins.'); },
        },
      ],
    });
  }
}
