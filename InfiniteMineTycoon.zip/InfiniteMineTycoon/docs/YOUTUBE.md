# YouTube presentation kit — Infinite Mine Tycoon

No YouTube account integration or auto-upload is included; this is a guide for recording and publishing manually.

## Recording tips
- Use `?debug` or localhost only if you need `window.game` for testing; do not use it in published footage unless you say so.
- Window 1920x1080, browser zoom 100%, particles "High", screen shake on. Record at 60 fps.
- Game music is procedural and original, so footage is safe to monetise from an audio standpoint. Add your own voice-over separately.
- Turn off floating text only if the footage looks busy.

## Video ideas
1. **From Zero to One Billion Coins** — early game tapping, first machines, workers, first region unlock, the first prestige. Hook: show the final coin counter in the first 5 seconds.
2. **Unlocking the Deepest Mine** — research order, region unlocks, the treasure room, rare minerals glowing in the deep regions.
3. **First 100 Prestige Resets** — core upgrades, route changes, how fast each reset gets. Show the history table.
4. **Building the Ultimate Mining Empire** — late-game machines, milestones (x2 every machine milestone), banner moments.

## Titles / descriptions (examples)
- "I Built a Mining Empire With Zero Clicks (Idle Tycoon)"
- "How Deep Can You Dig? Infinite Mine Tycoon"
Description template: one-line hook, play link, chapters, "Pixel-art idle mining tycoon made with HTML5." Add the CrazyGames link when live.

## Thumbnail
`assets/promo/youtube-thumbnail-1280x720.png` is a starting point; add a large number ("1 BILLION") or a glowing gem for contrast.

## Promo videos and covers
`assets/promo/videos/` holds two 17.5-second silent gameplay previews: `gameplay-landscape-1920x1080.mp4` (16:9) and `gameplay-portrait-1080x1620.mp4` (2:3), made to the CrazyGames preview-video rules (no sound, no promo text, the cover as first frame). For YouTube, add your own voice-over or music and a title card if you want them. The footage was captured from the real game with a deterministic fake clock; scripted progress uses the localhost-only debug API.
Cover images (title only): `cover-landscape-1920x1080.png`, `cover-portrait-800x1200.png`, `cover-square-800x800.png`.
