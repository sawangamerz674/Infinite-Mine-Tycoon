# AI advisor ("Ask the Foreman")

An optional Mine-tab card that gives one short, practical tip based on the current run, written by a Google Gemini model. It is off by default in the sense that it only appears when the advisor server is running and configured.

## How it works

```
Browser (AdvisorSystem)  --summary-->  server/index.mjs  --prompt-->  Gemini API
        ^                                    |  holds GEMINI_API_KEY
        +------------- { tip } --------------+
```

- The browser sends a compact summary: region, coins, income, storage %, machine/worker/upgrade levels, researched tech ids, next region cost, prestige counts. No names, ids of the player, or other personal data.
- The server whitelists and clamps that summary (`sanitizeSummary`), builds the prompt, calls the model with a fixed system instruction and returns plain text (`cleanTip`).
- The API key exists only in the server's environment. It is never sent to the browser.
- If the server is missing, not configured, or blocked (static hosting, CrazyGames, offline), the health check fails and the card stays hidden. The rest of the game is unaffected.

## Run it

```bash
npm install
cp .env.example .env        # then set GEMINI_API_KEY (load it with your shell or host)
GEMINI_API_KEY=... npm run start:ai     # http://localhost:8080
npm run start:ai:mock                   # canned answers, no key, no network
```

| Variable | Meaning |
|----------|---------|
| `GEMINI_API_KEY` | Required for real answers |
| `GEMINI_MODEL` | Default `gemini-3.5-flash`; confirm the name in Google's current model list |
| `ALLOWED_ORIGIN` | Set when the game's files are hosted on a different origin than the server (CORS) |
| `PORT` | Default 8080 |

Client settings are in `config/game.config.json` under `ai`: `enabled`, `baseUrl` (empty = same origin), `cooldownSeconds` (20), `timeoutSeconds` (12).

On a plain static host the health check is one failed request (a 404 in the console) and nothing else; set `ai.enabled` to `false` in the config for static or portal builds to skip it. The check is also skipped automatically when the CrazyGames SDK is active.

## Safeguards
- Prompt injection: only ids and clamped numbers reach the prompt, and the system instruction tells the model to treat the data as statistics.
- Abuse and cost: 8 requests per minute per client address, 2,000 per day overall, 8 KB request limit, 12 s timeout, 160 output tokens.
- Errors return friendly messages; details are logged on the server only.
- The tip is displayed as text, never as HTML.

## Platform notes
- **CrazyGames:** portals normally restrict network requests to the game's own origin and review external services. Check their current rules before shipping this; the safe default is to leave the server out of the portal build.
- **Google Play / own website:** host the server (any Node 22 host), serve the game from it or set `ALLOWED_ORIGIN`, and mention the AI service in your privacy policy and Data safety form.
- A Gemini API key has usage costs and quotas; monitor them.

## Tests
`npm test` covers the sanitiser, prompt, rate limiter and error handling with a fake client. `npm run test:e2e` starts the mock server, checks the card appears, answers and respects the cooldown, and that it stays hidden without the API. A real Gemini call has not been tested because it needs a key.
