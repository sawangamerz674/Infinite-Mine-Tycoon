# CrazyGames submission notes — Infinite Mine Tycoon

> Checked against docs.crazygames.com (technical, gameplay and quality requirements; SDK v3 game, ad and intro pages) on 2026-11-12. Re-check before uploading; the portal's rules can change.

## Listing text
**Title:** Infinite Mine Tycoon
**Short description:** Dig deep, build machines, hire workers and uncover rare minerals in a pixel-art idle mining tycoon. Prestige to start again, stronger.
**Long description:** Tap the rock, then let machines and workers do the digging. Sell minerals, research upgrades, unlock five regions from the Surface Quarry to the Crystal Depths, and hunt the treasure chests that appear in hidden rooms. When growth slows, prestige for Mining Cores that permanently boost your next run. The game saves automatically and pays out offline progress.
**Genre/tags:** idle, clicker, tycoon, incremental, mining, pixel art, management
**Languages:** English

## Controls
- Mouse / touch: tap the rock to mine; tap treasure chests when they appear; use the side panels for machines, workers, research, prestige, statistics and settings.
- Keyboard: Tab / Enter / Space operate every button.
- No audio autoplay: sound starts after the first interaction; a mute toggle is in Settings.

## Covers and preview videos (`assets/promo/`)
Rules from docs.crazygames.com (game covers): three covers, title as the only text, no borders, icons, store logos or "Play"/"New" words, nothing blurry or pixelated; preview videos 15-20 s, at most 50 MB, 1080p landscape (16:9) and 1080p portrait (2:3), no sound, no fast-forwarding, the static cover as the opening frame, no black bars, mouse cursors or promotional text.
- Covers: `cover-landscape-1920x1080.png`, `cover-portrait-800x1200.png`, `cover-square-800x800.png`. They are cropped 1:1 from a 10x native-scale render of the game, so every art pixel is a sharp 10x10 block (no resampling), with only the title added.
- Videos: `videos/gameplay-landscape-1920x1080.mp4` and `videos/gameplay-portrait-1080x1620.mp4` (2:3), 17.5 s, about 3.6 MB and 2.1 MB, silent, first frame is the cover. Scripted real gameplay: only the game's own UI is visible.
- The other files (`screenshot-*`, `play-phone-*`, YouTube thumbnail, Play feature graphic) are for other stores and may carry text; do not upload them as CrazyGames covers.
- The art is deliberately pixel art. If a reviewer reads "pixelated" as low quality, point to the sharp integer scaling.

## SDK integration
Only documented SDK v3 calls are used: init, loadingStart/Stop, gameplayStart/Stop, rewarded and midgame ads, and the data module. Ads are optional; the game works without the SDK. The integration was tested against a stub of the documented API, not the live SDK, so test inside the CrazyGames QA/preview tool.
- Rewarded: offline earnings x2 and a 5-minute income boost. Midgame: only after a prestige, 3-minute cooldown. Game and audio pause during ads.

## Pre-submission checklist
- [ ] In the Developer Portal submission form, switch on **"Does your game save progress?"** (required when using the data module).
- [ ] In the QA tool, toggle the game's mute and confirm audio stops and resumes; test a logged-in user and a guest.
- [ ] Test in the CrazyGames preview with the real SDK (ads, pause, save/load).
- [ ] Confirm the total file size and load time meet current limits.
- [ ] Confirm no external requests other than the SDK.
- [ ] Play 10+ minutes on desktop and a phone; check offline reward and prestige.
- [ ] Check Settings → Reset and Export/Import saves.
- [ ] Balance pass (all numbers are tunable in `config/` and `data/`).

## Requirements check (2026-11-12)
| Requirement | Status |
|---|---|
| Upload package within limits (250 MB, 1,500 files, 50 MB initial, 20 MB for mobile homepage) | Met: `npm run package:crazygames` builds `dist/crazygames/` (84 files, about 0.4 MB) without promo art, docs, tests or the AI server |
| Relative paths only | Met (`./` manifest, relative script/css/fetch paths) |
| SDK v3 script in head, `await init()`, no calls when environment is `disabled` | Met; verified against a stub for crazygames, local, disabled and no-SDK |
| gameplayStart/Stop at every break (menu, modal, ad, hidden tab) | Met |
| loadingStart/Stop | Met |
| Ads: mute and pause on adStarted, resume on finished or error; works with adblock | Met; rewarded ads are optional and player-initiated |
| Rewarded-ad rules (not on the tapping screen, video indicated, a no-ad alternative, reward only on `adFinished`, no dead buttons, notice when adblock is on) | Met: the Income Boost card moved to the Machines tab, shows a video icon, offers the same boost for coins, hides the video option when ads are unavailable and says so when an adblocker is detected |
| Midgame ads only at natural breaks, SDK enforces the 3-minute limit | Met: only after a completed prestige, never on a navigation button |
| Works with ads disabled (Basic Launch) | Met: nothing depends on an ad; every reward has a normal route |
| Data module for saves | Met: progress, backup and player options are stored with SDK `data.getItem/setItem/removeItem`; an older LocalStorage save is migrated once (copied, verified, then removed); falls back to LocalStorage if the module fails; save size guarded below the 1 MB limit |
| `muteAudio` support (full-release requirement) | Met: `SDK.game.settings.muteAudio` is read at start and `addSettingsChangeListener` keeps it live; it overrides the in-game audio options, which cannot lift it, and Settings explains why sound is off |
| No custom fullscreen button | Met: hidden whenever the SDK is active |
| No cross-promotion or external links | Met: no store or other-game links in the game |
| English included; PEGI 12 suitable | Met; English only, no real-money purchases |
| Chrome and Edge; keyboard, mouse and touch | Met; Safari and Chromebook performance not tested here |
| `user-select: none` on body; no page scroll from wheel or arrow keys or space | Met |
| iOS audio resumes from a user gesture | Met |
| Land in gameplay with at most one click | Met (one Play click) |
| Readable at 800x450 and 1920x1080 | Checked at 800x450 and 1920x1080 |
| AI Foreman advisor | Hidden automatically on CrazyGames; server not part of the upload |

| Covers: 3 sizes, title only, no borders/icons/extra words | Met (regenerated 2026-11-16) |
| Preview videos: 15-20 s, <= 50 MB, 1080p landscape and 2:3 portrait, silent, cover as first frame, no promo text | Met (17.5 s, 3.6 MB and 2.1 MB) |
| Quality guide: one consistent art style, clear labels, skippable onboarding (How to Play is optional), control hints, no oversized ad buttons, consistent audio levels | Met by design; no onboarding is forced |
| Privacy: no personal data collected beyond the SDK | Met; the AI advisor is off on CrazyGames |

Not verified: the live SDK (only a stub was available), real-device Safari, 144 Hz+ refresh behaviour (the loop is delta-time based), and the Developer Portal cover-size page, which could not be fetched.
Optional and not implemented: `happytime()`, user account module, `Escape` closes dialogs (the quality guide suggests avoiding keys with browser behaviour).
