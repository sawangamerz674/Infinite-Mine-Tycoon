# Game design

## Core loop
Tapping (or machines) mines minerals into **storage**. Minerals are **sold** (manually with *Sell all*, or automatically when storage is full) for coins and Research Points. Coins buy machines, upgrades and workers. Deeper regions give rarer, more valuable minerals. When growth slows, **prestige** for permanent bonuses.

Costs follow `baseCost x growth^level`; Buy x1 / x10 / Max use the geometric-series total. Every 25 machine levels doubles that machine's output (configurable `machines.milestoneEvery`).

## Controls
Click or tap the rock, press Space, or use the Mine! button. Every 10th hit is a bonus strike that pays 5x.

## Minerals and regions
Five regions unlock in order for coins: Surface Mine, Iron Caverns, Golden Depths, Crystal Caverns, Ancient Depths (`data/regions.json`). Each has its own two minerals (the last has one), look, lighting and region-gated machines. The first time a mineral reaches storage it is *discovered* and pays Research Points by rarity.

## Machines
- **Producers:** Basic Miner, Advanced Miner, Drill Machine, Heavy Drill, plus region-gated Industrial Excavator, Crystal Extractor and Advanced Mining Robot
- **Support:** Conveyor Belt (output), Mining Elevator (storage), Ore Processor (sell value)

## Workers (`data/workers.json`)
Miner (+output), Engineer (cheaper machines, capped at -50%), Transporter (+storage), Geologist (+sell value), Manager (faster auto-sell). Each type has a hired count and a shared training level: `bonus = hired x perWorker x (1 + level x levelBoost)`.

## Upgrades (`data/upgrades.json`)
Pickaxe Power, Mining Speed, Machine Production, Conveyor Speed, Worker Efficiency, Mineral Selling Value, Storage Capacity, Automation Efficiency (max level 25).

## Auto-sell
Built in and enabled from the first launch; no purchase required. It sells only while storage is full, after a delay (base 3 s). A Manager, its training, the Sales Network research and Automation Efficiency shorten the delay (minimum 0.5 s). Players can switch it off under the storage bar or in the Workers tab. Offline progress uses the same rule: each fill-and-sell cycle sells one full storage.

## Research (`data/research.json`)
20 technologies in 5 categories (mining, machines, transport, discovery, workers) with prerequisite chains. Each has a `persists` flag that decides whether it survives a prestige. Research Points come from sales, discoveries, region unlocks, achievements and treasure.

## Achievements
22 achievements with progress bars; each pays Research Points and +1% production.

## Prestige (`data/prestige.json`)
Available once a run has earned 100M coins. `cores = floor(coreScale x (runCoins / coreDivisor) ^ coreExponent)`. Each core ever earned adds +2% production. Resets coins, minerals, machines, upgrades, workers, regions and non-persistent research; keeps Research Points, persistent research, discoveries, achievements, statistics, cores, core upgrades and history. Seven core upgrades, including Surveyor's Map (start in deeper regions) and Time Capsule (longer offline cap). `prestige()` refuses to run without explicit confirmation.

## Offline progress
Validated and capped (2 h base, +2 h per Time Capsule level, 24 h maximum, `config.offline`), paid at 50% efficiency, shown in a *Welcome Back* popup that must be collected. Future, negative or absurd timestamps are ignored.

## Treasure and milestones
Every 90-180 s a chest appears in a hidden room for 25 s and pays coins, Research Points or a rare-mineral cache. Each thousand-fold of lifetime coins triggers a celebration. Both are tuned in `config.treasure` and `config.milestones`.

## Rewarded ads (CrazyGames build only)
Optional: x2 offline earnings, 5 minutes of x2 income. A midgame ad can appear only after a prestige, at most every 3 minutes. Nothing is granted unless the ad finished.

## Tuning checklist
1. Edit JSON in `data/` or `config/`
2. `npm run validate`
3. Play 10 minutes; check the first machine purchase, the first region unlock and the first prestige feel right

All current numbers are starting points and have not been balanced against real player data.
