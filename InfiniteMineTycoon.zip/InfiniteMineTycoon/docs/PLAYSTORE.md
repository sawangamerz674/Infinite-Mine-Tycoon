# Google Play release guide — Infinite Mine Tycoon

The game is a static web app, so the standard route to Google Play is a **Trusted Web Activity (TWA)** wrapping the hosted game. Nothing here has been uploaded or reviewed by Google; check current Play Console policies before you submit.

## What the project already provides
- `manifest.webmanifest` (fullscreen, any orientation, theme colours, icons incl. maskable)
- `sw.js` service worker (installable, works offline after the first load; not registered inside portal iframes)
- `assets/icons/icon-512.png` (store icon), `icon-maskable-512.png`, `icon-192.png`
- `assets/promo/play-feature-graphic-1024x500.png` (feature graphic)
- `assets/promo/play-phone-1…5-*.png` (1080x1920 phone screenshots)

## Steps
1. Host the game over HTTPS (any static host). Open it in Chrome and confirm the install prompt / Lighthouse PWA checks pass.
2. Generate the Android project with Bubblewrap (`npx @bubblewrap/cli init --manifest https://YOUR-HOST/manifest.webmanifest`, then `bubblewrap build`). This produces the `.aab`.
3. Set up Digital Asset Links: put the `assetlinks.json` Bubblewrap prints at `https://YOUR-HOST/.well-known/assetlinks.json`, with your signing key's SHA-256. Without it the app shows a browser address bar.
4. In Play Console create the app, upload the `.aab`, add the store listing below, complete Data safety and Content rating, and start with internal or closed testing.

## Listing text
**Title:** Infinite Mine Tycoon
**Short description (80 chars):** Dig deep, automate your mine and prestige in this pixel-art idle tycoon.
**Full description:** Tap the rock, hire machines and workers, and build an enormous underground empire. Mine nine minerals across five regions, research 20 technologies, hunt treasure chests, earn 22 achievements and prestige for permanent Ancient Core bonuses. Your mine keeps working while you are away. Original pixel art and music, no sign-up.
**Category:** Games › Casual (or Simulation). **Tags:** idle, tycoon, clicker, mining, pixel art.

## Policy items to prepare
- **Privacy policy URL** is required. The game stores progress on the device only. If you enable ads (CrazyGames SDK is for the CrazyGames build; a Play build needs its own ad network or none), disclose them.
- **Data safety:** no account, no personal data collected by the game itself. Declare anything your ad provider collects.
- **Content rating:** no violence, gambling or user-generated content; fill the questionnaire honestly.
- **Ads on Play:** the CrazyGames SDK is not used outside CrazyGames and the game runs without it. Rewarded buttons are hidden when no ad platform is active.
- Test on a real phone: touch, rotation, offline start, background/resume, save/load.

## Known limits
- Not tested in a real TWA build or on a device in this environment.
- Price, countries, age rating and listing screenshots are your decisions.
