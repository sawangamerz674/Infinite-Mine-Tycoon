#!/usr/bin/env node
/**
 * Game server with the optional Foreman advisor API.
 *
 *   GET  /api/health    -> { ok: true, enabled: true }
 *   POST /api/advisor   -> { tip: "..." }   body: the game summary built by AdvisorSystem
 *   everything else     -> the game's static files
 *
 * Environment (see .env.example):
 *   GEMINI_API_KEY   required for real answers (never sent to the browser)
 *   GEMINI_MODEL     model name, default gemini-3.5-flash (check Google's current model list)
 *   ADVISOR_MOCK=1   (or the --mock flag) canned answers, no key and no network (demos, tests)
 *   ALLOWED_ORIGIN   set when the game is hosted on another origin (CORS)
 *   PORT             default 8080
 */
import { createServer } from 'node:http';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { serveStatic } from '../tools/static-handler.mjs';
import { createAdvisor, createMockClient, createRateLimiter } from './advisor.mjs';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const PORT = Number(process.env.PORT) || 8080;
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.5-flash';
const MAX_BODY = 8 * 1024;

const MOCK = process.env.ADVISOR_MOCK === '1' || process.argv.includes('--mock');

async function createClient() {
  if (MOCK) return createMockClient();
  if (!process.env.GEMINI_API_KEY) return null;
  const { GoogleGenAI } = await import('@google/genai');
  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

const client = await createClient();
const advisor = client ? createAdvisor({ client, model: MODEL }) : null;
const limiter = createRateLimiter();

function cors(res) {
  if (process.env.ALLOWED_ORIGIN) {
    res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }
}

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}

function readJson(req) {
  return new Promise((resolveBody, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error('Request too large'), { status: 413 }));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolveBody(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(Object.assign(new Error('Invalid JSON'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

async function handleApi(req, res, path) {
  cors(res);
  if (req.method === 'OPTIONS') return res.writeHead(204).end();
  if (path === '/api/health' && req.method === 'GET') return sendJson(res, 200, { ok: true, enabled: Boolean(advisor) });
  if (path === '/api/advisor' && req.method === 'POST') {
    if (!advisor) return sendJson(res, 503, { error: 'The advisor is not configured.' });
    if (!limiter.allow(req.socket.remoteAddress ?? 'unknown')) return sendJson(res, 429, { error: 'The Foreman needs a break. Try again in a minute.' });
    try {
      return sendJson(res, 200, { tip: await advisor.advise(await readJson(req)) });
    } catch (err) {
      if (err.status) return sendJson(res, err.status, { error: err.message });
      if (err instanceof TypeError) return sendJson(res, 400, { error: 'Invalid summary' });
      console.error('Advisor error:', err.message);
      return sendJson(res, 502, { error: 'The Foreman is unavailable right now.' });
    }
  }
  return sendJson(res, 404, { error: 'Not found' });
}

createServer((req, res) => {
  const path = new URL(req.url, 'http://localhost').pathname;
  if (path.startsWith('/api/')) return handleApi(req, res, path);
  return serveStatic(req, res, ROOT);
}).listen(PORT, () => {
  const mode = MOCK ? 'mock' : advisor ? `Gemini (${MODEL})` : 'disabled (no GEMINI_API_KEY)';
  console.log(`Infinite Mine Tycoon: http://localhost:${PORT}  |  advisor: ${mode}`);
});
