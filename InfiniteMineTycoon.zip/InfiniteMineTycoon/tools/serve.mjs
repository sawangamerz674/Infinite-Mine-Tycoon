#!/usr/bin/env node
/**
 * Minimal static file server for local development (no dependencies).
 * ES modules and fetch() need http://, so index.html cannot be opened from disk.
 *
 *   npm start            -> http://localhost:8080
 *   PORT=3000 npm start  -> http://localhost:3000
 */
import { createServer } from 'node:http';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { serveStatic } from './static-handler.mjs';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const PORT = Number(process.env.PORT) || 8080;

createServer((req, res) => serveStatic(req, res, ROOT))
  .listen(PORT, () => console.log(`Infinite Mine Tycoon: http://localhost:${PORT}`));
