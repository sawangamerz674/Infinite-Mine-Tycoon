/**
 * Builds a clean upload folder for the CrazyGames developer portal and checks it
 * against the published limits (250 MB total, 1,500 files, 50 MB initial download,
 * 20 MB for the mobile homepage). Promo art, docs, tests, tooling and the optional
 * AI server are left out. Usage: npm run package:crazygames  ->  dist/crazygames/
 */
import { cpSync, rmSync, mkdirSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'dist', 'crazygames');
const INCLUDE = ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'js', 'config', 'data', 'assets/fonts', 'assets/icons'];

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
for (const item of INCLUDE) {
  const from = join(root, item);
  if (existsSync(from)) cpSync(from, join(out, item), { recursive: true });
}

let files = 0;
let bytes = 0;
(function walk(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p);
    else { files += 1; bytes += st.size; }
  }
})(out);

const mb = bytes / 1048576;
console.log(`dist/crazygames: ${files} files, ${mb.toFixed(2)} MB`);
const problems = [];
if (files > 1500) problems.push('more than 1,500 files');
if (mb > 250) problems.push('over 250 MB total');
if (mb > 20) console.log('note: above 20 MB, so not eligible for the mobile homepage');
if (problems.length) { console.error(`FAILED: ${problems.join(', ')}`); process.exit(1); }
console.log('Within CrazyGames size and file-count limits. Zip the contents of that folder (index.html at the zip root) and upload.');
