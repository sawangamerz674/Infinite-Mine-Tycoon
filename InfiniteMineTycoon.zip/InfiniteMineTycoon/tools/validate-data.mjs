#!/usr/bin/env node
/**
 * Validates the JSON content files: unique ids, required fields, sane numbers and
 * cross references (research prerequisites, region minerals, regions in config).
 * Exits with code 1 and a list of problems when something is wrong.
 *
 *   npm run validate
 */
import { readFile } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const load = async (path) => JSON.parse(await readFile(new URL(path, root), 'utf8'));

const problems = [];
const fail = (message) => problems.push(message);

function uniqueIds(label, list) {
  const seen = new Set();
  for (const item of list) {
    if (!(typeof item.id === 'string' && item.id) && !Number.isInteger(item.id)) fail(`${label}: entry without id`);
    else if (seen.has(item.id)) fail(`${label}: duplicate id "${item.id}"`);
    else seen.add(item.id);
  }
  return seen;
}

function positive(label, item, fields) {
  for (const f of fields) {
    if (!Number.isFinite(item[f]) || item[f] < 0) fail(`${label} "${item.id}": "${f}" must be a non-negative number`);
  }
}

const [minerals, machines, workers, upgrades, regions, research, achievements, prestige] = await Promise.all(
  ['minerals', 'machines', 'workers', 'upgrades', 'regions', 'research', 'achievements', 'prestige'].map((n) => load(`data/${n}.json`)),
);
await load('config/game.config.json');
await load('config/balance.config.json');

const mineralIds = uniqueIds('minerals', minerals.minerals);
minerals.minerals.forEach((m) => positive('mineral', m, ['value', 'weight', 'miningSpeed']));

uniqueIds('machines', machines.machines);
for (const m of machines.machines) {
  positive('machine', m, m.kind === 'producer' ? ['baseCost', 'baseRate', 'growth'] : ['baseCost', 'growth']);
  if (!['producer', 'support'].includes(m.kind)) fail(`machine "${m.id}": unknown kind "${m.kind}"`);
}

uniqueIds('workers', workers.workers);
workers.workers.forEach((w) => positive('worker', w, ['baseCost', 'growth', 'upgradeBaseCost', 'upgradeGrowth']));

uniqueIds('upgrades', upgrades.upgrades);
upgrades.upgrades.forEach((u) => positive('upgrade', u, ['baseCost', 'growth']));

const regionIds = uniqueIds('regions', regions.regions);
for (const m of minerals.minerals) {
  if (!regionIds.has(m.region)) fail(`mineral "${m.id}": unknown region ${m.region}`);
}

const categoryIds = uniqueIds('research categories', research.categories);
const techIds = uniqueIds('research techs', research.techs);
for (const t of research.techs) {
  if (!categoryIds.has(t.category)) fail(`tech "${t.id}": unknown category "${t.category}"`);
  for (const req of [].concat(t.requires ?? [])) {
    if (!techIds.has(req)) fail(`tech "${t.id}": unknown prerequisite "${req}"`);
  }
  if (typeof t.persists !== 'boolean') fail(`tech "${t.id}": "persists" must be true or false`);
}

uniqueIds('achievements', achievements.achievements);
achievements.achievements.forEach((a) => positive('achievement', a, ['target']));
uniqueIds('prestige upgrades', prestige.upgrades);

if (mineralIds.size === 0) fail('no minerals defined');

if (problems.length) {
  console.error(`Data validation failed (${problems.length}):`);
  problems.forEach((p) => console.error(`  - ${p}`));
  process.exit(1);
}
console.log(
  `Data OK: ${minerals.minerals.length} minerals, ${machines.machines.length} machines, ${workers.workers.length} workers, `
  + `${upgrades.upgrades.length} upgrades, ${regions.regions.length} regions, ${research.techs.length} techs, `
  + `${achievements.achievements.length} achievements, ${prestige.upgrades.length} prestige upgrades.`,
);
